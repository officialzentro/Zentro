import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { warmupDb } from './lib/supabase';
import './styles/global.css';
import { ErrorBoundary } from './ErrorBoundary';

import BottomNav      from './components/BottomNav';
import MobileDownloadBanner from './components/MobileDownloadBanner';
import { usePush } from './hooks/usePush';
import Home           from './pages/Home';
import Explore        from './pages/Explore';
import ShopDetail     from './pages/ShopDetail';
import Login          from './pages/Login';
import Register       from './pages/Register';
import Account        from './pages/Account';
import AdminPortal    from './pages/AdminPortal';
import BarberDashboard from './pages/BarberDashboard';
import BarberSetup    from './pages/BarberSetup';
import BarberSlots    from './pages/BarberSlots';
import BarberPayment  from './pages/BarberPayment';
import Download       from './pages/Download';
import InviteFriends  from './pages/InviteFriends';

warmupDb();

function BarberRoute({ children }) {
  const { user, profile, authReady } = useAuth();
  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return <Navigate to="/login" replace />;
  if (profile && profile.role !== 'barber') return <Navigate to="/" replace />;
  return children;
}

function AppRoutes() {
  const { user } = useAuth();
  usePush(user?.id);
  return (
    <>
      <Routes>
        <Route path="/"          element={<ErrorBoundary name="Home"><Home /></ErrorBoundary>} />
        <Route path="/explore"   element={<ErrorBoundary name="Explore"><Explore /></ErrorBoundary>} />
        <Route path="/shop/:id"  element={<ErrorBoundary name="ShopDetail"><ShopDetail /></ErrorBoundary>} />
        <Route path="/login"     element={<ErrorBoundary name="Login"><Login /></ErrorBoundary>} />
        <Route path="/register"  element={<ErrorBoundary name="Register"><Register /></ErrorBoundary>} />
        <Route path="/account"   element={<ErrorBoundary name="Account"><Account /></ErrorBoundary>} />
        <Route path="/invite"    element={<ErrorBoundary name="InviteFriends"><InviteFriends /></ErrorBoundary>} />
        <Route path="/admin"     element={<ErrorBoundary name="AdminPortal"><AdminPortal /></ErrorBoundary>} />
        <Route path="/barber/dashboard" element={<BarberRoute><ErrorBoundary name="BarberDashboard"><BarberDashboard /></ErrorBoundary></BarberRoute>} />
        <Route path="/barber/setup"     element={<BarberRoute><ErrorBoundary name="BarberSetup"><BarberSetup /></ErrorBoundary></BarberRoute>} />
        <Route path="/barber/slots"     element={<BarberRoute><ErrorBoundary name="BarberSlots"><BarberSlots /></ErrorBoundary></BarberRoute>} />
        <Route path="/barber/payment"   element={<BarberRoute><ErrorBoundary name="BarberPayment"><BarberPayment /></ErrorBoundary></BarberRoute>} />
        <Route path="/bookings"  element={<Navigate to="/account" replace />} />
        <Route path="/download"  element={<ErrorBoundary name="Download"><Download /></ErrorBoundary>} />
        <Route path="*"          element={<Navigate to="/" replace />} />
      </Routes>
      <ErrorBoundary name="BottomNav"><BottomNav /></ErrorBoundary>
      <ErrorBoundary name="MobileDownloadBanner"><MobileDownloadBanner /></ErrorBoundary>
    </>
  );
}

export default function App() {
  return (
    <ErrorBoundary name="AuthProvider+Router">
      <BrowserRouter>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
