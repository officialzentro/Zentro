import { NavLink, useLocation } from 'react-router-dom';

// Home icon SVG
const HomeIcon = ({ active }) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill={active ? 'var(--brand)' : 'none'}
    stroke={active ? 'var(--brand)' : 'var(--text-3)'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
    <polyline points="9,22 9,12 15,12 15,22"/>
  </svg>
);

const ExploreIcon = ({ active }) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
    stroke={active ? 'var(--brand)' : 'var(--text-3)'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6" fill={active ? 'var(--brand-glow)' : 'none'}/>
    <line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/>
  </svg>
);

const AccountIcon = ({ active }) => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill={active ? 'var(--brand-glow)' : 'none'}
    stroke={active ? 'var(--brand)' : 'var(--text-3)'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
    <circle cx="12" cy="7" r="4" fill={active ? 'var(--brand)' : 'none'} stroke={active ? 'var(--brand)' : 'var(--text-3)'}/>
  </svg>
);

export default function BottomNav() {
  const { pathname } = useLocation();
  if (['/login', '/register', '/admin'].some(p => pathname.startsWith(p))) return null;

  // All users (barber or customer) get the same 3-tab nav.
  // Barbers access their dashboard/setup/slots/payment via Account tabs.
  const links = [
    { to: '/',        label: 'Home',    Icon: HomeIcon    },
    { to: '/explore', label: 'Explore', Icon: ExploreIcon },
    { to: '/account', label: 'Account', Icon: AccountIcon },
  ];

  return (
    <nav className="bottomnav">
      {links.map(({ to, label, Icon }) => (
        <NavLink
          key={to}
          to={to}
          end={to === '/'}
          className={({ isActive }) => `bottomnav-item${isActive ? ' active' : ''}`}
        >
          {({ isActive }) => (
            <>
              <span className="bottomnav-icon"><Icon active={isActive} /></span>
              {label}
            </>
          )}
        </NavLink>
      ))}
    </nav>
  );
}
