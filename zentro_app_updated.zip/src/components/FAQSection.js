import { useState } from 'react';

const FAQS = [
  {
    q: 'Zentro kya hai?',
    a: 'Zentro Pakistan ka online barber booking platform hai. Aap apne nearby barbers dhundh kar seconds mein appointment book kar sakte ho — bina wait kiye, bina call kiye. Your Cut, Your Time.',
  },
  {
    q: 'Kya Zentro free hai customers ke liye?',
    a: 'Haan! Customers ke liye Zentro bilkul free hai. Account banao, barber dhundho, aur apna time slot book karo — koi charge nahi.',
  },
  {
    q: 'Main apna barber kaise book karun?',
    a: 'Home screen se koi bhi shop tap karo, available time slot choose karo, service select karo, aur Book Now press karo. Itna aasaan hai!',
  },
  {
    q: 'Kya mujhe account banana zaroori hai?',
    a: 'Haan, booking ke liye free account banana hoga. Yeh sirf ek minute ka kaam hai — naam, email, aur password.',
  },
  {
    q: 'Barber ke liye subscription plans kya hain?',
    a: 'Barbers ke liye Basic, Pro, aur Premium plans hain — 999 Rs, 2499 Rs, aur 4999 Rs monthly. Har plan mein alag features hain jaise QR code, priority listing, aur zyada photos.',
  },
  {
    q: 'Payment kaise karte hain barbers?',
    a: 'Barbers JazzCash ya Easypaisa se payment karte hain. Screenshot upload karo aur admin verify karke subscription activate kar deta hai.',
  },
  {
    q: 'Kya Zentro app available hai?',
    a: 'Haan! Zentro PWA hai — aap isko seedha apne phone ke browser se install kar sakte ho bina Play Store ke. Download page par jaake apne phone mein add karo.',
  },
  {
    q: 'Mera booking cancel kaise hoga?',
    a: 'Account page par jaao, apni upcoming booking dekho, aur Cancel button press karo. Slot automatically free ho jaata hai.',
  },
  {
    q: 'Kya main multiple barbers book kar sakta hun?',
    a: 'Haan! Aap jitne chahein utne alag barbers se appointments book kar sakte ho.',
  },
  {
    q: 'Mujhe koi masla ho to kahan contact karun?',
    a: 'Hamare TikTok @zentropk_official ya Instagram par message karo. Hum jaldi respond karte hain!',
  },
];

function ChevronIcon({ open }) {
  return (
    <svg
      width="16" height="16" viewBox="0 0 24 24" fill="none"
      stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"
      style={{ transition: 'transform 0.25s', transform: open ? 'rotate(180deg)' : 'rotate(0deg)', flexShrink: 0 }}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function FAQItem({ q, a, open, onToggle }) {
  return (
    <div
      style={{
        borderRadius: 14,
        background: open ? 'var(--bg-input)' : 'var(--bg-card)',
        border: `1.5px solid ${open ? 'var(--border-brand)' : 'var(--border)'}`,
        overflow: 'hidden',
        transition: 'border-color 0.2s',
        marginBottom: 8,
      }}
    >
      <button
        onClick={onToggle}
        style={{
          width: '100%', textAlign: 'left',
          background: 'none', border: 'none', cursor: 'pointer',
          padding: '14px 16px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10,
          color: open ? 'var(--brand)' : 'var(--text-1)',
        }}
      >
        <span style={{
          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14,
          lineHeight: 1.4,
        }}>{q}</span>
        <ChevronIcon open={open} />
      </button>
      {open && (
        <div className="fade-up" style={{
          padding: '0 16px 14px',
          fontSize: 13, color: 'var(--text-2)', lineHeight: 1.65,
          fontFamily: 'var(--font-display)', fontWeight: 500,
        }}>
          {a}
        </div>
      )}
    </div>
  );
}

export default function FAQSection() {
  const [openIdx, setOpenIdx] = useState(null);

  return (
    <div
      style={{ padding: '28px 20px 20px' }}
      // structured data for SEO
      itemScope itemType="https://schema.org/FAQPage"
    >
      <p style={{
        fontSize: 11, fontWeight: 800, letterSpacing: 1.2, textTransform: 'uppercase',
        color: 'var(--brand)', marginBottom: 6, fontFamily: 'var(--font-display)',
      }}>FAQ</p>
      <h2 style={{
        fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22,
        marginBottom: 18, color: 'var(--text-1)',
        letterSpacing: '-0.4px',
      }}>
        Common Sawaalaat
      </h2>

      {FAQS.map((item, i) => (
        <div key={i} itemScope itemProp="mainEntity" itemType="https://schema.org/Question">
          <meta itemProp="name" content={item.q} />
          <div itemScope itemProp="acceptedAnswer" itemType="https://schema.org/Answer">
            <meta itemProp="text" content={item.a} />
          </div>
          <FAQItem
            q={item.q}
            a={item.a}
            open={openIdx === i}
            onToggle={() => setOpenIdx(openIdx === i ? null : i)}
          />
        </div>
      ))}
    </div>
  );
}
