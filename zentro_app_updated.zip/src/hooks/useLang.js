import { useState } from 'react';

// ── Shared language hook ───────────────────────────────────────────────────────
// Persists choice in localStorage so it survives app restarts.
// Usage: const { lang, toggleLang, LangToggleBtn } = useLang();
// Drop <LangToggleBtn /> anywhere in the topnav.

export default function useLang() {
  const [lang, setLang] = useState(() => localStorage.getItem('zentro_lang') || 'en');

  const toggleLang = () => {
    const next = lang === 'en' ? 'ur' : 'en';
    setLang(next);
    localStorage.setItem('zentro_lang', next);
  };

  function LangToggleBtn({ style = {} }) {
    return (
      <button
        onClick={toggleLang}
        title={lang === 'en' ? 'Roman Urdu mein switch karo' : 'Switch to English'}
        style={{
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          borderRadius: '50%', width: 36, height: 36,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          cursor: 'pointer', flexShrink: 0, ...style,
        }}
      >
        {lang === 'en' ? (
          // Show Urdu chars when in English mode (tap to go Urdu)
          <svg width="20" height="20" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <text x="2" y="20" fontFamily="serif" fontSize="18" fill="var(--text-2)" fontWeight="bold">ا</text>
            <text x="14" y="20" fontFamily="serif" fontSize="11" fill="var(--brand)" fontWeight="bold">ر</text>
          </svg>
        ) : (
          // Show EN when in Urdu mode (tap to go English)
          <svg width="20" height="20" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
            <text x="1" y="19" fontFamily="sans-serif" fontSize="13" fill="var(--text-2)" fontWeight="bold">EN</text>
          </svg>
        )}
      </button>
    );
  }

  return { lang, toggleLang, LangToggleBtn };
}
