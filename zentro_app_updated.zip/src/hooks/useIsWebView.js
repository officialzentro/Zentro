// useIsWebView — returns true when running inside Appilix WebView APK
// Detection: URL param ?apk=1  OR  user-agent contains "Appilix" / "wv"
// Barbers/customers in the native APK wrapper don't need FAQ or social follow prompts.

let _cached = null;

export default function useIsWebView() {
  if (_cached !== null) return _cached;
  const params = new URLSearchParams(window.location.search);
  if (params.get('apk') === '1') { _cached = true; return true; }
  const ua = navigator.userAgent || '';
  // Appilix injects its own UA string; also match Android WebView signature
  if (/Appilix|wv\)/.test(ua)) { _cached = true; return true; }
  _cached = false;
  return false;
}
