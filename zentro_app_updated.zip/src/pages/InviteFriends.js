import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { Users, Tag, CheckCircle, Sparkle, Check } from '../lib/icons';
import {
  getOrCreateReferralCode,
  fetchMyReferrals,
  buildInviteLink,
  copyToClipboard,
} from '../lib/referrals';

// ── Inline share sheet ─────────────────────────────────────────────────────────
function ShareSheet({ link, text, onClose }) {
  const encoded = encodeURIComponent(link);
  const encodedText = encodeURIComponent(text + '\n' + link);

  const options = [
    {
      label: 'WhatsApp',
      color: '#25D366',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
        </svg>
      ),
      href: `https://wa.me/?text=${encodedText}`,
    },
    {
      label: 'SMS',
      color: '#0080FF',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
      ),
      href: `sms:?body=${encodedText}`,
    },
    {
      label: 'Telegram',
      color: '#2AABEE',
      icon: (
        <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
          <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
        </svg>
      ),
      href: `https://t.me/share/url?url=${encoded}&text=${encodeURIComponent(text)}`,
    },
  ];

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 999,
      background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'flex-end',
    }} onClick={onClose}>
      <div
        onClick={e => e.stopPropagation()}
        style={{
          width: '100%', background: 'var(--bg-card)',
          borderRadius: '20px 20px 0 0', padding: '20px 20px 36px',
          boxShadow: '0 -8px 40px rgba(0,0,0,0.35)',
        }}
      >
        <div style={{ width: 40, height: 4, borderRadius: 2, background: 'var(--border)', margin: '0 auto 18px' }} />
        <p style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, marginBottom: 18, textAlign: 'center' }}>
          Share Your Invite
        </p>
        <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: 20 }}>
          {options.map(opt => (
            <a
              key={opt.label}
              href={opt.href}
              target="_blank"
              rel="noopener noreferrer"
              style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, textDecoration: 'none' }}
            >
              <div style={{
                width: 56, height: 56, borderRadius: 16,
                background: opt.color + '20', color: opt.color,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {opt.icon}
              </div>
              <span style={{ fontSize: 11, fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--text-2)' }}>{opt.label}</span>
            </a>
          ))}
        </div>
        {/* Copy link row */}
        <CopyLinkRow link={link} />
        <button onClick={onClose} style={{ width: '100%', marginTop: 14, padding: '12px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-2)', cursor: 'pointer' }}>
          Cancel
        </button>
      </div>
    </div>
  );
}

function CopyLinkRow({ link }) {
  const [copied, setCopied] = useState(false);
  const handle = async () => {
    await copyToClipboard(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };
  return (
    <div style={{ display: 'flex', gap: 10, alignItems: 'center', background: 'var(--bg-input)', borderRadius: 'var(--radius-sm)', padding: '10px 14px' }}>
      <span style={{ flex: 1, fontSize: 12, color: 'var(--text-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{link}</span>
      <button onClick={handle} style={{ flexShrink: 0, background: copied ? 'var(--success)' : 'var(--brand)', border: 'none', borderRadius: 8, padding: '7px 14px', cursor: 'pointer', color: '#fff', fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700, display: 'flex', alignItems: 'center', gap: 4 }}>
        {copied ? <><Check size={13} color="#fff" /> Copied</> : 'Copy'}
      </button>
    </div>
  );
}

const STEPS = [
  { title: '1. Code ya Link Share Karo', body: 'Apna unique code ya invite link WhatsApp pe bhejo ya kisi ko bhi.' },
  { title: '2. Dost Account Banaye',     body: 'Woh tera code use kar ke Zentro pe free account banaye.' },
  { title: '3. Reward Mile!',            body: 'Dost join kare toh tujhe reward milega — barbers ko free subscription days!' },
];

export default function InviteFriends() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [code, setCode]           = useState(null);
  const [referrals, setReferrals] = useState([]);
  const [loading, setLoading]     = useState(true);
  const [copied, setCopied]       = useState(false);
  const [showShareSheet, setShowShareSheet] = useState(false);

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    load();
  }, [user, authReady]); // eslint-disable-line

  const load = async () => {
    setLoading(true);
    const [codeRow, refs] = await Promise.all([
      getOrCreateReferralCode(user.id),
      fetchMyReferrals(user.id),
    ]);
    setCode(codeRow || null);
    setReferrals(refs);
    setLoading(false);
  };

  const handleCopyCode = async () => {
    if (!code) return;
    const ok = await copyToClipboard(code);
    if (ok) {
      setCopied(true);
      showToast('success', 'Code copied!');
      setTimeout(() => setCopied(false), 1800);
    } else {
      showToast('error', 'Could not copy — long-press to select instead');
    }
  };

  const handleCopyLink = async () => {
    if (!code) return;
    const ok = await copyToClipboard(buildInviteLink(code));
    if (ok) showToast('success', 'Invite link copied!');
    else showToast('error', 'Could not copy link');
  };

  const handleShare = async () => {
    if (!code) return;
    const link = buildInviteLink(code);
    const shareText = `Yaar, Zentro try karo! Apne barber ko online book karo. Mera code use karo: ${code}`;
    const ua = navigator.userAgent || '';
    const isWebView = /wv/.test(ua) || typeof window.Android !== 'undefined' || (/android/i.test(ua) && !/chrome\/[.0-9]* mobile/i.test(ua));
    // Skip native share in WebView — it silently drops the URL or does nothing.
    // Always use our custom sheet so WhatsApp/Telegram/SMS links work correctly.
    if (!isWebView && navigator.share) {
      try {
        await navigator.share({ title: 'Join Zentro', text: shareText + '\n' + link });
        return;
      } catch {} // user cancelled — fall through
    }
    setShowShareSheet(true);
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  return (
    <div className="page">
      {ToastEl}
      {showShareSheet && (
        <ShareSheet
          link={buildInviteLink(code)}
          text={`Yaar, Zentro try karo! Apne barber ko online book karo. Mera code use karo: ${code}`}
          onClose={() => setShowShareSheet(false)}
        />
      )}
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
        <span className="page-title">Invite Friends</span>
      </div>

      <div className="page-inner page-enter" style={{ paddingTop: 20 }}>

        {/* ── Hero ── */}
        <div className="invite-hero">
          <div className="invite-hero-icon">
            <Users size={26} color="#fff" />
          </div>
          <h2 style={{ fontSize: 20, marginBottom: 6 }}>Dost ko bulao, reward kamao!</h2>
          <p style={{ color: 'var(--text-2)', fontSize: 13.5, lineHeight: 1.55, maxWidth: 290, margin: '0 auto' }}>
            Apna code share karo. Dost join kare toh <b style={{ color: 'var(--brand)' }}>tumhein free subscription days</b> milenge!
          </p>

          {/* Code display */}
          <div style={{
            marginTop: 18, marginBottom: 4,
            background: 'rgba(0,128,255,0.08)',
            border: '1.5px dashed var(--brand)',
            borderRadius: 16, padding: '14px 18px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12,
          }}>
            <div>
              <div style={{ fontSize: 10, fontWeight: 700, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 4 }}>Tera Referral Code</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 28, color: 'var(--brand)', letterSpacing: 3 }}>
                {code || '——'}
              </div>
            </div>
            <button
              onClick={handleCopyCode}
              style={{
                flexShrink: 0,
                background: copied ? '#22c55e' : 'var(--brand)',
                border: 'none', borderRadius: 12,
                padding: '10px 18px', cursor: 'pointer',
                color: '#fff', fontSize: 13,
                fontFamily: 'var(--font-display)', fontWeight: 800,
                display: 'flex', alignItems: 'center', gap: 6,
                transition: 'background 0.2s',
              }}
            >
              {copied ? <CheckCircle size={15} color="#fff" /> : <Tag size={15} color="#fff" />}
              {copied ? 'Copy Ho Gaya!' : 'Copy Karo'}
            </button>
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 10 }}>
            <button
              className="btn btn-secondary btn-sm"
              style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, whiteSpace: 'nowrap' }}
              onClick={handleCopyLink}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/>
                <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>
              </svg>
              Link Copy Karo
            </button>
            <button
              className="btn btn-primary btn-sm"
              style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, whiteSpace: 'nowrap' }}
              onClick={handleShare}
            >
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
                <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
                <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
              </svg>
              Share Karo
            </button>
          </div>
        </div>

        {/* ── How it works ── */}
        <p className="section-label" style={{ marginTop: 28 }}>How It Works</p>
        <div className="accent-line-animated" />
        <div className="card">
          {STEPS.map((s, i) => (
            <div key={s.title} className="ref-step" style={{ borderBottom: i < STEPS.length - 1 ? '1px solid var(--border)' : 'none' }}>
              <div className="ref-step-num">{i + 1}</div>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, marginBottom: 2 }}>{s.title}</div>
                <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.45 }}>{s.body}</div>
              </div>
            </div>
          ))}
        </div>

        {/* ── Referral history ── */}
        <p className="section-label" style={{ marginTop: 28 }}>Your Invites</p>
        <div className="accent-line-animated" />
        {referrals.length === 0 ? (
          <div className="empty-state" style={{ padding: '36px 20px' }}>
            <div className="empty-icon"><Sparkle size={32} color="var(--text-3)" /></div>
            <div className="empty-title" style={{ fontSize: 16 }}>No invites yet</div>
            <div className="empty-sub">Share your code above to start earning credits</div>
          </div>
        ) : (
          <div className="card" style={{ padding: '6px 16px' }}>
            {referrals.map((r, i) => (
              <div key={r.id} className="ref-row stagger-in" style={{ animationDelay: `${i * 0.04}s` }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
                  <div className="ref-row-avatar">
                    {(r.referee?.full_name || r.referee?.email || '?')[0].toUpperCase()}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 13.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 160 }}>
                      {r.referee?.full_name || r.referee?.email || 'Friend'}
                    </div>
                    <div style={{ fontSize: 11.5, color: 'var(--text-3)' }}>
                      {new Date(r.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })}
                    </div>
                  </div>
                </div>
                <span className={`badge ${r.status === 'rewarded' ? 'badge-success' : r.status === 'voided' ? 'badge-error' : 'badge-warning'}`}>
                  {r.status === 'rewarded' ? 'Earned' : r.status === 'voided' ? 'Voided' : 'Pending'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
      <div style={{ height: 40 }} />
    </div>
  );
}
