import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useToast } from '../hooks/useToast';
import { User, Scissors, Tag, Sparkle } from '../lib/icons';
import { redeemReferralCode } from '../lib/referrals';

export default function Register() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { showToast, ToastEl } = useToast();
  const [name, setName]   = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass]   = useState('');
  const [role, setRole]   = useState('customer');
  const [gender, setGender] = useState('male');
  const [refCode, setRefCode] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const ref = searchParams.get('ref');
    if (ref) setRefCode(ref.toUpperCase());
  }, [searchParams]);

  const submit = async () => {
    if (!name || !email || !pass) return showToast('error', 'Fill in all fields');
    if (pass.length < 6) return showToast('error', 'Password must be 6+ characters');
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({ email, password: pass });
    if (error) { setLoading(false); return showToast('error', error.message); }
    const uid = data.user?.id;
    if (uid) {
      const { error: profileError } = await supabase.from('profiles').insert({ id: uid, full_name: name, email, role, gender });
      if (profileError) console.error('[DB] profile insert error:', profileError);

      if (refCode.trim()) {
        const { error: refError } = await redeemReferralCode(refCode, uid);
        if (refError) {
          // Don't fail the signup over an invalid code — just let them know.
          showToast('error', 'Account created, but referral code was invalid');
        }
      }
    }
    setLoading(false);
    showToast('success', 'Account created!');
    setTimeout(() => navigate('/'), 1000);
  };

  return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px', maxWidth: 480, margin: '0 auto' }}>
      {ToastEl}

      <div style={{ marginBottom: 36 }} className="fade-up">
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 34, letterSpacing: -0.5, marginBottom: 8 }}>
          Join<span style={{ color: 'var(--brand)' }}>Zentro</span>
        </div>
        <p style={{ color: 'var(--text-2)', fontSize: 15 }}>Create your account</p>
      </div>

      <div className="fade-up" style={{ animationDelay: '0.08s' }}>
        {/* Role selector — styled like JSX reference */}
        <div style={{ marginBottom: 20 }}>
          <div className="input-label" style={{ marginBottom: 8 }}>I am a</div>
          <div style={{ display: 'flex', gap: 8 }}>
            {[
              { value: 'customer', label: 'Customer', icon: <User size={16} /> },
              { value: 'barber',   label: 'Barber',   icon: <Scissors size={16} /> },
            ].map(r => (
              <button key={r.value} onClick={() => setRole(r.value)} style={{
                flex: 1, padding: '12px', borderRadius: 14,
                border: `1.5px solid ${role === r.value ? 'var(--brand)' : 'var(--border-strong)'}`,
                background: role === r.value ? 'var(--brand-glow)' : 'var(--bg-input)',
                color: role === r.value ? 'var(--brand)' : 'var(--text-2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer', fontSize: 14,
              }}>
                {r.icon} {r.label}
              </button>
            ))}
          </div>
        </div>

        <div className="input-group">
          <label className="input-label">Full Name</label>
          <input className="input" placeholder="Your name" value={name} onChange={e => setName(e.target.value)} />
        </div>
        <div className="input-group">
          <label className="input-label">Email</label>
          <input className="input" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
        </div>
        <div className="input-group">
          <label className="input-label">Password</label>
          <input className="input" type="password" placeholder="Min 6 characters" value={pass} onChange={e => setPass(e.target.value)} />
        </div>

        <div className="input-group">
          <label className="input-label">Gender</label>
          <div style={{ display: 'flex', gap: 8 }}>
            {[
              { value: 'male', label: 'Male', icon: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="10" cy="14" r="6"/><line x1="14.5" y1="9.5" x2="20" y2="4"/><polyline points="16 4 20 4 20 8"/>
                </svg>
              )},
              { value: 'female', label: 'Female', icon: (
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="8" r="6"/><line x1="12" y1="14" x2="12" y2="20"/><line x1="9" y1="17" x2="15" y2="17"/>
                </svg>
              )},
            ].map(g => (
              <button key={g.value} onClick={() => setGender(g.value)} style={{
                flex: 1, padding: '12px', borderRadius: 14,
                border: `1.5px solid ${gender === g.value ? 'var(--brand)' : 'var(--border-strong)'}`,
                background: gender === g.value ? 'var(--brand-glow)' : 'var(--bg-input)',
                color: gender === g.value ? 'var(--brand)' : 'var(--text-2)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer', fontSize: 14,
              }}>
                {g.icon} {g.label}
              </button>
            ))}
          </div>
        </div>

        <div className="input-group">
          <label className="input-label">Referral Code <span style={{ color: 'var(--text-3)', textTransform: 'none', fontWeight: 500 }}>(optional)</span></label>
          <div style={{ position: 'relative' }}>
            <span style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
              <Tag size={15} color="var(--text-3)" />
            </span>
            <input
              className="input"
              placeholder="e.g. ZC746D02"
              value={refCode}
              onChange={e => setRefCode(e.target.value.toUpperCase())}
              style={{ paddingLeft: 38, textTransform: 'uppercase' }}
            />
          </div>
          {refCode && (
            <span style={{ fontSize: 12, color: 'var(--brand)', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 5 }}>
              You and your friend will both get rewarded once you complete your first booking
              <Sparkle size={13} color="var(--brand)" style={{ flexShrink: 0 }} />
            </span>
          )}
        </div>

        <button className="btn btn-primary" onClick={submit} disabled={loading} style={{ marginTop: 8 }}>
          {loading ? <span className="spinner spinner-sm" style={{ borderTopColor: '#fff' }} /> : 'Create Account'}
        </button>

        <p style={{ textAlign: 'center', marginTop: 28, color: 'var(--text-2)', fontSize: 14 }}>
          Already have an account?{' '}
          <Link to="/login" style={{ color: 'var(--brand)', fontWeight: 700 }}>Sign In</Link>
        </p>
      </div>
    </div>
  );
}
