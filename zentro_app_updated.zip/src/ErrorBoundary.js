import { Component } from 'react';

export class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{
          padding: 24, fontFamily: 'monospace', fontSize: 13,
          background: '#1a0000', color: '#ff6b6b', minHeight: '100dvh',
          whiteSpace: 'pre-wrap', wordBreak: 'break-all',
        }}>
          <b>Crash in: {this.props.name}</b>{'\n\n'}
          {this.state.error?.message}{'\n\n'}
          {this.state.error?.stack}
        </div>
      );
    }
    return this.props.children;
  }
}
