import { useEffect, useState } from 'react';
import { fetchBarberWalletBalance } from '../lib/wallet';
import { fetchMyCredits } from '../lib/referrals';

const WalletIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>
  </svg>
);

const GiftIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/>
    <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
  </svg>
);

const ArrowDownIcon = () => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>
  </svg>
);

// Barber Zentro Wallet Card — shows credits received from customers + referral rewards
export default function WalletCard({ userId, mode }) {
  const [balance, setBalance]       = useState(0);
  const [referralCredits, setReferralCredits] = useState(0);
  const [loading, setLoading]       = useState(true);

  useEffect(() => {
    if (!userId) return;
    if (mode === 'barber') {
      Promise.all([
        fetchBarberWalletBalance(userId),
        fetchMyCredits(userId),
      ]).then(([bal, creditData]) => {
        setBalance(bal);
        // referral credits stored as subscription_days kind — treat amount as Rs value now
        setReferralCredits(creditData.subscriptionDaysTotal || 0);
        setLoading(false);
      });
    } else {
      setLoading(false);
    }
  }, [userId, mode]);

  if (loading) {
    return <div className="skeleton" style={{ height: 96, borderRadius: 'var(--radius)' }} />;
  }

  if (mode !== 'barber') return null;

  const total = balance + referralCredits;

  if (total === 0) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '24px 16px' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 8 }}>
          <GiftIcon />
        </div>
        <div style={{ fontWeight: 700, fontSize: 14.5, marginBottom: 2 }}>No credits yet</div>
        <div style={{ fontSize: 12.5, color: 'var(--text-2)' }}>Credits from customers and referrals will appear here</div>
      </div>
    );
  }

  return (
    <div>
      <div className="wallet-card" style={{
        background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
        boxShadow: '0 8px 28px rgba(99,102,241,0.28)',
        position: 'relative', overflow: 'hidden',
      }}>
        {/* Background glow */}
        <div style={{
          position: 'absolute', top: -20, right: -20, width: 100, height: 100,
          borderRadius: '50%', background: 'rgba(99,102,241,0.2)', filter: 'blur(24px)',
        }} />
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, opacity: 0.85 }}>
          <WalletIcon />
          <span style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6, color: '#fff' }}>Zentro Wallet</span>
        </div>
        <div className="wallet-amount" style={{ color: '#fff', fontSize: 32, fontWeight: 900 }}>
          Rs {total.toLocaleString()}
        </div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', marginTop: 4 }}>
          Use at checkout to get discount on subscription
        </div>
      </div>

      {(balance > 0 || referralCredits > 0) && (
        <div className="card" style={{ padding: '12px 16px', marginTop: 10 }}>
          {balance > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0', borderBottom: referralCredits > 0 ? '1px solid var(--border)' : 'none' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ color: 'var(--brand)' }}><ArrowDownIcon /></span>
                <span style={{ fontSize: 13, color: 'var(--text-2)', fontWeight: 600 }}>From customers</span>
              </div>
              <span style={{ fontWeight: 800, fontSize: 13, color: 'var(--text-1)' }}>Rs {balance.toLocaleString()}</span>
            </div>
          )}
          {referralCredits > 0 && (
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '6px 0' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ color: '#CC8E00' }}>
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/>
                    <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
                  </svg>
                </span>
                <span style={{ fontSize: 13, color: 'var(--text-2)', fontWeight: 600 }}>Referral rewards</span>
              </div>
              <span style={{ fontWeight: 800, fontSize: 13, color: '#CC8E00' }}>Rs {referralCredits.toLocaleString()}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
