-- ════════════════════════════════════════════════════════════════
-- Zentro Wallet + Shop Upgrades — Supabase SQL Migration
-- Run this in your Supabase SQL Editor
-- ════════════════════════════════════════════════════════════════

-- ── 1. wallet_transactions table ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wallet_transactions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user_id    uuid REFERENCES profiles(id) ON DELETE SET NULL,
  to_user_id      uuid REFERENCES profiles(id) ON DELETE SET NULL,
  type            text NOT NULL CHECK (type IN ('transfer', 'barber_payment', 'referral', 'admin_grant')),
  amount          numeric(10,2) NOT NULL CHECK (amount > 0),
  note            text,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_wallet_tx_from ON wallet_transactions(from_user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_tx_to   ON wallet_transactions(to_user_id);

ALTER TABLE wallet_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "wallet_tx_select_own"
  ON wallet_transactions FOR SELECT
  USING (auth.uid() = from_user_id OR auth.uid() = to_user_id);

CREATE POLICY "wallet_tx_insert_own"
  ON wallet_transactions FOR INSERT
  WITH CHECK (auth.uid() = from_user_id);

-- ── 2. shops table — new columns ─────────────────────────────────────────────
-- Gender type: 'men' | 'women' | 'both'
ALTER TABLE shops
  ADD COLUMN IF NOT EXISTS gender_type text NOT NULL DEFAULT 'men'
    CHECK (gender_type IN ('men', 'women', 'both'));

-- Home service: 'salon_only' | 'home_only' | 'both'
ALTER TABLE shops
  ADD COLUMN IF NOT EXISTS home_service text NOT NULL DEFAULT 'salon_only'
    CHECK (home_service IN ('salon_only', 'home_only', 'both'));

-- Extra fee charged for home visits (nullable = no extra fee)
ALTER TABLE shops
  ADD COLUMN IF NOT EXISTS home_fee numeric(10,2) DEFAULT NULL;

-- ── 3. bookings table — new columns ──────────────────────────────────────────
-- Where the customer wants the service
ALTER TABLE bookings
  ADD COLUMN IF NOT EXISTS booking_location text NOT NULL DEFAULT 'salon'
    CHECK (booking_location IN ('salon', 'home'));

-- Home fee that was applied at booking time (snapshot, not live)
ALTER TABLE bookings
  ADD COLUMN IF NOT EXISTS home_fee_applied numeric(10,2) DEFAULT NULL;

-- ── 4. Admin setting: credits → subscription days conversion rate ──────────
INSERT INTO app_settings (key, value)
VALUES ('credits_to_sub_days_rate', '100')
ON CONFLICT (key) DO NOTHING;

-- ── 5. Admin setting: minimum wallet send amount ────────────────────────────
-- Applies to both "send to friend" and "pay barber via QR" flows.
INSERT INTO app_settings (key, value)
VALUES ('wallet_min_send_amount', '10')
ON CONFLICT (key) DO NOTHING;

-- ════════════════════════════════════════════════════════════════
-- Summary:
--   wallet_transactions   — logs P2P transfers + barber payments
--   shops.gender_type     — men / women / both
--   shops.home_service    — salon_only / home_only / both
--   shops.home_fee        — extra charge for home visits (Rs)
--   bookings.booking_location  — salon / home
--   bookings.home_fee_applied  — fee snapshot at booking time
--   credits_to_sub_days_rate   — Rs 100 = 1 barber sub day (default)
--   wallet_min_send_amount     — Rs 10 minimum send/pay amount (default, admin-editable)
-- ════════════════════════════════════════════════════════════════
