import { useEffect, useRef, useState, useCallback } from 'react';
import SocialBar from '../components/SocialBar';
import { MapPin, Calendar, Bell, StarFilled, Scissors, Gift, Check } from '../lib/icons';

const APK_URL = 'https://apkpure.com/zentro/com.zentro.app/download';

// ── Confetti ──────────────────────────────────────────────────────
const COLORS = ['#0080FF', '#00c6ff', '#ffffff', '#004FC4', '#60b8ff'];
function Confetti({ active, onDone }) {
  const canvasRef = useRef(null);
  const rafRef    = useRef(null);
  useEffect(() => {
    if (!active) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    canvas.width = window.innerWidth; canvas.height = window.innerHeight;
    const pieces = Array.from({ length: 100 }, () => ({
      x: Math.random() * canvas.width, y: -10 - Math.random() * 80,
      w: 6 + Math.random() * 7, h: 3 + Math.random() * 4,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      rot: Math.random() * Math.PI * 2, vx: (Math.random() - 0.5) * 4,
      vy: 3 + Math.random() * 5, vr: (Math.random() - 0.5) * 0.2, opacity: 1,
    }));
    let done = false;
    const tick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      let alive = 0;
      for (const p of pieces) {
        p.x += p.vx; p.y += p.vy; p.rot += p.vr; p.vy += 0.15;
        if (p.y > canvas.height * 0.7) p.opacity -= 0.03;
        if (p.opacity <= 0) continue; alive++;
        ctx.save(); ctx.globalAlpha = Math.max(0, p.opacity);
        ctx.translate(p.x, p.y); ctx.rotate(p.rot);
        ctx.fillStyle = p.color; ctx.fillRect(-p.w/2, -p.h/2, p.w, p.h);
        ctx.restore();
      }
      if (alive > 0) rafRef.current = requestAnimationFrame(tick);
      else if (!done) { done = true; onDone?.(); }
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [active, onDone]);
  if (!active) return null;
  return <canvas ref={canvasRef} style={{ position:'fixed', inset:0, zIndex:99999, pointerEvents:'none' }} />;
}

// ── Icons ─────────────────────────────────────────────────────────
const PlayStoreIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
    <path d="M3 20.5v-17c0-.83 1-.83 1.5-.5l15 8.5-15 8.5c-.5.33-1.5.33-1.5-.5z" fill="currentColor"/>
    <path d="M3 3.5L13.5 12 3 20.5" stroke="rgba(255,255,255,0.3)" strokeWidth="0.5"/>
    <path d="M3 3.5l10 8.5" stroke="#4ade80" strokeWidth="0.8"/>
    <path d="M3 20.5l10-8.5" stroke="#f87171" strokeWidth="0.8"/>
    <path d="M13.5 12L18.5 12" stroke="#60a5fa" strokeWidth="0.8"/>
  </svg>
);

const ApkIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="5" y="2" width="14" height="20" rx="2"/><line x1="12" y1="18" x2="12.01" y2="18"/>
  </svg>
);

const SCREENSHOTS = [
  { label: 'Dashboard',  src: '/screenshots/screen1.png' },
  { label: 'Shop Setup', src: '/screenshots/screen2.png' },
  { label: 'Slots',      src: '/screenshots/screen3.png' },
  { label: 'Payment',    src: '/screenshots/screen4.png' },
  { label: 'Wallet',     src: '/screenshots/screen5.png' },
];

const FEATURES = [
  { icon: <MapPin size={26} color="var(--brand)" />,    title: 'Find Nearby Barbers',   desc: 'GPS se apne qareeb best barbers dhundo' },
  { icon: <Calendar size={26} color="var(--brand)" />,  title: 'Online Booking',         desc: 'Slot choose karo, confirm karo — koi call nahi' },
  { icon: <Bell size={26} color="var(--brand)" />,      title: 'Real-time Alerts',       desc: 'Booking confirm hote hi notification milti hai' },
  { icon: <StarFilled size={26} />,                     title: 'Ratings & Reviews',      desc: 'Best barbers asaani se identify karo' },
  { icon: <Scissors size={26} color="var(--brand)" />,  title: 'Barber Dashboard',       desc: 'Appointments, slots, earnings — sab ek jagah' },
  { icon: <Gift size={26} color="var(--brand)" />,      title: 'Free for Customers',     desc: 'Customers ke liye bilkul free — hamesha' },
];

export default function Download() {
  const [confetti, setConfetti]   = useState(false);
  const [pwaDone, setPwaDone]     = useState(false);
  const [pwaReady, setPwaReady]   = useState(false);
  const [installing, setInstalling] = useState(false);

  useEffect(() => {
    // Check if PWA prompt is already stored
    if (window.__pwaInstallPrompt) setPwaReady(true);
    const handler = () => setPwaReady(true);
    window.addEventListener('pwaPromptReady', handler);
    // Poll briefly in case it fires slightly after mount
    const t = setTimeout(() => { if (window.__pwaInstallPrompt) setPwaReady(true); }, 1000);
    return () => { window.removeEventListener('pwaPromptReady', handler); clearTimeout(t); };
  }, []);

  const handleAPK = useCallback(() => {
    window.open(APK_URL, '_blank', 'noopener,noreferrer');
    setConfetti(true);
  }, []);

  const handlePWA = useCallback(async () => {
    if (pwaDone) return;
    setInstalling(true);
    if (window.triggerPWAInstall) {
      const accepted = await window.triggerPWAInstall();
      if (accepted) { setPwaDone(true); setConfetti(true); }
    } else {
      // Fallback: if already installed or prompt unavailable
      alert('App already installed or open this page in Chrome to install.');
    }
    setInstalling(false);
  }, [pwaDone]);

  return (
    <div style={s.page}>
      <Confetti active={confetti} onDone={() => setConfetti(false)} />

      {/* ── Hero ── */}
      <section style={s.hero}>
        <div style={s.badge}>
          <span style={{ width:8, height:8, borderRadius:'50%', background:'#4ade80', display:'inline-block' }}/>
          Pakistan Ka #1 Barber Booking App
        </div>

        <div style={s.logoRow}>
          <img src="/zentro_icon.svg" alt="Zentro" style={{ width:56, height:56, borderRadius:16 }} />
          <div>
            <div style={s.appName}>Zentro</div>
            <div style={s.appTagline}>Book Your Barber Online</div>
          </div>
        </div>

        <div style={s.ratingRow}>
          {[0,1,2,3,4].map(i => <StarFilled key={i} size={16} color="#FFB800" />)}
          <span style={{ color:'rgba(255,255,255,0.5)', fontSize:13, marginLeft:6 }}>4.8 • Free</span>
        </div>

        {/* ── Download Buttons ── */}
        <div style={s.btnGroup}>
          {/* Play Store button → triggers PWA install */}
          <button style={s.playBtn} className="tap-feedback" onClick={handlePWA} disabled={installing}>
            <PlayStoreIcon />
            <div style={{ textAlign:'left' }}>
              <div style={{ fontSize:10, opacity:0.75, lineHeight:1 }}>GET IT ON</div>
              <div style={{ fontSize:16, fontWeight:800, fontFamily:'var(--font-display)', lineHeight:1.2, display: pwaDone && !installing ? 'flex' : 'block', alignItems: 'center', gap: 5 }}>
                {installing ? 'Installing…' : pwaDone ? <><Check size={14} /> Installed!</> : 'Google Play'}
              </div>
            </div>
          </button>

          {/* APKPure */}
          <button style={s.apkBtn} className="tap-feedback" onClick={handleAPK}>
            <ApkIcon />
            <div style={{ textAlign:'left' }}>
              <div style={{ fontSize:10, opacity:0.75, lineHeight:1 }}>DOWNLOAD FROM</div>
              <div style={{ fontSize:16, fontWeight:800, fontFamily:'var(--font-display)', lineHeight:1.2 }}>APKPure</div>
            </div>
          </button>
        </div>

        <p style={s.heroNote}>Android 5.0+ • Free • No ads</p>
      </section>

      {/* ── Screenshots ── */}
      <section style={s.section}>
        <h2 style={s.sectionTitle}>App Screenshots</h2>
        <div style={s.screenshotRow}>
          {SCREENSHOTS.map((sc, i) => (
            <div key={i} style={s.screenshotCard}>
              <div style={s.phoneFrame}>
                {/* Phone notch */}
                <div style={s.notch} />
                <img src={sc.src} alt={sc.label} style={s.screenshotImg}
                  onError={e => { e.target.style.background='#0a1220'; e.target.src=''; }} />
              </div>
              <span style={s.screenshotLabel}>{sc.label}</span>
            </div>
          ))}
        </div>
        <p style={s.scrollHint}>swipe to see more →</p>
      </section>

      {/* ── Features ── */}
      <section style={s.section}>
        <h2 style={s.sectionTitle}>Kya Milega Zentro Mein?</h2>
        <div style={s.featuresGrid}>
          {FEATURES.map((f, i) => (
            <div key={i} style={s.featureCard} className="tap-feedback">
              <div style={s.featureEmoji}>{f.icon}</div>
              <div>
                <div style={s.featureTitle}>{f.title}</div>
                <div style={s.featureDesc}>{f.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Bottom CTA ── */}
      <section style={s.cta}>
        <h3 style={s.ctaTitle}>Abhi Download Karo — <span style={{ color:'#0080FF' }}>FREE!</span></h3>
        <p style={s.ctaSub}>Koi subscription nahi, koi hidden charges nahi</p>
        <div style={{ ...s.btnGroup, justifyContent:'center' }}>
          <button style={s.playBtn} className="tap-feedback" onClick={handlePWA} disabled={installing}>
            <PlayStoreIcon />
            <div style={{ textAlign:'left' }}>
              <div style={{ fontSize:10, opacity:0.75, lineHeight:1 }}>GET IT ON</div>
              <div style={{ fontSize:15, fontWeight:800, fontFamily:'var(--font-display)', lineHeight:1.2, display: pwaDone ? 'flex' : 'block', alignItems: 'center', gap: 5 }}>
                {pwaDone ? <><Check size={13} /> Installed!</> : 'Google Play'}
              </div>
            </div>
          </button>
          <button style={s.apkBtn} className="tap-feedback" onClick={handleAPK}>
            <ApkIcon />
            <div style={{ textAlign:'left' }}>
              <div style={{ fontSize:10, opacity:0.75, lineHeight:1 }}>DOWNLOAD FROM</div>
              <div style={{ fontSize:15, fontWeight:800, fontFamily:'var(--font-display)', lineHeight:1.2 }}>APKPure</div>
            </div>
          </button>
        </div>
      </section>

      {/* ── Social ── */}
      <section style={{ padding:'24px 24px 40px', textAlign:'center' }}>
        <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:16, justifyContent:'center' }}>
          <div style={{ height:1, width:40, background:'var(--border)' }} />
          <span style={{ fontSize:11, fontWeight:800, letterSpacing:1.4, textTransform:'uppercase', color:'var(--text-3)', fontFamily:'var(--font-display)' }}>Follow Zentro</span>
          <div style={{ height:1, width:40, background:'var(--border)' }} />
        </div>
        <SocialBar />
      </section>
    </div>
  );
}

const s = {
  page: { minHeight:'100vh', background:'var(--bg)', paddingBottom:80, fontFamily:'var(--font-body)' },
  hero: {
    background:'linear-gradient(160deg, #060E1E 0%, #091525 65%, #0a1a35 100%)',
    padding:'52px 24px 44px', textAlign:'center',
    display:'flex', flexDirection:'column', alignItems:'center', gap:16,
  },
  badge: {
    display:'inline-flex', alignItems:'center', gap:7,
    background:'rgba(0,128,255,0.12)', border:'1px solid rgba(0,128,255,0.25)',
    borderRadius:40, padding:'5px 14px', fontSize:12,
    color:'rgba(255,255,255,0.75)', fontFamily:'var(--font-display)', letterSpacing:0.3,
  },
  logoRow: {
    display:'flex', alignItems:'center', gap:14,
  },
  appName: {
    fontFamily:'var(--font-display)', fontWeight:900, fontSize:32, color:'#fff', lineHeight:1,
  },
  appTagline: {
    fontSize:13, color:'rgba(255,255,255,0.5)', marginTop:3,
  },
  ratingRow: { display:'flex', alignItems:'center', gap:2 },
  btnGroup: {
    display:'flex', gap:12, flexWrap:'wrap', justifyContent:'center', width:'100%', maxWidth:380,
  },
  playBtn: {
    flex:1, minWidth:150, display:'flex', alignItems:'center', gap:12,
    background:'#1a1a2e', border:'1.5px solid rgba(255,255,255,0.15)',
    borderRadius:14, padding:'12px 18px', cursor:'pointer', color:'#fff',
    transition:'all 0.15s', boxShadow:'0 4px 20px rgba(0,0,0,0.3)',
  },
  apkBtn: {
    flex:1, minWidth:150, display:'flex', alignItems:'center', gap:12,
    background:'rgba(0,128,255,0.12)', border:'1.5px solid rgba(0,128,255,0.3)',
    borderRadius:14, padding:'12px 18px', cursor:'pointer', color:'#fff',
    transition:'all 0.15s', boxShadow:'0 4px 20px rgba(0,128,255,0.15)',
  },
  heroNote: { color:'rgba(255,255,255,0.3)', fontSize:12, marginTop:-4 },
  section: { padding:'36px 20px 12px', maxWidth:600, margin:'0 auto' },
  sectionTitle: {
    fontFamily:'var(--font-display)', fontWeight:800, fontSize:22,
    color:'var(--text-1)', marginBottom:20,
  },
  screenshotRow: {
    display:'flex', gap:14, overflowX:'auto', paddingBottom:12,
    scrollSnapType:'x mandatory', WebkitOverflowScrolling:'touch',
    scrollbarWidth:'none', msOverflowStyle:'none',
  },
  screenshotCard: {
    display:'flex', flexDirection:'column', alignItems:'center', gap:8,
    flexShrink:0, scrollSnapAlign:'start',
  },
  phoneFrame: {
    width:155, height:280, borderRadius:22, overflow:'hidden',
    background:'#0a1220', border:'2.5px solid rgba(0,128,255,0.25)',
    boxShadow:'0 12px 32px rgba(0,0,0,0.35), inset 0 0 0 1px rgba(255,255,255,0.04)',
    position:'relative',
  },
  notch: {
    position:'absolute', top:0, left:'50%', transform:'translateX(-50%)',
    width:60, height:14, background:'#060E1E', borderRadius:'0 0 10px 10px',
    zIndex:2,
  },
  screenshotImg: { width:'100%', height:'100%', objectFit:'cover', display:'block' },
  screenshotLabel: { fontSize:12, color:'var(--text-3)', fontWeight:600 },
  scrollHint: { textAlign:'center', color:'var(--text-3)', fontSize:12, marginTop:4, letterSpacing:0.4 },
  featuresGrid: { display:'flex', flexDirection:'column', gap:12 },
  featureCard: {
    display:'flex', gap:14, alignItems:'flex-start',
    background:'var(--bg-card)', borderRadius:'var(--radius)',
    padding:'14px 16px', border:'1px solid var(--border)',
    boxShadow:'var(--shadow-card)',
  },
  featureEmoji: {
    width:44, height:44, borderRadius:12, background:'rgba(0,128,255,0.08)',
    display:'flex', alignItems:'center', justifyContent:'center',
    fontSize:22, flexShrink:0,
  },
  featureTitle: { fontFamily:'var(--font-display)', fontWeight:700, fontSize:15, color:'var(--text-1)', marginBottom:3 },
  featureDesc: { fontSize:13, color:'var(--text-2)', lineHeight:1.5 },
  cta: {
    padding:'36px 24px', textAlign:'center',
    display:'flex', flexDirection:'column', alignItems:'center', gap:14,
  },
  ctaTitle: { fontFamily:'var(--font-display)', fontWeight:800, fontSize:22, color:'var(--text-1)', lineHeight:1.3 },
  ctaSub: { fontSize:13, color:'var(--text-2)', marginTop:-6 },
};
