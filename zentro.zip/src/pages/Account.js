import { useEffect, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import useTheme from '../hooks/useTheme';
import useIsWebView from '../hooks/useIsWebView';
import { useToast } from '../hooks/useToast';
import { usePlanPerks } from '../hooks/usePlanPerks';
import { format } from 'date-fns';
import { uploadPaymentProof } from '../lib/imageUpload';
import { createPortal } from 'react-dom';
import L from 'leaflet';
import BarberGuide from '../components/BarberGuide';
import { TutorialHomeCard, WatchStepButton } from '../components/TutorialVideo';
import ReminderPrefs from '../components/ReminderPrefs';
import { useOnboarding } from '../components/OnboardingTutorial';
import WalletCard from '../components/WalletCard';
import { getOrCreateReferralCode, buildInviteLink, copyToClipboard, fetchMyReferrals, fetchMyCredits, fetchNotifications, markAllRead, sendNotification, maybeNotifySubscriptionExpiry } from '../lib/referrals';
import { fetchBarberWalletBalance, fetchMinSendAmount } from '../lib/wallet';
import { SendFriendFlow } from './CustomerWallet';
import { Bell, QrCode } from '../lib/icons';
import useLang from '../hooks/useLang';
import { buildQRCanvas, buildPoster } from '../lib/qrArt';

// Set by the Home screen button so the QR card opens by itself on the Bookings screen
let openQROnNextVisit = false;
const openSupportChat = () => window.dispatchEvent(new Event('zentro:open-support'));

// ── SVG Icon set (no basic emojis) ────────────────────────────────────────────
import { Icon, SectionLabel } from './account/shared';
import SetupTab from './account/SetupTab';
import SlotsTab from './account/SlotsTab';
import PushSettingRow from '../components/PushSettingRow';

// -- QR Code --------------------------------------------------------------
// Real Zentro logo, loaded once and reused (same-origin file, so the canvas stays exportable)
let zentroLogoPromise = null;
function loadZentroLogo() {
  if (!zentroLogoPromise) {
    zentroLogoPromise = new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => { zentroLogoPromise = null; resolve(null); };
      img.src = '/zentro_logo.png';
    });
  }
  return zentroLogoPromise;
}

function ZentroQR({ shopId, shopName, size = 240 }) {
  const canvasRef = useRef(null);
  const [qrReady, setQrReady] = useState(false);
  // ?pay=1 opens the credit payment modal when customer scans
  const qrText = shopId ? `https://zentropk.vercel.app/shop/${shopId}?pay=1` : '';

  useEffect(() => {
    if (!shopId) return;
    let cancelled = false;
    setQrReady(false);
    loadZentroLogo().then((logo) => {
      if (cancelled) return;
      const canvas = canvasRef.current;
      if (!canvas) return;
      try {
        const built = buildQRCanvas(qrText, size * 2, logo);
        canvas.width = built.width; canvas.height = built.height;
        canvas.getContext('2d').drawImage(built, 0, 0);
      } catch (e) { /* leave the box empty instead of crashing the page */ }
      setQrReady(true);
    });
    return () => { cancelled = true; };
  }, [shopId, size]); // eslint-disable-line

  const download = async () => {
    // make sure the Sora font is ready so the poster text looks right
    try {
      if (document.fonts && document.fonts.load) {
        await Promise.all([
          document.fonts.load('900 64px Sora'),
          document.fonts.load('700 44px Sora'),
          document.fonts.load('600 26px Sora'),
          document.fonts.load('500 20px Sora'),
        ]);
      }
    } catch (e) { /* ignore, fallback font is used */ }
    const logo = await loadZentroLogo();
    const poster = buildPoster({ text: qrText, shopName, logoImg: logo });
    const link = document.createElement('a');
    link.download = `zentro-qr-${(shopName || 'shop').replace(/\s+/g, '-').toLowerCase()}.png`;
    link.href = poster.toDataURL('image/png');
    link.click();
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
      <div style={{ padding: 16, borderRadius: 26, background: 'linear-gradient(160deg,#0A1428,#050C1C)',
        border: '1px solid rgba(0,128,255,0.35)', boxShadow: '0 12px 32px rgba(0,128,255,0.18)',
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
        <div style={{ padding: 10, background: '#F0F6FF', borderRadius: 18, position: 'relative', lineHeight: 0 }}>
          <canvas ref={canvasRef} style={{ display: 'block', width: size, height: size, borderRadius: 10 }} />
          {!qrReady && (
            <div style={{ position: 'absolute', inset: 10, borderRadius: 10, background: 'var(--bg-input)',
              display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <div className="spinner" />
            </div>
          )}
        </div>
        <div style={{ textAlign: 'center', maxWidth: size + 20 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 17, letterSpacing: 1.5, color: '#FFFFFF' }}>
            SCAN TO BOOK
          </div>
          <div style={{ fontWeight: 700, fontSize: 13, color: '#0080FF', marginTop: 3,
            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {shopName}
          </div>
        </div>
      </div>
      {qrReady && (
        <button className="btn btn-secondary btn-sm" onClick={download}
          style={{ width: 'auto', paddingLeft: 20, paddingRight: 20, display: 'flex', alignItems: 'center', gap: 6 }}>
          {Icon.download()} Download QR
        </button>
      )}
    </div>
  );
}

// ── Stat Card ─────────────────────────────────────────────────────────────────
function StatCard({ label, value, icon }) {
  return (
    <div style={{
      background: 'var(--bg-card)', borderRadius: 16, padding: '16px 12px',
      border: '1px solid var(--border)', textAlign: 'center',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
    }}>
      <div style={{ width: 36, height: 36, borderRadius: 12, background: 'var(--brand-glow)',
        display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</div>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17, color: 'var(--text-1)' }}>{value}</div>
      <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
    </div>
  );
}

// ── Status pill ───────────────────────────────────────────────────────────────
function StatusPill({ status }) {
  const map = {
    pending:   { bg: 'rgba(255,149,0,0.1)',  border: 'rgba(255,149,0,0.25)',  color: 'var(--warning)',  label: 'Pending' },
    confirmed: { bg: 'rgba(0,200,100,0.1)',  border: 'rgba(0,200,100,0.25)', color: 'var(--success)', label: 'Confirmed' },
    completed: { bg: 'rgba(0,128,255,0.1)',  border: 'rgba(0,128,255,0.2)',  color: 'var(--brand)',   label: 'Completed' },
    cancelled: { bg: 'rgba(0,0,0,0.05)',     border: 'rgba(0,0,0,0.1)',      color: 'var(--text-3)',  label: 'Cancelled' },
  };
  const s = map[status] || map.pending;
  return (
    <span style={{ fontSize: 10, fontWeight: 700, fontFamily: 'var(--font-display)',
      color: s.color, background: s.bg, border: `1px solid ${s.border}`,
      padding: '3px 10px', borderRadius: 100, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
      {s.label}
    </span>
  );
}

// ── Dashboard Tab ─────────────────────────────────────────────────────────────
const PLAN_ICONS_DB = {
  basic: (color = '#8EA0BC') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 2l20 20M2 22 12 12 22 2"/><path d="M7 7l10 10"/>
    </svg>
  ),
  pro: (color = '#0080FF') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
    </svg>
  ),
  premium: (color = '#FFB800') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 4l5 8 5-6 5 6 5-8v14H2z"/>
    </svg>
  ),
};
const TIER_COLORS_DB = { basic: '#8EA0BC', pro: '#0080FF', premium: '#FFB800' };
const PLAN_ICONS = PLAN_ICONS_DB;

function SubCountdownDB({ expiresAt }) {
  if (!expiresAt) return null;
  const exp  = new Date(expiresAt);
  const now  = new Date();
  const diff = exp - now;
  const expired = diff <= 0;
  const days = expired ? 0 : Math.ceil(diff / (1000 * 60 * 60 * 24));
  const isUrgent = !expired && days <= 7;
  return (
    <div style={{
      marginTop: 12, padding: '10px 14px', borderRadius: 10,
      background: expired ? 'rgba(255,59,59,0.08)' : isUrgent ? 'rgba(255,149,0,0.08)' : 'rgba(0,128,255,0.06)',
      border: `1px solid ${expired ? 'rgba(255,59,59,0.2)' : isUrgent ? 'rgba(255,149,0,0.25)' : 'rgba(0,128,255,0.15)'}`,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    }}>
      <div>
        <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, color: expired ? 'var(--error)' : isUrgent ? 'var(--warning)' : 'var(--text-3)', marginBottom: 3 }}>
          {expired ? 'Subscription Expired' : 'Subscription Active'}
        </div>
        <div style={{ fontSize: 13, fontWeight: 600, color: expired ? 'var(--error)' : 'var(--text-1)' }}>
          {expired ? 'Renew to continue' : `Expires ${exp.toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}`}
        </div>
      </div>
      {!expired && (
        <div style={{ textAlign: 'center', background: isUrgent ? 'rgba(255,149,0,0.12)' : 'var(--brand-glow)', borderRadius: 10, padding: '6px 12px', minWidth: 54 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: isUrgent ? 'var(--warning)' : 'var(--brand)', lineHeight: 1 }}>{days}</div>
          <div style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', color: isUrgent ? 'var(--warning)' : 'var(--brand)', letterSpacing: 0.5 }}>days left</div>
        </div>
      )}
    </div>
  );
}

// ── Reusable share sheet (WhatsApp / SMS / Telegram fallback for WebViews) ──
function ShareSheet({ link, text, onClose }) {
  const encoded = encodeURIComponent(link);
  const encodedFull = encodeURIComponent(text + '\n' + link);
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    await copyToClipboard(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };
  const options = [
    {
      label: 'WhatsApp', color: '#25D366',
      href: `https://wa.me/?text=${encodedFull}`,
      icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>,
    },
    {
      label: 'SMS', color: '#0080FF',
      href: `sms:?body=${encodedFull}`,
      icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
    },
    {
      label: 'Telegram', color: '#2AABEE',
      href: `https://t.me/share/url?url=${encoded}&text=${encodeURIComponent(text)}`,
      icon: <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>,
    },
  ];
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 999, background: 'rgba(0,0,0,0.55)', display: 'flex', alignItems: 'flex-end' }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ width: '100%', background: 'var(--bg-card)', borderRadius: '20px 20px 0 0', padding: '20px 20px 36px', boxShadow: '0 -8px 40px rgba(0,0,0,0.35)' }}>
        <div style={{ width: 40, height: 4, borderRadius: 2, background: 'var(--border)', margin: '0 auto 18px' }} />
        <p style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, marginBottom: 18, textAlign: 'center' }}>Share Invite Link</p>
        <div style={{ display: 'flex', justifyContent: 'space-around', marginBottom: 20 }}>
          {options.map(opt => (
            <a key={opt.label} href={opt.href} target="_blank" rel="noopener noreferrer" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, textDecoration: 'none' }}>
              <div style={{ width: 56, height: 56, borderRadius: 16, background: opt.color + '20', color: opt.color, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{opt.icon}</div>
              <span style={{ fontSize: 11, fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--text-2)' }}>{opt.label}</span>
            </a>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center', background: 'var(--bg-input)', borderRadius: 'var(--radius-sm)', padding: '10px 14px', marginBottom: 10 }}>
          <span style={{ flex: 1, fontSize: 12, color: 'var(--text-2)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{link}</span>
          <button onClick={handleCopy} style={{ flexShrink: 0, background: copied ? 'var(--success)' : 'var(--brand)', border: 'none', borderRadius: 8, padding: '7px 14px', cursor: 'pointer', color: '#fff', fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700 }}>{copied ? Icon.check('#fff') : null} {copied ? 'Copied' : 'Copy'}</button>
        </div>
        <button onClick={onClose} style={{ width: '100%', padding: '12px', background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-2)', cursor: 'pointer' }}>Cancel</button>
      </div>
    </div>
  );
}

function BarberReferralCardDB({ userId, showToast }) {
  const [refCode, setRefCode]       = useState(null);
  const [codeCopied, setCodeCopied] = useState(false);
  const [showShareSheet, setShowShareSheet] = useState(false);
  const [referrals, setReferrals]   = useState([]);
  const [tierDays, setTierDays]     = useState(null); // { basic, pro, premium }

  useEffect(() => {
    if (!userId) return;
    getOrCreateReferralCode(userId).then(code => setRefCode(code || null));
    fetchMyReferrals(userId).then(setReferrals);
    supabase.from('app_settings').select('key, value')
      .in('key', ['referral_barber_to_barber_days_basic', 'referral_barber_to_barber_days_pro', 'referral_barber_to_barber_days_premium'])
      .then(({ data }) => {
        if (!data) return;
        const map = {};
        data.forEach(row => { map[row.key] = Number(row.value); });
        setTierDays({
          basic:   map.referral_barber_to_barber_days_basic   ?? null,
          pro:     map.referral_barber_to_barber_days_pro     ?? null,
          premium: map.referral_barber_to_barber_days_premium ?? null,
        });
      });
  }, [userId]);

  const handleCopyCode = async () => {
    if (!refCode) return;
    const ok = await copyToClipboard(refCode);
    if (ok) { setCodeCopied(true); showToast('success', 'Code copied!'); setTimeout(() => setCodeCopied(false), 1800); }
  };

  const handleShareLink = async () => {
    if (!refCode) return;
    const link = buildInviteLink(refCode);
    const shareText = `List your shop on Zentro — use my referral code ${refCode} when you sign up!`;
    const isWebViewApp = useIsWebView();
    // Skip native share in WebView — it silently drops the URL or does nothing.
    if (!isWebViewApp && navigator.share) {
      try {
        await navigator.share({ title: 'Join Zentro as a Barber', text: shareText + '\n' + link });
        return;
      } catch { /* fall through */ }
    }
    // Always show custom sheet (in WebView, or if native share failed/was cancelled)
    setShowShareSheet(true);
  };

  const confirmed = referrals.filter(r => r.status === 'rewarded').length;
  const pending   = referrals.filter(r => r.status === 'awaiting_purchase' || r.status === 'pending').length;

  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{
        borderRadius: 18, overflow: 'hidden', marginBottom: 12,
        background: 'linear-gradient(135deg, #0a1628 0%, #0b1f3e 50%, #071430 100%)',
        border: '1.5px solid rgba(0,128,255,0.25)',
        boxShadow: '0 8px 32px rgba(0,128,255,0.12)',
      }}>
        <div style={{ height: 3, background: 'linear-gradient(90deg, var(--brand), #00c6ff)' }} />
        <div style={{ padding: '18px 18px 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <div style={{ width: 44, height: 44, borderRadius: 14, flexShrink: 0,
              background: 'linear-gradient(135deg, rgba(0,128,255,0.25), rgba(0,198,255,0.15))',
              border: '1.5px solid rgba(0,128,255,0.3)',
              display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {Icon.gift('var(--brand)')}
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, color: '#fff' }}>Refer Barbers</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', marginTop: 2 }}>
                {tierDays ? `Earn Rs ${tierDays.basic ?? '–'}/${tierDays.pro ?? '–'}/${tierDays.premium ?? '–'} credits when they buy Basic/Pro/Premium` : 'Earn Zentro credits when they buy a plan'}
              </div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
            {[
              { label: 'Confirmed', value: confirmed, color: 'var(--success)' },
              { label: 'Pending',   value: pending,   color: '#FFB800' },
            ].map(s => (
              <div key={s.label} style={{ background: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: '12px 14px', border: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24, color: s.color, lineHeight: 1 }}>{s.value}</div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', fontWeight: 600, marginTop: 3, textTransform: 'uppercase', letterSpacing: 0.5 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        {refCode && (
          <div style={{ margin: '0 18px 18px', background: 'rgba(0,128,255,0.1)', border: '1px solid rgba(0,128,255,0.2)', borderRadius: 12, padding: '10px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 3 }}>Your Code</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: '#fff', letterSpacing: 2 }}>{refCode}</div>
            </div>
            <button onClick={handleCopyCode} style={{
              background: codeCopied ? 'var(--success)' : 'var(--brand)',
              border: 'none', borderRadius: 10, padding: '10px 14px',
              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
              transition: 'all 0.2s', color: '#fff',
              fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700,
            }}>
              {codeCopied ? Icon.check('#fff') : Icon.copy('#fff')}
              {codeCopied ? 'Copied' : 'Copy'}
            </button>
          </div>
        )}
      </div>
      <button onClick={handleShareLink} className="btn btn-primary" style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
        {Icon.share()}
        Share Invite Link
      </button>
      {showShareSheet && refCode && (
        <ShareSheet
          link={buildInviteLink(refCode)}
          text={`List your shop on Zentro — use my referral code ${refCode} when you sign up!`}
          onClose={() => setShowShareSheet(false)}
        />
      )}
      {referrals.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <SectionLabel>Recent Referrals</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {referrals.slice(0, 4).map(r => (
              <div key={r.id} style={{ background: 'var(--bg-card)', borderRadius: 12, padding: '10px 14px', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 34, height: 34, borderRadius: 10, flexShrink: 0, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {Icon.users('var(--brand)')}
                  </div>
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13 }}>{r.referee?.full_name || 'New Barber'}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{new Date(r.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })}</div>
                  </div>
                </div>
                <span className={`badge ${r.status === 'rewarded' || r.status === 'confirmed' ? 'badge-success' : 'badge-warning'}`} style={{ textTransform: 'capitalize' }}>{r.status}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function BarberWalletCardDB({ userId, onPress }) {
  const [balance, setBalance] = useState(null);
  useEffect(() => {
    if (!userId) return;
    fetchBarberWalletBalance(userId).then(bal => setBalance(bal));
  }, [userId]);
  const total = balance || 0;
  if (balance === null) return null;
  return (
    <div
      onClick={onPress}
      style={{ marginBottom: 20, borderRadius: 14, cursor: onPress ? 'pointer' : 'default',
        background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
        padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14,
        boxShadow: '0 6px 24px rgba(99,102,241,0.28)', position: 'relative', overflow: 'hidden' }}
    >
      <div style={{ position: 'absolute', top: -15, right: -15, width: 80, height: 80, borderRadius: '50%', background: 'rgba(99,102,241,0.2)', filter: 'blur(20px)' }} />
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>
      </svg>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6 }}>Zentro Wallet</div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: '#fff' }}>Rs {total.toLocaleString()}</div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.65)', marginTop: 1 }}>Use at checkout for discount on subscription</div>
      </div>
      {onPress && <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: 18, flexShrink: 0 }}>›</span>}
    </div>
  );
}

function DashboardTab({ user, showToast, perks }) {
  const [shop, setShop]         = useState(null);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats]       = useState({ today: 0, total: 0, completed: 0 });
  const [loading, setLoading]   = useState(true);
  const [bTab, setBTab]         = useState('today');
  const [showQR, setShowQR]   = useState(() => { const v = openQROnNextVisit; openQROnNextVisit = false; return v; });
  const qrCardRef = useRef(null);

  const { plansConfig, loading: plansLoading } = usePlanPerks(shop?.subscription_tier || 'basic');

  useEffect(() => { fetchData(); }, []); // eslint-disable-line

  const fetchData = async () => {
    const { data: shopData } = await supabase.from('shops').select('*').eq('owner_id', user.id).maybeSingle();
    setShop(shopData);
    if (!shopData) { setLoading(false); return; }
    maybeNotifySubscriptionExpiry(shopData, user.id).catch(() => {});
    const { data: bData } = await supabase
      .from('bookings')
      .select('*, profiles(full_name), services(name, price), time_slots(slot_date, start_time)')
      .eq('shop_id', shopData.id)
      .order('created_at', { ascending: false });
    const bs = bData || [];
    setBookings(bs);
    const today = format(new Date(), 'yyyy-MM-dd');
    const todayBs = bs.filter(b => b.time_slots?.slot_date === today && b.status !== 'cancelled');
    const completed = bs.filter(b => b.status === 'completed').length;
    setStats({ today: todayBs.length, total: bs.length, completed });
    setLoading(false);
  };

  const updateStatus = async (bookingId, status, slotId) => {
    await supabase.from('bookings').update({ status }).eq('id', bookingId);
    if (status === 'cancelled') await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
    showToast('success', `Booking ${status}`);
    const b = bookings.find(x => x.id === bookingId);
    if (b?.customer_id) {
      sendNotification(b.customer_id, {
        title: `Booking ${status}`,
        body: `Your ${b.services?.name || 'booking'} at ${shop?.name || 'the shop'} was ${status}.`,
        type: 'booking_status',
        meta: { url: '/account' },
      }).catch(() => {});
    }
    fetchData();
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  if (!shop) return (
    <div style={{ textAlign: 'center', padding: '48px 0' }}>
      <div style={{ width: 56, height: 56, borderRadius: 18, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
        {Icon.store()}
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--text-1)', marginBottom: 6 }}>No shop yet</div>
      <div style={{ fontSize: 13, color: 'var(--text-3)' }}>Set up your shop in the Setup tab</div>
    </div>
  );

  const today      = format(new Date(), 'yyyy-MM-dd');
  const todayBs    = bookings.filter(b => b.time_slots?.slot_date === today);
  const upcomingBs = bookings.filter(b => b.time_slots?.slot_date > today && b.status !== 'cancelled');
  const pastBs     = bookings.filter(b => b.time_slots?.slot_date < today);
  const tabBs      = bTab === 'today' ? todayBs : bTab === 'upcoming' ? upcomingBs : bTab === 'past' ? pastBs : bookings;
  const currentTier = shop.subscription_tier || 'basic';
  const openQR = () => {
    setShowQR(true);
    setTimeout(() => { if (qrCardRef.current) qrCardRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 60);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* ── Status banner ── */}
      {!shop.is_active && (
        <div style={{ background: 'rgba(255,149,0,0.08)', border: '1px solid rgba(255,149,0,0.2)', borderRadius: 12, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--warning)', flexShrink: 0 }} />
          <span style={{ fontSize: 13, color: 'var(--warning)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Pending admin approval</span>
        </div>
      )}

      {/* ── Quick numbers ── */}
      <div style={{ display: 'flex', gap: 16, fontSize: 12, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
        <span>Aaj <span style={{ color: 'var(--text-1)' }}>{stats.today}</span></span>
        <span>Total <span style={{ color: 'var(--text-1)' }}>{stats.total}</span></span>
        <span>Done <span style={{ color: 'var(--success)' }}>{stats.completed}</span></span>
      </div>

      {/* ── Bookings Tabs ── */}
      <div>
        <SectionLabel>Bookings</SectionLabel>
        <div style={{ display: 'flex', gap: 8, marginBottom: 14, overflowX: 'auto', paddingBottom: 2 }}>
          {[
            { key: 'today',    label: `Today (${todayBs.length})` },
            { key: 'upcoming', label: `Upcoming (${upcomingBs.length})` },
            { key: 'past',     label: `Past (${pastBs.length})` },
            { key: 'all',      label: `All (${bookings.length})` },
          ].map(t => (
            <button key={t.key} onClick={() => setBTab(t.key)} style={{
              flexShrink: 0, padding: '7px 14px', borderRadius: 20, border: 'none',
              cursor: 'pointer', fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)',
              background: bTab === t.key ? 'var(--brand)' : 'var(--bg-input)',
              color:      bTab === t.key ? '#fff'         : 'var(--text-2)',
              transition: 'all 0.15s',
            }}>{t.label}</button>
          ))}
        </div>
        {tabBs.length === 0 ? (
          <div style={{ background: 'var(--bg-input)', borderRadius: 12, padding: '18px 16px', textAlign: 'center' }}>
            <div style={{ fontSize: 13, color: 'var(--text-3)', fontFamily: 'var(--font-display)' }}>No bookings here</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', margin: '6px 0 14px', lineHeight: 1.6 }}>
              Share your QR code so customers can book you.
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="btn btn-primary btn-sm" onClick={openQR}
                style={{ width: 'auto', paddingLeft: 20, paddingRight: 20 }}>Show my QR code</button>
            </div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {tabBs.map((b, i) => (
              <div key={b.id} className="stagger-in" style={{ animationDelay: `${Math.min(i * 0.04, 0.3)}s` }}>
                <BookingRowDB booking={b} onUpdate={updateStatus} />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* QR Code - one tap to show */}
      <div ref={qrCardRef}>
        {perks?.qr ? (
          <div style={{ background: 'var(--bg-card)', border: '1.5px solid var(--border)', borderRadius: 16, padding: 14 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <div style={{ width: 44, height: 44, borderRadius: 14, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                {Icon.qr()}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-1)' }}>Customers scan to book</div>
                <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>Download it and stick it in your shop</div>
              </div>
              <button className="btn btn-primary btn-sm" onClick={() => setShowQR(v => !v)}
                style={{ width: 'auto', paddingLeft: 16, paddingRight: 16, flexShrink: 0 }}>
                {showQR ? 'Hide' : 'Show QR'}
              </button>
            </div>
            {showQR && (
              <div style={{ marginTop: 16 }}>
                <ZentroQR shopId={shop.id} shopName={shop.name} size={220} />
              </div>
            )}
          </div>
        ) : (
          <div style={{ background: 'var(--bg-input)', borderRadius: 16, padding: '20px 18px', textAlign: 'center', border: '1.5px dashed var(--border)' }}>
            <div style={{ width: 44, height: 44, borderRadius: 14, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
              {Icon.qr()}
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-1)', marginBottom: 6 }}>QR Code not included</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', lineHeight: 1.6 }}>
              Upgrade to <strong style={{ color: 'var(--brand)' }}>Pro</strong> or <strong style={{ color: '#FFB800' }}>Premium</strong> to get your branded QR code
            </div>
          </div>
        )}
      </div>

    </div>
  );
}


function BookingRowDB({ booking: b, onUpdate }) {
  return (
    <div style={{ background: 'var(--bg-card)', borderRadius: 16, padding: '14px 16px',
      border: '1px solid var(--border)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-1)' }}>
          {b.profiles?.full_name || 'Customer'}
        </div>
        <StatusPill status={b.status} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: b.status === 'pending' || b.status === 'confirmed' ? 14 : 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-2)' }}>
          {Icon.scissors('var(--text-3)')}
          <span>{b.services?.name} — <strong style={{ color: 'var(--text-1)' }}>Rs {b.services?.price}</strong></span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-2)' }}>
          {Icon.clock('var(--text-3)')}
          <span>{b.time_slots?.start_time?.slice(0, 5)}</span>
        </div>
      </div>
      {b.status === 'pending' && (
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => onUpdate(b.id, 'confirmed', b.time_slot_id)}>Confirm</button>
          <button onClick={() => onUpdate(b.id, 'cancelled', b.time_slot_id)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--error)', fontSize: 13, fontWeight: 700, fontFamily: 'var(--font-display)', padding: '0 12px' }}>Cancel</button>
        </div>
      )}
      {b.status === 'confirmed' && (
        <button className="btn btn-primary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: 6 }}
          onClick={() => onUpdate(b.id, 'completed', b.time_slot_id)}>
          {Icon.check('#fff')} Mark Complete
        </button>
      )}
    </div>
  );
}

// ── Map helpers for SetupTab ───────────────────────────────────────────────────
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});
const DEFAULT_PLANS_PT = {
  basic:   { name: 'Basic',   price: 999,  photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, photos: 30, qr: true,  badge: true,  priority: true  },
};
const TIER_COLORS_PT = { basic: '#8EA0BC', pro: '#0080FF', premium: '#FFB800' };

function PaymentTab({ user, showToast }) {
  const [shop, setShop]             = useState(null);
  const [payments, setPayments]     = useState([]);
  const [settings, setSettings]     = useState({});
  const [plans, setPlans]           = useState(DEFAULT_PLANS_PT);
  const [loading, setLoading]       = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingProof, setUpProof] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [form, setForm] = useState({ txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });
  const [numCopied, setNumCopied] = useState(false);
  const [walletBalance, setWalletBalance] = useState(0);
  const [payingWithCredits, setPayingWithCredits] = useState(false);
  const [useDiscount, setUseDiscount] = useState(false);
  const [showSendFriend, setShowSendFriend] = useState(false);
  const [minSendAmount, setMinSendAmount] = useState(50);

  useEffect(() => { fetchMinSendAmount().then(setMinSendAmount); }, []);

  const copyAccountNumber = async (num) => {
    const ok = await copyToClipboard(num);
    if (ok) { setNumCopied(true); showToast('success', 'Number copied!'); setTimeout(() => setNumCopied(false), 1800); }
    else showToast('error', 'Copy failed');
  };

  useEffect(() => { loadData(); }, []); // eslint-disable-line

  const loadData = async () => {
    const [{ data: s }, { data: pays }, { data: cfg }, bal] = await Promise.all([
      supabase.from('shops').select('id, name, subscription_tier, subscription_status, subscription_expires_at, subscription_approved_at').eq('owner_id', user.id).maybeSingle(),
      supabase.from('payment_submissions').select('*').eq('owner_id', user.id).order('submitted_at', { ascending: false }),
      supabase.from('app_settings').select('key, value'),
      fetchBarberWalletBalance(user.id),
    ]);
    setShop(s);
    setPayments(pays || []);
    setWalletBalance(bal || 0);
    const map = {};
    (cfg || []).forEach(r => { map[r.key] = r.value; });
    setSettings(map);
    if (map.plans_config) {
      try {
        const parsed = JSON.parse(map.plans_config);
        const merged = {};
        for (const t of ['basic', 'pro', 'premium']) merged[t] = { ...DEFAULT_PLANS_PT[t], ...(parsed[t] || {}) };
        setPlans(merged);
      } catch {}
    }
    setLoading(false);
  };

  const uploadProof = async (e) => {
    const file = e.target.files[0];
    if (!file || !user) return;
    setUpProof(true);
    try {
      const url = await uploadPaymentProof(file, user.id);
      setForm(p => ({ ...p, screenshot_url: url }));
      showToast('success', 'Screenshot uploaded');
    } catch (err) { showToast('error', 'Upload failed: ' + err.message); }
    setUpProof(false);
  };

  const payWithCredits = async () => {
    if (!shop)         return showToast('error', 'No shop found');
    if (!selectedPlan) return showToast('error', 'Select a plan first');
    const plan = plans[selectedPlan];
    if (walletBalance < plan.price) return showToast('error', 'Insufficient credits');
    setPayingWithCredits(true);
    // Deduct credits from barber wallet
    const { error: deductErr } = await supabase.from('credits').insert({
      user_id: user.id, amount: -plan.price, kind: 'barber_credit',
      source: 'subscription_payment', redeemed_at: new Date().toISOString(),
    });
    if (deductErr) { setPayingWithCredits(false); return showToast('error', 'Credits deduction failed'); }
    // Auto-approve: activate subscription directly
    const expiresAt = new Date();
    expiresAt.setMonth(expiresAt.getMonth() + 1);
    const { error: shopErr } = await supabase.from('shops').update({
      subscription_tier: selectedPlan,
      subscription_status: 'active',
      subscription_expires_at: expiresAt.toISOString(),
      subscription_approved_at: new Date().toISOString(),
    }).eq('id', shop.id);
    if (shopErr) { setPayingWithCredits(false); return showToast('error', 'Subscription update failed'); }
    // Log in payment_submissions for record
    await supabase.from('payment_submissions').insert({
      shop_id: shop.id, owner_id: user.id, amount: plan.price,
      txn_id: 'WALLET_AUTO', screenshot_url: '',
      payment_method: 'wallet_credits',
      requested_tier: selectedPlan,
      status: 'approved', submitted_at: new Date().toISOString(),
    });
    setPayingWithCredits(false);
    showToast('success', `${plan.name} plan activated! Credits deducted.`);
    setSelectedPlan(null);
    setUseDiscount(false);
    loadData();
  };

  const submit = async () => {
    if (!shop)         return showToast('error', 'No shop found');
    if (!selectedPlan) return showToast('error', 'Select a plan first');
    if (!form.txn_id)  return showToast('error', 'Transaction ID required');
    setSubmitting(true);
    const plan = plans[selectedPlan];
    const discountAmt = useDiscount ? Math.min(walletBalance, plan.price) : 0;
    const amountPaid  = plan.price - discountAmt;
    const { error } = await supabase.from('payment_submissions').insert({
      shop_id: shop.id, owner_id: user.id, amount: amountPaid,
      txn_id: form.txn_id, screenshot_url: form.screenshot_url,
      payment_method: form.payment_method,
      requested_tier: selectedPlan,
      status: 'pending', submitted_at: new Date().toISOString(),
    });
    setSubmitting(false);
    if (error) return showToast('error', error.message);
    showToast('success', 'Payment submitted! Admin will review soon.');
    setForm({ txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });
    setSelectedPlan(null);
    setUseDiscount(false);
    loadData();
  };

  // Free plan (price = 0): skip payment proof entirely, just request admin activation.
  const requestFreePlan = async () => {
    if (!shop)         return showToast('error', 'No shop found');
    if (!selectedPlan) return showToast('error', 'Select a plan first');
    setSubmitting(true);
    const { error } = await supabase.from('payment_submissions').insert({
      shop_id: shop.id, owner_id: user.id, amount: 0,
      txn_id: 'FREE_PLAN', screenshot_url: '',
      payment_method: 'free',
      requested_tier: selectedPlan,
      status: 'pending', submitted_at: new Date().toISOString(),
    });
    setSubmitting(false);
    if (error) return showToast('error', error.message);
    showToast('success', 'Requested! Admin will approve shortly.');
    setSelectedPlan(null);
    loadData();
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  const accountNumber = form.payment_method === 'jazzcash' ? settings.jazzcash_number : settings.easypaisa_number;
  const accountName   = form.payment_method === 'jazzcash' ? settings.jazzcash_name   : settings.easypaisa_name;
  const currentTier   = shop?.subscription_tier || 'basic';
  const isActive      = shop?.subscription_status === 'active';

  // Subscription time remaining
  const expiresAt   = shop?.subscription_expires_at ? new Date(shop.subscription_expires_at) : null;
  const now         = new Date();
  const msLeft      = expiresAt ? expiresAt - now : null;
  const daysLeft    = msLeft !== null ? Math.ceil(msLeft / (1000 * 60 * 60 * 24)) : null;
  const isExpired   = daysLeft !== null && daysLeft <= 0;
  const isUrgent    = daysLeft !== null && daysLeft > 0 && daysLeft <= 5;
  const expiryColor = isExpired ? '#FF4444' : isUrgent ? '#FFB800' : 'rgba(255,255,255,0.9)';

  const selectedPrice  = selectedPlan ? plans[selectedPlan]?.price : 0;
  const discountAmt    = (useDiscount && selectedPlan) ? Math.min(walletBalance, selectedPrice) : 0;
  const amountDue      = selectedPrice - discountAmt;
  const canPayFull     = walletBalance >= selectedPrice && selectedPrice > 0;
  const isFreePlan     = !!selectedPlan && selectedPrice === 0;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <BarberWalletCardDB userId={user?.id} onPress={() => setShowSendFriend(true)} />
      <button
        onClick={() => setShowSendFriend(true)}
        style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          background: 'var(--bg-input)', border: '1.5px solid var(--border)', borderRadius: 12,
          padding: '12px 16px', cursor: 'pointer', color: 'var(--text-1)',
          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13.5, marginTop: -4 }}
      >
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
        </svg>
        Send Credits to a Friend
      </button>
      {shop && (
        <div style={{ background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
          borderRadius: 20, padding: '18px 20px', color: '#fff' }}>
          <div style={{ fontSize: 11, opacity: 0.8, fontFamily: 'var(--font-display)', fontWeight: 700,
            textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Current Plan</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: expiresAt ? 14 : 0 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24, textTransform: 'capitalize' }}>
              {plans[currentTier]?.name || currentTier}
            </span>
            <span style={{ background: 'rgba(255,255,255,0.2)', borderRadius: 100, padding: '4px 14px',
              fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-display)', textTransform: 'capitalize' }}>
              {shop.subscription_status || 'Pending'}
            </span>
          </div>

          {expiresAt && (
            <div>
              <div style={{ height: 5, background: 'rgba(255,255,255,0.15)', borderRadius: 10, overflow: 'hidden', marginBottom: 8 }}>
                <div style={{
                  height: '100%', borderRadius: 10,
                  width: `${daysLeft > 0 ? Math.min(100, Math.max(2, (daysLeft / 30) * 100)) : 0}%`,
                  background: isExpired ? '#FF4444' : isUrgent ? '#FFB800' : 'rgba(255,255,255,0.8)',
                  transition: 'width 0.5s',
                }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 13, fontFamily: 'var(--font-display)', fontWeight: 700, color: expiryColor, display: 'flex', alignItems: 'center' }}>
                  {(isExpired || isUrgent) && (
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: 4, flexShrink: 0 }}>
                      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                      <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
                    </svg>
                  )}
                  {isExpired
                    ? 'Subscription expired'
                    : isUrgent
                      ? `${daysLeft} day${daysLeft === 1 ? '' : 's'} left — renew soon!`
                      : `${daysLeft} day${daysLeft === 1 ? '' : 's'} remaining`}
                </span>
                <span style={{ fontSize: 11, opacity: 0.65, fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                  Expires {expiresAt.toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}
                </span>
              </div>
            </div>
          )}

          {!expiresAt && isActive && (
            <p style={{ fontSize: 12, opacity: 0.7, marginTop: 4, fontFamily: 'var(--font-display)' }}>
              No expiry date set — contact admin
            </p>
          )}
        </div>
      )}

      {/* ── Wallet Balance Banner ── */}
      {walletBalance > 0 && selectedPlan && !isFreePlan && (
        <div style={{ background: 'linear-gradient(135deg, #1a1a2e, #0f3460)', borderRadius: 16, padding: '14px 16px', border: '1px solid rgba(99,102,241,0.35)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>
              </svg>
              <div>
                <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.55)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>Zentro Wallet</div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 16, color: '#fff' }}>Rs {walletBalance.toLocaleString()}</div>
              </div>
            </div>
            {/* Toggle: use discount */}
            {!canPayFull && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.65)', fontWeight: 600 }}>Use discount</span>
                <div onClick={() => setUseDiscount(d => !d)} style={{
                  width: 40, height: 22, borderRadius: 11, cursor: 'pointer', transition: 'background 0.2s',
                  background: useDiscount ? '#6366f1' : 'rgba(255,255,255,0.15)',
                  position: 'relative',
                }}>
                  <div style={{
                    position: 'absolute', top: 3, left: useDiscount ? 21 : 3, width: 16, height: 16,
                    borderRadius: '50%', background: '#fff', transition: 'left 0.2s',
                  }} />
                </div>
              </div>
            )}
          </div>

          {/* Full pay button */}
          {canPayFull && (
            <>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', marginBottom: 12 }}>
                You have enough credits to cover the full <strong style={{ color: '#fff' }}>Rs {selectedPrice.toLocaleString()}</strong> — no screenshot needed, instant activation.
              </div>
              <button className="btn" onClick={payWithCredits} disabled={payingWithCredits} style={{
                width: '100%', background: 'linear-gradient(135deg,#6366f1,#8b5cf6)',
                border: 'none', color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14,
              }}>
                {payingWithCredits ? <span className="spinner spinner-sm" /> : `Pay Rs ${selectedPrice.toLocaleString()} · Instant Activate`}
              </button>
              <div style={{ textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,0.35)', marginTop: 10 }}>— or pay via JazzCash / Easypaisa below —</div>
            </>
          )}

          {/* Discount active summary */}
          {!canPayFull && useDiscount && (
            <div style={{ background: 'rgba(99,102,241,0.15)', borderRadius: 10, padding: '8px 12px', fontSize: 12, color: 'rgba(255,255,255,0.8)' }}>
              Rs {discountAmt.toLocaleString()} deducted · send only <strong style={{ color: '#fff' }}>Rs {amountDue.toLocaleString()}</strong> via JazzCash / Easypaisa
            </div>
          )}
        </div>
      )}
      {/* ── Plan Cards ── */}
      <SectionLabel>Choose a Plan</SectionLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {['basic', 'pro', 'premium'].map(tier => {
          const p          = plans[tier];
          const isSelected = selectedPlan === tier;
          const isCurrent  = currentTier === tier && isActive;
          const color      = TIER_COLORS_PT[tier];
          return (
            <div key={tier} onClick={() => setSelectedPlan(tier)} style={{
              background: 'var(--bg-card)', borderRadius: 16, cursor: 'pointer',
              border: `2px solid ${isSelected ? color : isCurrent ? color + '66' : 'var(--border)'}`,
              padding: '14px 16px', position: 'relative',
              boxShadow: isSelected ? `0 4px 16px ${color}22` : 'none', transition: 'all 0.15s',
            }}>
              {isCurrent && (
                <span style={{ position: 'absolute', top: 10, right: 12, background: color, color: '#fff',
                  fontSize: 9, fontWeight: 800, borderRadius: 6, padding: '2px 8px',
                  letterSpacing: 0.5, fontFamily: 'var(--font-display)' }}>ACTIVE</span>
              )}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <div style={{ width: 20, height: 20, borderRadius: '50%', flexShrink: 0,
                  border: `2px solid ${isSelected ? color : 'var(--border)'}`,
                  background: isSelected ? color : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {isSelected && <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#fff' }} />}
                </div>
                <div style={{ width: 28, height: 28, borderRadius: 8, background: `${color}18`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  {PLAN_ICONS[tier] && PLAN_ICONS[tier](color)}
                </div>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, color: isSelected ? color : 'var(--text-1)' }}>{p?.name}</div>
                  <div style={{ fontSize: 12, color: color, fontWeight: 700 }}>Rs {p?.price?.toLocaleString()} / mo</div>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
                {[
                  { label: 'Photos',   value: `${p?.photos} uploads`, hasBool: false },
                  { label: 'QR Code',  bool: p?.qr },
                  { label: 'Badge',    bool: p?.badge },
                  { label: 'Priority', bool: p?.priority },
                ].map(f => (
                  <div key={f.label} style={{ background: 'var(--bg-input)', borderRadius: 8, padding: '6px 10px',
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 600, textTransform: 'uppercase' }}>{f.label}</div>
                    {f.hasBool === false
                      ? <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-1)' }}>{f.value}</div>
                      : f.bool
                        ? <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        : <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                    }
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Payment options — only when plan selected ── */}
      {selectedPlan && isFreePlan && (
        <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
          <SectionLabel>Activate Free Plan</SectionLabel>
          <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 14 }}>
            This plan is free — no payment needed. Just request activation and an admin will approve it shortly.
          </p>
          <button className="btn btn-primary" onClick={requestFreePlan} disabled={submitting}>
            {submitting ? <span className="spinner spinner-sm" /> : `Request ${plans[selectedPlan]?.name} Plan (Free)`}
          </button>
        </div>
      )}
      {selectedPlan && !isFreePlan && (
        <>
          {(accountNumber || accountName) && (
            <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
              <SectionLabel>Send Rs {amountDue.toLocaleString()} To</SectionLabel>              <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
                {['jazzcash', 'easypaisa'].map(m => (
                  <button key={m} onClick={() => setForm(p => ({ ...p, payment_method: m }))}
                    className={`btn ${form.payment_method === m ? 'btn-primary' : 'btn-secondary'} btn-sm`}
                    style={{ flex: 1, textTransform: 'capitalize' }}>{m}</button>
                ))}
              </div>
              {accountNumber && (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  <div style={{ background: 'var(--bg-input)', borderRadius: 12, padding: '14px 16px' }}>
                    {accountName && <p style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 5 }}>
                      Account Name: <strong style={{ color: 'var(--text-1)' }}>{accountName}</strong></p>}
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
                      <p style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, color: 'var(--brand)', margin: 0 }}>{accountNumber}</p>
                      <button onClick={() => copyAccountNumber(accountNumber)} style={{
                        background: numCopied ? 'var(--success)' : 'var(--brand)',
                        border: 'none', borderRadius: 10, padding: '10px 14px',
                        cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                        flexShrink: 0, transition: 'all 0.2s', color: '#fff',
                        fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700,
                      }}>
                        {numCopied
                          ? <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                          : <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                        }
                        {numCopied ? 'Copied' : 'Copy'}
                      </button>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      const clean = (accountNumber || '').replace(/\D/g, '');
                      const isJazz = form.payment_method === 'jazzcash';
                      const intent = isJazz
                        ? `intent://transfer?to=${clean}#Intent;scheme=jazzcash;package=com.techlogix.mobilinkcustomer;end`
                        : `intent://send?to=${clean}#Intent;scheme=easypaisa;package=pk.com.telenor.phoenix;end`;
                      try { window.location.href = intent; } catch { window.location.href = `tel:${clean}`; }
                    }}
                    style={{
                      width: '100%', padding: '13px 16px',
                      background: form.payment_method === 'jazzcash'
                        ? 'linear-gradient(135deg,#c8102e,#e63950)'
                        : 'linear-gradient(135deg,#00a651,#00c463)',
                      border: 'none', borderRadius: 12,
                      color: '#fff', fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14,
                      cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                    }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>
                    Open {form.payment_method === 'jazzcash' ? 'JazzCash' : 'Easypaisa'} App
                  </button>
                </div>
              )}
            </div>
          )}
          <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
            <SectionLabel>Submit Payment Proof</SectionLabel>
            <div className="input-group">
              <label className="input-label">Transaction ID</label>
              <input className="input" placeholder="TXN ID from receipt" value={form.txn_id}
                onChange={e => setForm(p => ({ ...p, txn_id: e.target.value }))} />
            </div>
            <div className="input-group">
              <label className="input-label">Payment Screenshot</label>
              {form.screenshot_url ? (
                <div style={{ position: 'relative', marginBottom: 8 }}>
                  <img src={form.screenshot_url} alt="proof" style={{ width: '100%', borderRadius: 12, maxHeight: 180, objectFit: 'cover' }} />
                  <button onClick={() => setForm(p => ({ ...p, screenshot_url: '' }))}
                    style={{ position: 'absolute', top: 8, right: 8, background: 'var(--error)', color: '#fff',
                      border: 'none', borderRadius: 8, padding: '4px 10px', cursor: 'pointer', fontSize: 11,
                      fontFamily: 'var(--font-display)', fontWeight: 700 }}>Remove</button>
                </div>
              ) : (
                <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                  padding: '18px', border: '2px dashed var(--border)', borderRadius: 12,
                  background: 'var(--bg-input)', cursor: 'pointer', color: 'var(--text-2)', fontSize: 13 }}>
                  {uploadingProof ? <span className="spinner spinner-sm" /> : <>{Icon.upload()} Upload Screenshot</>}
                  <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadProof} disabled={uploadingProof} />
                </label>
              )}
            </div>
            <button className="btn btn-primary" onClick={submit} disabled={submitting}>
              {submitting ? <span className="spinner spinner-sm" /> : `Submit · ${plans[selectedPlan]?.name} Plan`}
            </button>
          </div>
        </>
      )}

      {payments.length > 0 && (
        <div>
          <SectionLabel>Payment History</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {payments.map((p, i) => (
              <div key={p.id} className="stagger-in" style={{ background: 'var(--bg-card)', borderRadius: 16, padding: '14px 16px', border: '1px solid var(--border)', animationDelay: `${Math.min(i * 0.04, 0.3)}s` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                  <div>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16 }}>Rs {p.amount}</span>
                    {p.requested_tier && (
                      <span style={{ marginLeft: 8, fontSize: 11, fontWeight: 700, color: TIER_COLORS_PT[p.requested_tier] || 'var(--brand)', textTransform: 'capitalize' }}>
                        · {p.requested_tier}
                      </span>
                    )}
                  </div>
                  <StatusPill status={p.status === 'approved' ? 'confirmed' : p.status === 'rejected' ? 'cancelled' : 'pending'} />
                </div>
                <p style={{ fontSize: 12, color: 'var(--text-2)', margin: '0 0 2px' }}>TXN: {p.txn_id} · {p.payment_method}</p>
                <p style={{ fontSize: 11, color: 'var(--text-3)', margin: 0 }}>{new Date(p.submitted_at).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {showSendFriend && (
        <SendFriendFlow
          userId={user.id}
          balance={walletBalance}
          minAmount={minSendAmount}
          onClose={() => setShowSendFriend(false)}
          onSuccess={(amt) => {
            setWalletBalance(b => Math.max(0, b - amt));
            setShowSendFriend(false);
          }}
          showToast={showToast}
        />
      )}
    </div>
  );
}


// ── Customer Booking Card ─────────────────────────────────────────────────────
function BookingCard({ booking: b, onCancel }) {
  return (
    <div style={{ background: 'var(--bg-card)', borderRadius: 18, padding: '16px', border: '1px solid var(--border)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, color: 'var(--text-1)' }}>{b.shops?.name}</div>
        <StatusPill status={b.status} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5, marginBottom: b.status === 'pending' ? 14 : 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 13, color: 'var(--text-2)' }}>
          {Icon.scissors('var(--text-3)')}
          <span>{b.services?.name} — <strong style={{ color: 'var(--brand)' }}>Rs {b.services?.price}</strong></span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 13, color: 'var(--text-2)' }}>
          {Icon.calendar()}
          <span>{b.time_slots?.slot_date} at {b.time_slots?.start_time?.slice(0, 5)}</span>
        </div>
      </div>
      {b.status === 'pending' && (
        <button className="btn btn-danger btn-sm" onClick={onCancel}>Cancel Booking</button>
      )}
    </div>
  );
}

// ── Main Account Page ─────────────────────────────────────────────────────────
// ── Barber app shell (new design): Home / Slots / Payments / More ─────────────
function fmtRs(n) {
  const v = Math.round(n || 0);
  if (v >= 1000) return `Rs ${(v / 1000).toFixed(1).replace(/\.0$/, '')}k`;
  return `Rs ${v}`;
}

function timeAgo(iso) {
  if (!iso) return '';
  const m = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (m < 1) return 'Just now';
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} hr ago`;
  const d = Math.round(h / 24);
  return d === 1 ? 'Yesterday' : `${d} days ago`;
}

function to12h(t) {
  if (!t) return '';
  const [hh, mm] = t.split(':');
  const h = parseInt(hh, 10);
  return `${((h + 11) % 12) + 1}:${mm} ${h >= 12 ? 'PM' : 'AM'}`;
}

const cap = (s) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : '');

function BarberHome({ user, profile, onGo, onNotif, unread }) {
  const [shop, setShop]         = useState(null);
  const [bookings, setBookings] = useState([]);
  const [srvCount, setSrvCount] = useState(0);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    let alive = true;
    (async () => {
      const { data: s } = await supabase.from('shops')
        .select('id, name, is_active, subscription_tier, subscription_expires_at, city, address, lat, lng, images')
        .eq('owner_id', user.id).maybeSingle();
      if (!alive) return;
      setShop(s);
      if (s) {
        const [{ data: bs }, { count: sc }] = await Promise.all([
          supabase.from('bookings')
            .select('id, status, created_at, profiles(full_name), services(name, price), time_slots(slot_date, start_time)')
            .eq('shop_id', s.id).order('created_at', { ascending: false }).limit(40),
          supabase.from('services').select('id', { count: 'exact', head: true }).eq('shop_id', s.id),
        ]);
        if (!alive) return;
        setBookings(bs || []);
        setSrvCount(sc || 0);
      }
      setLoading(false);
    })();
    return () => { alive = false; };
  }, [user.id]);

  if (loading) return <div style={{ textAlign: 'center', padding: 60 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  const today = format(new Date(), 'yyyy-MM-dd');
  const todayBs = bookings.filter(b => b.time_slots?.slot_date === today && b.status !== 'cancelled');
  const revenue = todayBs.reduce((sum, b) => sum + (Number(b.services?.price) || 0), 0);

  const tier = shop?.subscription_tier || 'basic';
  const pendingCount = bookings.filter(b => b.status === 'pending').length;

  // Next booking today
  const nowHM = format(new Date(), 'HH:mm');
  const nextB = [...todayBs]
    .filter(b => b.status !== 'completed' && (b.time_slots?.start_time || '').slice(0, 5) >= nowHM)
    .sort((x, y) => (x.time_slots?.start_time || '').localeCompare(y.time_slots?.start_time || ''))[0];
  const nextLine = nextB
    ? `Agli: ${(nextB.profiles?.full_name || 'Customer').split(' ')[0]}, ${to12h(nextB.time_slots?.start_time)}, ${nextB.services?.name || 'Booking'}`
    : 'Aaj ki koi aur booking nahi';

  // Shop setup progress (4 parts)
  const okBasic = !!(shop?.name && shop?.city && shop?.address);
  const okLoc   = !!(shop?.lat && shop?.lng);
  const setupDone = shop ? [okBasic, okLoc, srvCount > 0, (shop.images || []).length > 0].filter(Boolean).length : 0;
  const nextSetup = !okBasic ? 'basic info bharo' : !okLoc ? 'map par pin lagao' : srvCount === 0 ? 'services add karo' : 'photos lagao';

  const stroke = { fill: 'none', stroke: 'var(--brand)', strokeWidth: 2, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const mainActions = [
    { id: 'slots', label: 'Slots', sub: 'Time set karo', icon: <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg> },
    { id: 'bookings', label: 'Bookings', sub: pendingCount > 0 ? `${pendingCount} pending` : 'Sab dekho', icon: <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg> },
    { id: 'qr', label: 'QR Code', sub: 'Print karo', icon: <QrCode size={20} color="var(--brand)" /> },
    { id: 'payment', label: 'Payments', sub: `${cap(tier)} plan`, icon: <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg> },
  ];
  const moreActions = [
    { id: 'setup', label: 'Shop Setup', icon: <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><path d="M3 9l1-5h16l1 5"/><path d="M4 9v11h16V9"/><path d="M9 20v-6h6v6"/></svg> },
    { id: 'referrals', label: 'Refer a Barber', icon: <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg> },
    { id: 'guide', label: 'Guide aur video', icon: <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg> },
    { id: 'settings', label: 'Settings', icon: <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg> },
  ];
  const tapAction = (id) => {
    if (id === 'qr') { openQROnNextVisit = true; onGo('bookings'); }
    else onGo(id);
  };
  const tile = (a) => (
    <button key={a.id} onClick={() => tapAction(a.id)} style={{
      background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 14,
      padding: 12, textAlign: 'left', cursor: 'pointer', color: 'var(--text-1)',
      display: 'flex', alignItems: 'center', gap: 10, minWidth: 0,
    }}>
      <div style={{ width: 40, height: 40, borderRadius: 12, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>{a.icon}</div>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 700, fontFamily: 'var(--font-display)' }}>{a.label}</div>
        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{a.sub}</div>
      </div>
    </button>
  );

  return (
    <div>
      {/* Greeting + bell */}
      <div style={{ padding: '24px 20px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 13, color: 'var(--text-3)' }}>Assalam-o-Alaikum</div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 800, color: 'var(--text-1)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {shop?.name || profile?.full_name || 'Your shop'}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
        <button aria-label="Chat with support" onClick={openSupportChat} style={{
          width: 40, height: 40, borderRadius: 12, flexShrink: 0,
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: 'var(--text-1)',
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        </button>
        <button aria-label="Notifications" onClick={onNotif} style={{
          position: 'relative', width: 40, height: 40, borderRadius: 12, flexShrink: 0,
          background: 'var(--bg-card)', border: '1px solid var(--border)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <Bell size={18} color="var(--text-1)" />
          {unread > 0 && <span style={{ position: 'absolute', top: 8, right: 9, width: 8, height: 8, borderRadius: '50%', background: '#FF3B30', border: '2px solid var(--bg-card)' }} />}
        </button>
        </div>
      </div>

      <div style={{ padding: '4px 20px 0' }}>
        {shop && !shop.is_active && (
          <div style={{ background: 'rgba(255,149,0,0.08)', border: '1px solid rgba(255,149,0,0.2)', borderRadius: 12, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--warning)', flexShrink: 0 }} />
            <span style={{ fontSize: 13, color: 'var(--warning)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Pending admin approval</span>
          </div>
        )}

        {!shop ? (
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 18, padding: 24, textAlign: 'center', marginBottom: 16 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, marginBottom: 6 }}>No shop yet</div>
            <div style={{ fontSize: 13, color: 'var(--text-3)', marginBottom: 16 }}>Set up your shop to start getting bookings</div>
            <button className="btn btn-primary btn-sm" onClick={() => onGo('setup')}>Set up shop</button>
          </div>
        ) : (
          <div style={{ background: '#0080FF', borderRadius: 18, padding: 20, marginBottom: 16, color: '#fff' }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: '#CFE6FF', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 14 }}>Aaj</div>
            <div style={{ display: 'flex' }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 800, lineHeight: 1 }}>{todayBs.length}</div>
                <div style={{ fontSize: 12, color: '#CFE6FF', marginTop: 4 }}>Bookings</div>
              </div>
              <div style={{ flex: 1, borderLeft: '1px solid rgba(255,255,255,0.25)', paddingLeft: 16 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 800, lineHeight: 1 }}>{fmtRs(revenue)}</div>
                <div style={{ fontSize: 12, color: '#CFE6FF', marginTop: 4 }}>Andaza kamai</div>
              </div>
            </div>
            <div style={{ marginTop: 14, paddingTop: 14, borderTop: '1px solid rgba(255,255,255,0.25)', fontSize: 13 }}>{nextLine}</div>
          </div>
        )}

        {shop && setupDone < 4 && (
          <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 16, padding: 16, marginBottom: 16 }}>
            <div style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-display)', color: 'var(--text-1)' }}>Shop setup: 4 mein se {setupDone} pura</div>
            <div style={{ height: 8, borderRadius: 4, background: 'var(--border)', margin: '12px 0 8px' }}>
              <div style={{ width: `${setupDone * 25}%`, height: 8, borderRadius: 4, background: 'var(--brand)' }} />
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 12 }}>Agla kaam: {nextSetup}</div>
            <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => onGo('setup')}>Setup jari rakho</button>
          </div>
        )}

        {bookings.length === 0 && <TutorialHomeCard />}

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
          {mainActions.map(tile)}
        </div>

        <div style={{ background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 14, marginBottom: 18, overflow: 'hidden' }}>
          {moreActions.map((a, i) => (
            <button key={a.id} onClick={() => tapAction(a.id)} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '0 14px', height: 50,
              background: 'none', border: 'none', borderTop: i ? '1px solid var(--border)' : 'none',
              cursor: 'pointer', color: 'var(--text-1)', textAlign: 'left',
            }}>
              {a.icon}
              <span style={{ flex: 1, fontSize: 14, fontWeight: 600, fontFamily: 'var(--font-display)' }}>{a.label}</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 6 15 12 9 18" /></svg>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function SettingsPanel({ user, themeMode, setThemeMode, LangToggleBtn, onSignOut, navigate }) {
  const row = { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 0', borderBottom: '1px solid var(--border)' };
  return (
    <div className="card" style={{ padding: '4px 18px' }}>
      <div style={row}>
        <span style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-display)' }}>Appearance</span>
        <div style={{ display: 'flex', background: 'var(--bg-input)', borderRadius: 10, padding: 3, gap: 2 }}>
          {['system', 'light', 'dark'].map(opt => (
            <button key={opt} onClick={() => setThemeMode(opt)} style={{
              border: 'none', borderRadius: 8, padding: '6px 10px', fontSize: 11.5, fontWeight: 700, cursor: 'pointer',
              textTransform: 'capitalize', fontFamily: 'var(--font-display)',
              background: themeMode === opt ? 'var(--bg-card)' : 'transparent',
              color: themeMode === opt ? 'var(--brand)' : 'var(--text-3)',
            }}>{opt}</button>
          ))}
        </div>
      </div>
      <div style={row}>
        <span style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-display)' }}>Language</span>
        {LangToggleBtn ? <LangToggleBtn /> : null}
      </div>
      <PushSettingRow bare />
      <div style={row}>
        <span style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-display)' }}>Customer view</span>
        <button onClick={() => navigate('/')} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 13, fontWeight: 700, color: 'var(--brand)', fontFamily: 'var(--font-display)' }}>Open Home</button>
      </div>
      <div style={{ padding: '14px 0', fontSize: 12, color: 'var(--text-3)', overflow: 'hidden', textOverflow: 'ellipsis', borderBottom: '1px solid var(--border)' }}>{user?.email}</div>
      <button onClick={onSignOut} style={{ width: '100%', textAlign: 'left', padding: '14px 0', background: 'none', border: 'none', cursor: 'pointer', fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-display)', color: 'var(--error)' }}>Sign out</button>
    </div>
  );
}

function BarberShell({ user, profile, perks, showToast, tab, setTab, onNotif, unread, themeMode, setThemeMode, onSignOut, LangToggleBtn, navigate }) {
  const go = (id) => { setTab(id); window.scrollTo(0, 0); };
  const titles = { bookings: 'All bookings', slots: 'Manage Slots', payment: 'Payments', setup: 'Shop Setup', referrals: 'Refer a Barber', guide: 'Setup Guide', settings: 'Settings' };
  const stepForTab = { setup: 'shop', slots: 'slots', payment: 'plan', bookings: 'bookings' };

  return (
    <div>
      {tab === 'dashboard' ? (
        <BarberHome user={user} profile={profile} onGo={go} onNotif={onNotif} unread={unread} />
      ) : (
        <div style={{ padding: '20px 20px 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 18 }}>
            <button onClick={() => go('dashboard')} aria-label="Back" style={{
              width: 36, height: 36, borderRadius: 10, background: 'var(--bg-card)', border: '1px solid var(--border)',
              cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-1)',
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
            </button>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--text-1)', flex: 1, minWidth: 0 }}>{titles[tab]}</div>
            {stepForTab[tab] && <WatchStepButton stepId={stepForTab[tab]} label="Video dekho" compact />}
          </div>
          <div className="fade-in">
            {tab === 'bookings'  && <DashboardTab user={user} showToast={showToast} perks={perks} />}
            {tab === 'setup'     && <SetupTab     user={user} showToast={showToast} perks={perks} />}
            {tab === 'slots'     && <SlotsTab     user={user} showToast={showToast} />}
            {tab === 'payment'   && <PaymentTab   user={user} showToast={showToast} />}
            {tab === 'referrals' && <BarberReferralCardDB userId={user?.id} showToast={showToast} />}
            {tab === 'guide'     && <BarberGuide />}
            {tab === 'settings'  && <SettingsPanel user={user} themeMode={themeMode} setThemeMode={setThemeMode} LangToggleBtn={LangToggleBtn} onSignOut={onSignOut} navigate={navigate} />}
          </div>
        </div>
      )}
    </div>
  );
}

export default function Account() {
  const { user, profile, signOut, authReady, refreshProfile } = useAuth();
  const { mode: themeMode, setMode: setThemeMode } = useTheme();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();
  const { LangToggleBtn } = useLang();

  const [bookings, setBookings]   = useState([]);
  const [bTab, setBTab]           = useState('upcoming');
  const [bLoading, setBLoading]   = useState(true);
  const [barberTab, setBarberTab] = useState('dashboard');
  const [shopTier, setShopTier]   = useState(null);
  const setupPrompted = useRef(false);

  // Customer profile edit
  const [editGender, setEditGender] = useState(null); // null = closed, else 'male'/'female'
  const [savingGender, setSavingGender] = useState(false);
  const [editProfile, setEditProfile] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [profileForm, setProfileForm] = useState({ full_name: '', phone: '' });

  // Load plan perks from app_settings — live, admin-controlled
  const { perks, loading: perksLoading } = usePlanPerks(shopTier || 'basic');

  // Show barber tutorial only once
  const { TutorialEl } = useOnboarding(profile?.role === 'barber' ? 'barber' : null, user);

  useEffect(() => {
    if (!authReady) return;

    if (profile?.role !== 'barber') {
      fetchBookings();
    } else {
      // Load shop tier so plan perks are correct
      supabase.from('shops').select('id, subscription_tier').eq('owner_id', user.id).maybeSingle()
        .then(({ data, error }) => {
          if (data?.subscription_tier) setShopTier(data.subscription_tier);
          // New barber with no shop yet: open Shop Setup first
          if (!error && !data && !setupPrompted.current) { setupPrompted.current = true; setBarberTab('setup'); }
        });
    }
  }, [user, authReady, profile]); // eslint-disable-line

  const fetchBookings = async () => {
    const { data } = await supabase
      .from('bookings')
      .select('*, shops(owner_id, name, address), services(name, price), time_slots(slot_date, start_time)')
      .eq('customer_id', user.id)
      .order('created_at', { ascending: false });
    setBookings(data || []);
    setBLoading(false);
  };

  const cancel = async (id, slotId) => {
    const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', id);
    if (!error) {
      await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
      showToast('success', 'Booking cancelled');
      const b = bookings.find(x => x.id === id);
      if (b?.shops?.owner_id) {
        sendNotification(b.shops.owner_id, {
          title: 'Booking Cancelled',
          body: `A customer cancelled their ${b.services?.name || 'booking'}.`,
          type: 'booking_status',
          meta: { url: '/account' },
        }).catch(() => {});
      }
      fetchBookings();
    } else showToast('error', 'Failed to cancel');
  };

  const handleSignOut = async () => { await signOut(); navigate('/'); };

  const [showNotifDrawer, setShowNotifDrawer] = useState(false);
  const [notifs, setNotifs] = useState([]);
  const [notifLoading, setNotifLoading] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showBarberMore, setShowBarberMore] = useState(false);

  // Load unread count on mount
  useEffect(() => {
    if (!user) return;
    fetchNotifications(user.id).then(data => {
      setNotifs(data);
      setUnreadCount(data.filter(n => !n.is_read).length);
    });
  }, [user]); // eslint-disable-line

  const openNotifs = async () => {
    setShowNotifDrawer(true);
    setNotifLoading(true);
    const data = await fetchNotifications(user.id);
    setNotifs(data);
    setNotifLoading(false);
    setUnreadCount(0);
    await markAllRead(user.id);
  };

  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return (
    <div style={{ minHeight: 'var(--vh100)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 24px 100px', textAlign: 'center' }}>
      {/* Brand icon */}
      <div style={{
        width: 72, height: 72, borderRadius: 22,
        background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        marginBottom: 24, boxShadow: 'var(--shadow-brand)',
      }}>
        {Icon.scissors('#fff')}
      </div>
      <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 26, marginBottom: 8, color: 'var(--text-1)' }}>
        Apna Account
      </h2>
      <p style={{ color: 'var(--text-2)', fontSize: 15, marginBottom: 36, maxWidth: 280, lineHeight: 1.6 }}>
        Bookings dekhne aur manage karne ke liye sign in karo
      </p>
      <button
        className="btn btn-primary"
        style={{ width: '100%', maxWidth: 320, marginBottom: 14 }}
        onClick={() => navigate('/login')}
      >
        Sign In
      </button>
      <button
        className="btn btn-secondary"
        style={{ width: '100%', maxWidth: 320, marginBottom: 14, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10 }}
        onClick={async () => {
          await supabase.auth.signInWithOAuth({
            provider: 'google',
            options: { redirectTo: `${window.location.origin}/auth/callback` }
          });
        }}
      >
        <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.4 29.3 35 24 35c-6.1 0-11-4.9-11-11s4.9-11 11-11c2.8 0 5.3 1 7.3 2.7l5.7-5.7C33.6 6.5 29 4.5 24 4.5 12.9 4.5 4 13.4 4 24.5s8.9 20 20 20 20-8.9 20-20c0-1.4-.1-2.7-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.6 15.9 18.9 13 24 13c2.8 0 5.3 1 7.3 2.7l5.7-5.7C33.6 6.5 29 4.5 24 4.5c-7.7 0-14.3 4.4-17.7 10.2z"/><path fill="#4CAF50" d="M24 44.5c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.6 26.7 36.5 24 36.5c-5.3 0-9.6-3.6-11.2-8.5l-6.5 5C9.6 39.9 16.3 44.5 24 44.5z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.3 4.2-4.2 5.6l6.2 5.2C40.9 36.4 44 30.9 44 24.5c0-1.4-.1-2.7-.4-4z"/></svg>
        Continue with Google
      </button>
      <button
        className="btn"
        style={{ width: '100%', maxWidth: 320, background: 'var(--bg-card)', border: '1px solid var(--border)', color: 'var(--text-1)' }}
        onClick={() => navigate('/register')}
      >
        Register — Free hai
      </button>
    </div>
  );

  const today    = format(new Date(), 'yyyy-MM-dd');
  const upcoming = bookings.filter(b => b.time_slots?.slot_date >= today && b.status !== 'cancelled');
  const past     = bookings.filter(b => b.time_slots?.slot_date < today  || b.status === 'cancelled');
  const list     = bTab === 'upcoming' ? upcoming : past;
  const isBarber = profile?.role === 'barber';

  const saveGender = async (val) => {
    setSavingGender(true);
    await supabase.from('profiles').update({ gender: val }).eq('id', user.id);
    setSavingGender(false);
    setEditGender(null);
    showToast('success', 'Gender updated');
  };

  const saveProfileInfo = async () => {
    if (!profileForm.full_name.trim()) return showToast('error', 'Name cannot be empty');
    setSavingProfile(true);
    await supabase.from('profiles').update({
      full_name: profileForm.full_name.trim(),
      phone: profileForm.phone.trim(),
    }).eq('id', user.id);
    setSavingProfile(false);
    setEditProfile(false);
    refreshProfile();
    showToast('success', 'Profile updated');
  };

  const barberTabs = [
    { id: 'dashboard', label: 'Dashboard', short: 'Dash', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
        <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
      </svg>
    )},
    { id: 'setup', label: 'Setup', short: 'Setup', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
        <polyline points="9 22 9 12 15 12 15 22"/>
      </svg>
    )},
    { id: 'slots', label: 'Slots', short: 'Slots', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
      </svg>
    )},
    { id: 'payment', label: 'Payment', short: 'Pay', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>
      </svg>
    )},
    { id: 'referrals', label: 'Referrals', short: 'Refer', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 12 20 22 4 22 4 12"/>
        <rect x="2" y="7" width="20" height="5"/>
        <line x1="12" y1="22" x2="12" y2="7"/>
        <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/>
        <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
      </svg>
    )},
    { id: 'guide', label: 'Guide', short: 'Guide', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <line x1="12" y1="8" x2="12" y2="12"/>
        <line x1="12" y1="16" x2="12.01" y2="16"/>
      </svg>
    )},
  ];

  const NotifDrawerPortal = showNotifDrawer ? createPortal(
    <div
      onClick={() => setShowNotifDrawer(false)}
      style={{
        position: 'fixed', inset: 0, zIndex: 9998,
        background: 'rgba(0,0,0,0.75)',
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          position: 'absolute', bottom: 0, left: 0, right: 0,
          background: 'var(--bg-card)',
          borderRadius: '22px 22px 0 0',
          maxHeight: '80vh',
          display: 'flex', flexDirection: 'column',
          animation: 'slideUp 0.28s cubic-bezier(0.34,1.2,0.64,1)',
          border: '1px solid var(--border)',
          borderBottom: 'none',
        }}
      >
        {/* Handle */}
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: 12, paddingBottom: 6 }}>
          <div style={{ width: 40, height: 4, borderRadius: 2, background: 'var(--border-strong)' }} />
        </div>
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          padding: '8px 20px 14px',
          borderBottom: '1px solid var(--border)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Bell size={20} color="var(--brand)" />
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--text-1)' }}>
              Notifications
            </span>
          </div>
          <button
            onClick={() => setShowNotifDrawer(false)}
            style={{
              background: 'var(--bg-input)', border: '1px solid var(--border)',
              borderRadius: '50%', width: 32, height: 32,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer', color: 'var(--text-2)', fontSize: 18, lineHeight: 1,
            }}
          >×</button>
        </div>
        {/* Body */}
        <div style={{ overflowY: 'auto', flex: 1, padding: '6px 0 40px' }}>
          {notifLoading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 40 }}>
              <div className="spinner" />
            </div>
          ) : notifs.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '48px 24px' }}>
              <Bell size={40} color="var(--text-3)" />
              <div style={{ fontSize: 15, color: 'var(--text-2)', marginTop: 14, fontWeight: 600 }}>
                Abhi koi notification nahi
              </div>
              <div style={{ fontSize: 12.5, color: 'var(--text-3)', marginTop: 6 }}>
                Bookings aur updates yahan nazar aayenge
              </div>
            </div>
          ) : notifs.map(n => (
            <div key={n.id} style={{
              padding: '14px 20px',
              borderBottom: '1px solid var(--border)',
              background: n.is_read ? 'transparent' : 'var(--brand-glow2)',
              borderLeft: n.is_read ? '3px solid transparent' : '3px solid var(--brand)',
            }}>
              {!n.is_read && (
                <span style={{
                  fontSize: 10, fontWeight: 800, color: 'var(--brand)',
                  background: 'var(--brand-glow)', borderRadius: 6,
                  padding: '2px 7px', marginBottom: 5, display: 'inline-block',
                  textTransform: 'uppercase', letterSpacing: 0.5,
                }}>New</span>
              )}
              <div style={{ fontWeight: 700, fontSize: 14, color: 'var(--text-1)', marginBottom: 4 }}>{n.title}</div>
              <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5 }}>{n.body}</div>
              <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 6 }}>
                {new Date(n.created_at).toLocaleString('en-PK', { dateStyle: 'medium', timeStyle: 'short' })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>,
    document.body
  ) : null;

  if (isBarber) {
    return (
      <div className="page">
        {TutorialEl}
        {ToastEl}
        {NotifDrawerPortal}
        <BarberShell
          user={user} profile={profile} perks={perks} showToast={showToast}
          tab={barberTab} setTab={setBarberTab}
          onNotif={openNotifs} unread={unreadCount}
          themeMode={themeMode} setThemeMode={setThemeMode}
          onSignOut={handleSignOut} LangToggleBtn={LangToggleBtn} navigate={navigate}
        />
      </div>
    );
  }

  return (
    <div className="page">
      {TutorialEl}
      {ToastEl}
      <div className="topnav">
        <div className="topnav-logo">Zen<span style={{ color: 'var(--brand)' }}>tro</span></div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <LangToggleBtn />
          <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Account</span>
        </div>
      </div>

      <div style={{ padding: '20px 20px 0' }}>

        {/* Profile Hero */}
        <div className="fade-up" style={{ marginBottom: 20 }}>
          <div style={{
            background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
            borderRadius: 22, padding: '18px 20px', color: '#fff',
            display: 'flex', alignItems: 'center', gap: 14,
            boxShadow: 'var(--shadow-brand)',
          }}>
            <div style={{
              width: 52, height: 52, borderRadius: 18,
              background: 'rgba(255,255,255,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22,
              flexShrink: 0, border: '2px solid rgba(255,255,255,0.35)',
            }}>
              {profile?.full_name?.[0]?.toUpperCase() || '?'}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17, marginBottom: 2 }}>
                {profile?.full_name}
              </div>
              <div style={{ fontSize: 12, opacity: 0.8, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 6 }}>
                {user.email}
              </div>
              <span style={{ background: 'rgba(255,255,255,0.2)', borderRadius: 100, padding: '2px 10px',
                fontSize: 10, fontWeight: 700, fontFamily: 'var(--font-display)', textTransform: 'capitalize' }}>
                {profile?.role}
              </span>
            </div>
            <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
              <button onClick={openNotifs} style={{
                position: 'relative',
                background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.25)',
                borderRadius: 12, padding: '9px 12px', color: '#fff', cursor: 'pointer',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <Bell size={17} color="#fff" />
                {unreadCount > 0 && (
                  <span style={{
                    position: 'absolute', top: 4, right: 4,
                    background: '#FF3B30',
                    borderRadius: '50%', width: 8, height: 8,
                    border: '2px solid var(--brand)',
                  }} />
                )}
              </button>
              <button onClick={handleSignOut} style={{
                background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.25)',
                borderRadius: 12, padding: '9px 12px', color: '#fff', cursor: 'pointer',
                display: 'flex', alignItems: 'center', gap: 6,
              }}>
                {Icon.signout()}
              </button>
            </div>
          </div>
        </div>

        {/* Appearance — theme toggle, visible to everyone */}
        <div className="card fade-up" style={{ marginBottom: 18, padding: '14px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)', flexShrink: 0 }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
              </svg>
            </div>
            <div style={{ fontWeight: 700, fontSize: 13.5 }}>Appearance</div>
          </div>
          <div style={{ display: 'flex', background: 'var(--bg-input)', borderRadius: 10, padding: 3, gap: 2 }}>
            {['system', 'light', 'dark'].map(opt => (
              <button key={opt} onClick={() => setThemeMode(opt)}
                style={{
                  border: 'none', borderRadius: 8, padding: '6px 10px', fontSize: 11.5, fontWeight: 700,
                  cursor: 'pointer', textTransform: 'capitalize', fontFamily: 'var(--font-display)',
                  background: themeMode === opt ? 'var(--bg-card)' : 'transparent',
                  color: themeMode === opt ? 'var(--brand)' : 'var(--text-3)',
                  boxShadow: themeMode === opt ? 'var(--shadow-card)' : 'none',
                }}>
                {opt}
              </button>
            ))}
          </div>
        </div>

        <PushSettingRow />

        {/* BARBER: Tab bar */}
        {isBarber && (
          <>
            {/* ── Barber Nav: 3 priority tabs + a "More" pill for the rest, instead of one flat scroll of 6 ── */}
            {(() => {
              const PRIMARY_IDS = ['dashboard', 'slots', 'payment'];
              const MORE_IDS = ['setup', 'referrals', 'guide'];
              const primaryTabs = barberTabs.filter(t => PRIMARY_IDS.includes(t.id));
              const moreTabs = barberTabs.filter(t => MORE_IDS.includes(t.id));
              const isInMore = MORE_IDS.includes(barberTab);
              return (
                <div style={{ marginBottom: 20 }}>
                  <div style={{ display: 'flex', gap: 8 }}>
                    {primaryTabs.map(t => {
                      const active = barberTab === t.id;
                      return (
                        <button key={t.id} onClick={() => { setBarberTab(t.id); setShowBarberMore(false); }} style={{
                          flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
                          padding: '12px 8px', borderRadius: 14,
                          border: active ? 'none' : '1.5px solid var(--border)',
                          cursor: 'pointer', transition: 'all 0.18s',
                          background: active ? 'var(--brand)' : 'var(--bg-card)',
                          color: active ? '#fff' : 'var(--text-2)',
                          boxShadow: active ? '0 4px 14px rgba(0,128,255,0.35)' : 'none',
                        }}>
                          {t.icon(active ? '#fff' : 'var(--text-2)')}
                          <span style={{ fontSize: 11, fontFamily: 'var(--font-display)', fontWeight: 700 }}>{t.label}</span>
                        </button>
                      );
                    })}
                    <button onClick={() => setShowBarberMore(v => !v)} style={{
                      flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
                      padding: '12px 8px', borderRadius: 14,
                      border: (isInMore || showBarberMore) ? 'none' : '1.5px solid var(--border)',
                      cursor: 'pointer', transition: 'all 0.18s',
                      background: (isInMore || showBarberMore) ? 'var(--brand)' : 'var(--bg-card)',
                      color: (isInMore || showBarberMore) ? '#fff' : 'var(--text-2)',
                      boxShadow: (isInMore || showBarberMore) ? '0 4px 14px rgba(0,128,255,0.35)' : 'none',
                    }}>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>
                      </svg>
                      <span style={{ fontSize: 11, fontFamily: 'var(--font-display)', fontWeight: 700 }}>More</span>
                    </button>
                  </div>

                  {showBarberMore && (
                    <div className="fade-in" style={{ display: 'flex', flexDirection: 'column', gap: 6, marginTop: 8 }}>
                      {moreTabs.map(t => {
                        const active = barberTab === t.id;
                        return (
                          <button key={t.id} onClick={() => { setBarberTab(t.id); setShowBarberMore(false); }} style={{
                            display: 'flex', alignItems: 'center', gap: 10,
                            padding: '11px 14px', borderRadius: 12, textAlign: 'left',
                            border: `1.5px solid ${active ? 'var(--border-brand)' : 'var(--border)'}`,
                            background: active ? 'var(--brand-glow)' : 'var(--bg-card)',
                            color: active ? 'var(--brand)' : 'var(--text-2)',
                            cursor: 'pointer',
                          }}>
                            {t.icon(active ? 'var(--brand)' : 'var(--text-2)')}
                            <span style={{ fontSize: 13, fontFamily: 'var(--font-display)', fontWeight: 700 }}>{t.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })()}

            <div className="fade-in">
              {barberTab === 'dashboard' && <DashboardTab user={user} showToast={showToast} perks={perks} />}
              {barberTab === 'setup'     && <SetupTab     user={user} showToast={showToast} perks={perks} />}
              {barberTab === 'slots'     && <SlotsTab     user={user} showToast={showToast} />}
              {barberTab === 'payment'   && <PaymentTab   user={user} showToast={showToast} />}
              {barberTab === 'referrals' && (
                <div>
                  <SectionLabel>Refer Barbers</SectionLabel>
                  <BarberReferralCardDB userId={user?.id} showToast={showToast} />
                </div>
              )}
              {barberTab === 'guide'     && <BarberGuide />}
            </div>
          </>
        )}

        {/* CUSTOMER: Bookings */}
        {!isBarber && (
          <>
            <button onClick={() => window.dispatchEvent(new Event('zentro:open-support'))} className="card" style={{
              width: '100%', marginBottom: 18, padding: '14px 18px', cursor: 'pointer', textAlign: 'left',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between', color: 'var(--text-1)',
            }}>
              <span style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-display)' }}>Support</span>
              <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Chat with Zentro</span>
            </button>
            {/* Profile Info card — name & phone, editable */}
            <div className="card fade-up" style={{ marginBottom: 18, padding: '16px 18px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: editProfile ? 14 : 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--brand-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)', flexShrink: 0 }}>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>{profile?.full_name || 'Add your name'}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 1 }}>
                      {profile?.phone || 'No phone number'}
                    </div>
                  </div>
                </div>
                <button onClick={() => {
                  if (!editProfile) setProfileForm({ full_name: profile?.full_name || '', phone: profile?.phone || '' });
                  setEditProfile(!editProfile);
                }}
                  style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 10, padding: '6px 14px', fontSize: 12.5, fontWeight: 700, color: 'var(--brand)', cursor: 'pointer', fontFamily: 'var(--font-display)' }}>
                  {editProfile ? 'Cancel' : 'Edit'}
                </button>
              </div>
              {editProfile && (
                <div>
                  <div className="input-group" style={{ marginBottom: 10 }}>
                    <label className="input-label">Full Name</label>
                    <input className="input" value={profileForm.full_name}
                      onChange={e => setProfileForm(p => ({ ...p, full_name: e.target.value }))} />
                  </div>
                  <div className="input-group" style={{ marginBottom: 12 }}>
                    <label className="input-label">Phone</label>
                    <input className="input" type="tel" placeholder="03xxxxxxxxx" value={profileForm.phone}
                      onChange={e => setProfileForm(p => ({ ...p, phone: e.target.value }))} />
                  </div>
                  <button className="btn btn-primary btn-sm" onClick={saveProfileInfo} disabled={savingProfile} style={{ width: '100%' }}>
                    {savingProfile ? <span className="spinner spinner-sm" /> : 'Save'}
                  </button>
                </div>
              )}
            </div>

            {/* Profile / Gender card */}
            <div className="card fade-up" style={{ marginBottom: 18, padding: '16px 18px' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: editGender !== null ? 14 : 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--brand-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)', flexShrink: 0 }}>
                    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                    </svg>
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14 }}>Gender</div>
                    <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 1, textTransform: 'capitalize' }}>
                      {profile?.gender || 'Not set'}
                    </div>
                  </div>
                </div>
                <button onClick={() => setEditGender(editGender !== null ? null : (profile?.gender || 'male'))}
                  style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 10, padding: '6px 14px', fontSize: 12.5, fontWeight: 700, color: 'var(--brand)', cursor: 'pointer', fontFamily: 'var(--font-display)' }}>
                  {editGender !== null ? 'Cancel' : 'Edit'}
                </button>
              </div>
              {editGender !== null && (
                <div>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                    {[
                      { value: 'male', label: 'Male', icon: (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="10" cy="14" r="6"/><line x1="14.5" y1="9.5" x2="20" y2="4"/><polyline points="16 4 20 4 20 8"/>
                        </svg>
                      )},
                      { value: 'female', label: 'Female', icon: (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <circle cx="12" cy="8" r="6"/><line x1="12" y1="14" x2="12" y2="20"/><line x1="9" y1="17" x2="15" y2="17"/>
                        </svg>
                      )},
                    ].map(g => (
                      <button key={g.value} onClick={() => setEditGender(g.value)} style={{
                        flex: 1, padding: '11px', borderRadius: 12,
                        border: `1.5px solid ${editGender === g.value ? 'var(--brand)' : 'var(--border)'}`,
                        background: editGender === g.value ? 'var(--brand-glow)' : 'var(--bg-input)',
                        color: editGender === g.value ? 'var(--brand)' : 'var(--text-2)',
                        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                        fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer', fontSize: 13.5,
                      }}>
                        {g.icon} {g.label}
                      </button>
                    ))}
                  </div>
                  <button className="btn btn-primary btn-sm" onClick={() => saveGender(editGender)} disabled={savingGender} style={{ width: '100%' }}>
                    {savingGender ? <span className="spinner spinner-sm" style={{ borderTopColor: '#fff' }} /> : 'Save'}
                  </button>
                </div>
              )}
            </div>

            <div
              className="card tap-feedback fade-up"
              onClick={() => navigate('/invite')}
              style={{
                display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18,
                cursor: 'pointer', border: '1.5px solid var(--border-brand)',
                background: 'var(--brand-glow2)',
              }}
            >
              <div style={{
                width: 42, height: 42, borderRadius: 12, flexShrink: 0,
                background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {Icon.scissors('#fff')}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>Invite Friends</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-2)' }}>Earn booking credits for every signup</div>
              </div>
              <span style={{ color: 'var(--brand)', fontSize: 18, flexShrink: 0 }}>›</span>
            </div>

            {/* Wallet Card — navigate to full wallet page for customers */}
            <div
              className="card tap-feedback fade-up"
              onClick={() => navigate('/wallet')}
              style={{
                display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18,
                cursor: 'pointer', border: '1.5px solid rgba(99,102,241,0.3)',
                background: 'rgba(99,102,241,0.06)',
              }}
            >
              <div style={{
                width: 42, height: 42, borderRadius: 12, flexShrink: 0,
                background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>
                </svg>
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>My Wallet</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-2)' }}>Credits · Send money · Pay barbers</div>
              </div>
              <span style={{ color: '#6366f1', fontSize: 18, flexShrink: 0 }}>›</span>
            </div>

            <div style={{ marginBottom: 18 }}>
              <WalletCard userId={user.id} mode={isBarber ? "barber" : "customer"} />
            </div>

            <ReminderPrefs user={user} profile={profile} refreshProfile={refreshProfile} showToast={showToast} />

            <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
              {['upcoming', 'past'].map(t => (
                <button key={t} onClick={() => setBTab(t)}
                  className={`chip${bTab === t ? ' active' : ''}`}
                  style={{ textTransform: 'capitalize' }}>
                  {t} ({t === 'upcoming' ? upcoming.length : past.length})
                </button>
              ))}
            </div>
            {bLoading ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[1, 2].map(i => <div key={i} className="skeleton" style={{ height: 130, borderRadius: 18 }} />)}
              </div>
            ) : list.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '48px 0' }}>
                <div style={{ width: 56, height: 56, borderRadius: 18, background: 'var(--brand-glow)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
                  {Icon.scissors()}
                </div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--text-1)', marginBottom: 6 }}>
                  {bTab === 'upcoming' ? 'No upcoming bookings' : 'No past bookings'}
                </div>
                <div style={{ fontSize: 13, color: 'var(--text-3)', marginBottom: 20 }}>
                  Browse shops and book your next cut
                </div>
                <button className="btn btn-primary btn-sm" onClick={() => navigate('/')}>Explore Shops</button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {list.map((b, i) => (
                  <div key={b.id} className="fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
                    <BookingCard booking={b} onCancel={() => cancel(b.id, b.time_slot_id)} />
                  </div>
                ))}
              </div>
            )}
          </>
        )}
        <div style={{ height: 80 }} />

        {/* ── Notification Drawer ── */}
        {NotifDrawerPortal}
      </div>
    </div>
  );
}
