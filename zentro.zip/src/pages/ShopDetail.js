import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { format, addDays } from 'date-fns';
import { Scissors, MapPin, Clock, StarFilled, Search } from '../lib/icons';

const PLAN_DEFAULTS = {
  basic:   { badge: false, priority: false },
  pro:     { badge: false, priority: true  },
  premium: { badge: true,  priority: true  },
};

function StarRating({ value, onChange, size = 28 }) {
  const [hovered, setHovered] = useState(0);
  return (
    <div style={{ display: 'flex', gap: 4 }}>
      {[1, 2, 3, 4, 5].map(n => (
        <span
          key={n}
          onClick={() => onChange && onChange(n)}
          onMouseEnter={() => onChange && setHovered(n)}
          onMouseLeave={() => onChange && setHovered(0)}
          style={{
            fontSize: size,
            cursor: onChange ? 'pointer' : 'default',
            color: n <= (hovered || value) ? '#FF9500' : 'var(--border-strong)',
            transition: 'color 0.15s',
            lineHeight: 1,
            userSelect: 'none',
          }}
        >★</span>
      ))}
    </div>
  );
}

export default function ShopDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { showToast, ToastEl } = useToast();

  const [shop, setShop]           = useState(null);
  const [services, setServices]   = useState([]);
  const [reviews, setReviews]     = useState([]);
  const [slots, setSlots]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [plansConfig, setPlansConfig] = useState(PLAN_DEFAULTS);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedSrv, setSelectedSrv]   = useState(null);
  const [booking, setBooking]     = useState(false);
  const [imgIdx, setImgIdx]       = useState(0);

  // Review state
  const [userReview, setUserReview]       = useState(null);   // existing review by this user
  const [completedBooking, setCompletedBooking] = useState(null); // a completed booking (eligibility)
  const [showReviewForm, setShowReviewForm]   = useState(false);
  const [reviewRating, setReviewRating]       = useState(5);
  const [reviewComment, setReviewComment]     = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    fetchShop();
    supabase.from('app_settings').select('value').eq('key', 'plans_config').maybeSingle().then(({ data }) => {
      if (data?.value) {
        try {
          const parsed = JSON.parse(data.value);
          setPlansConfig(t => {
            const merged = {};
            for (const k of ['basic', 'pro', 'premium']) merged[k] = { ...PLAN_DEFAULTS[k], ...(parsed[k] || {}) };
            return merged;
          });
        } catch {}
      }
    });
  }, [id]);

  useEffect(() => { fetchSlots(); }, [id, selectedDate]);

  useEffect(() => {
    if (user) checkUserReviewEligibility();
  }, [user, id]);

  const fetchShop = async () => {
    const [{ data: s }, { data: srv }, { data: rev }] = await Promise.all([
      supabase.from('shops').select('*').eq('id', id).maybeSingle(),
      supabase.from('services').select('*').eq('shop_id', id).eq('is_active', true),
      supabase.from('reviews').select('*, profiles(full_name)').eq('shop_id', id).order('created_at', { ascending: false }).limit(20),
    ]);
    setShop(s);
    setServices(srv || []);
    setReviews(rev || []);
    setLoading(false);
  };

  const fetchSlots = async () => {
    const { data } = await supabase
      .from('time_slots')
      .select('*')
      .eq('shop_id', id)
      .eq('slot_date', selectedDate)
      .eq('is_booked', false)
      .order('start_time');
    setSlots(data || []);
  };

  const checkUserReviewEligibility = async () => {
    // Check if user has already left a review
    const { data: existing } = await supabase
      .from('reviews')
      .select('*')
      .eq('shop_id', id)
      .eq('customer_id', user.id)
      .maybeSingle();
    setUserReview(existing || null);

    // Check if user has a completed booking at this shop
    const { data: completed } = await supabase
      .from('bookings')
      .select('id')
      .eq('shop_id', id)
      .eq('customer_id', user.id)
      .eq('status', 'completed')
      .limit(1)
      .maybeSingle();
    setCompletedBooking(completed || null);
  };

  const bookSlot = async () => {
    if (!user) return navigate('/login');
    if (!selectedSlot || !selectedSrv) return showToast('error', 'Select a service and time slot');
    setBooking(true);

    const { data: newBooking, error } = await supabase.from('bookings').insert({
      shop_id: id,
      customer_id: user.id,
      time_slot_id: selectedSlot.id,
      service_id: selectedSrv.id,
      status: 'pending',
    }).select('id').single();

    if (!error) {
      await supabase.from('time_slots').update({ is_booked: true }).eq('id', selectedSlot.id);
      showToast('success', 'Booking confirmed!');
      setSelectedSlot(null);
      fetchSlots();
      // Fire push notifications (non-blocking)
      if (newBooking?.id) {
        supabase.functions.invoke('send-push', {
          body: { booking_id: newBooking.id },
        }).catch(() => {}); // silent fail — don't block booking flow
      }
    } else {
      console.error('[DB] booking error:', error);
      showToast('error', 'Booking failed: ' + error.message);
    }
    setBooking(false);
  };

  const submitReview = async () => {
    if (!user) return navigate('/login');
    if (reviewRating < 1) return showToast('error', 'Please select a rating');
    setSubmittingReview(true);

    if (userReview) {
      // Update existing review
      const { error } = await supabase
        .from('reviews')
        .update({ rating: reviewRating, comment: reviewComment.trim() || null })
        .eq('id', userReview.id);
      if (!error) {
        showToast('success', 'Review updated!');
        setUserReview({ ...userReview, rating: reviewRating, comment: reviewComment.trim() });
        setShowReviewForm(false);
        fetchShop();
      } else {
        showToast('error', 'Failed to update review');
      }
    } else {
      // Insert new review
      const { error } = await supabase.from('reviews').insert({
        shop_id: id,
        customer_id: user.id,
        rating: reviewRating,
        comment: reviewComment.trim() || null,
      });
      if (!error) {
        showToast('success', 'Review submitted! Thank you.');
        setShowReviewForm(false);
        checkUserReviewEligibility();
        fetchShop();
      } else if (error.code === '23505') {
        showToast('error', 'You already reviewed this shop');
      } else {
        showToast('error', 'Failed to submit review');
      }
    }
    setSubmittingReview(false);
  };

  const avgRating = reviews.length > 0
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length)
    : null;

  // Generate next 7 days
  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { value: format(d, 'yyyy-MM-dd'), label: format(d, 'EEE'), day: format(d, 'd') };
  });

  if (loading) return (
    <div className="loading-screen">
      <div className="spinner" />
    </div>
  );

  if (!shop) return (
    <div className="empty-state" style={{ minHeight: '100dvh' }}>
      <div className="empty-icon"><Search size={36} color="var(--text-3)" /></div>
      <div className="empty-title">Shop not found</div>
      <button className="btn btn-secondary btn-sm" onClick={() => navigate('/')}>Go Home</button>
    </div>
  );

  const imgs = shop.images || [];
  const canReview = user && completedBooking;

  return (
    <div className="page">
      {ToastEl}

      {/* Back */}
      <div style={{ position: 'absolute', top: 16, left: 16, zIndex: 10 }}>
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
      </div>

      {/* Images */}
      <div style={{ position: 'relative', height: 260, background: 'var(--bg-input)', overflow: 'hidden' }}>
        {imgs.length > 0 ? (
          <img src={imgs[imgIdx]} alt={shop.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : (
          <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Scissors size={64} color="var(--text-3)" /></div>
        )}
        {imgs.length > 1 && (
          <div style={{ position: 'absolute', bottom: 12, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 6 }}>
            {imgs.map((_, i) => (
              <div key={i} onClick={() => setImgIdx(i)}
                style={{ width: i === imgIdx ? 20 : 6, height: 6, borderRadius: 3,
                  background: i === imgIdx ? 'var(--brand)' : 'rgba(255,255,255,0.4)',
                  transition: 'all 0.2s', cursor: 'pointer' }} />
            ))}
          </div>
        )}
      </div>

      <div style={{ padding: '20px 20px 0' }}>
        {/* Shop Info */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
            <h1 style={{ fontSize: 26 }}>{shop.name}</h1>
            {plansConfig[shop.subscription_tier]?.badge === true && shop.subscription_tier !== 'basic' && (
              <span className="badge badge-brand">{shop.subscription_tier}</span>
            )}
          </div>
          <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}><MapPin size={14} color="var(--text-3)" /> {shop.address}, {shop.city}</p>

          {/* Rating Summary */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            {avgRating ? (
              <>
                <StarRating value={Math.round(avgRating)} size={18} />
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: 'var(--text-1)' }}>
                  {avgRating.toFixed(1)}
                </span>
                <span style={{ fontSize: 13, color: 'var(--text-2)' }}>({reviews.length} review{reviews.length !== 1 ? 's' : ''})</span>
              </>
            ) : (
              <span style={{ fontSize: 13, color: 'var(--text-3)' }}>No reviews yet</span>
            )}
          </div>

          {shop.description && <p style={{ color: 'var(--text-2)', fontSize: 14, lineHeight: 1.6 }}>{shop.description}</p>}
        </div>

        {/* Services */}
        {services.length > 0 && (
          <div style={{ marginBottom: 28 }}>
            <p className="section-label">Services</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {services.map((srv, i) => (
                <div key={srv.id} onClick={() => setSelectedSrv(selectedSrv?.id === srv.id ? null : srv)}
                  className="tap-feedback fade-up"
                  style={{
                    padding: '14px 16px', borderRadius: 'var(--radius)',
                    border: `1.5px solid ${selectedSrv?.id === srv.id ? 'var(--brand)' : 'var(--border)'}`,
                    background: selectedSrv?.id === srv.id ? 'var(--brand-dim)' : 'var(--bg-card)',
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    cursor: 'pointer', transition: 'all 0.2s',
                    animationDelay: `${Math.min(i * 0.04, 0.3)}s`,
                  }}>
                  <div>
                    <div style={{ fontWeight: 600, fontFamily: 'var(--font-display)', marginBottom: 2 }}>{srv.name}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-2)' }}>{srv.duration_minutes} min</div>
                  </div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--brand)', fontSize: 16 }}>
                    Rs {srv.price}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Date Picker */}
        <div style={{ marginBottom: 20 }}>
          <p className="section-label">Pick a Date</p>
          <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 8 }}>
            {dates.map(d => (
              <button key={d.value} onClick={() => { setSelectedDate(d.value); setSelectedSlot(null); }}
                style={{
                  flexShrink: 0, width: 56, padding: '10px 0',
                  borderRadius: 'var(--radius-sm)', border: `1.5px solid ${selectedDate === d.value ? 'var(--brand)' : 'var(--border)'}`,
                  background: selectedDate === d.value ? 'var(--brand-dim)' : 'var(--bg-input)',
                  color: selectedDate === d.value ? 'var(--brand)' : 'var(--text-2)',
                  fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2
                }}>
                <span style={{ fontSize: 10, textTransform: 'uppercase' }}>{d.label}</span>
                <span style={{ fontSize: 18 }}>{d.day}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Time Slots */}
        <div style={{ marginBottom: 28 }}>
          <p className="section-label">Available Slots</p>
          {slots.length === 0 ? (
            <div className="empty-state" style={{ padding: '30px 0' }}>
              <div className="empty-icon"><Clock size={32} color="var(--text-3)" /></div>
              <div className="empty-sub">No slots available for this date</div>
            </div>
          ) : (
            <div key={selectedDate} style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {slots.map((slot, i) => (
                <button key={slot.id} onClick={() => setSelectedSlot(selectedSlot?.id === slot.id ? null : slot)}
                  className={`chip pop-in${selectedSlot?.id === slot.id ? ' active' : ''}`}
                  style={{ animationDelay: `${Math.min(i * 0.025, 0.25)}s` }}>
                  {slot.start_time.slice(0, 5)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Book Button */}
        <button className="btn btn-primary" onClick={bookSlot} disabled={booking || !selectedSlot || !selectedSrv}
          style={{ marginBottom: 32 }}>
          {booking ? <span className="spinner spinner-sm" /> : `Book — ${selectedSrv ? `Rs ${selectedSrv.price}` : 'Select Service & Slot'}`}
        </button>

        {/* ── Reviews Section ── */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <p className="section-label" style={{ margin: 0 }}>Reviews</p>
            {canReview && !showReviewForm && (
              <button
                onClick={() => {
                  if (userReview) {
                    setReviewRating(userReview.rating);
                    setReviewComment(userReview.comment || '');
                  }
                  setShowReviewForm(true);
                }}
                style={{
                  fontSize: 13, fontWeight: 600, fontFamily: 'var(--font-display)',
                  color: 'var(--brand)', background: 'var(--brand-dim)',
                  border: '1.5px solid var(--border-brand)', borderRadius: 'var(--radius-xs)',
                  padding: '6px 14px', cursor: 'pointer'
                }}>
                {userReview ? 'Edit Review' : '+ Write Review'}
              </button>
            )}
            {!user && (
              <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Login to review</span>
            )}
            {user && !completedBooking && !userReview && (
              <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Visit to review</span>
            )}
          </div>

          {/* Review Form */}
          {showReviewForm && (
            <div style={{
              background: 'var(--bg-card)', border: '1.5px solid var(--border-brand)',
              borderRadius: 'var(--radius)', padding: 18, marginBottom: 16,
              boxShadow: 'var(--shadow-brand)'
            }}>
              <p style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14 }}>
                {userReview ? 'Update your review' : 'Rate your experience'}
              </p>

              {/* Star picker */}
              <div style={{ marginBottom: 14 }}>
                <StarRating value={reviewRating} onChange={setReviewRating} size={34} />
              </div>

              {/* Comment */}
              <textarea
                value={reviewComment}
                onChange={e => setReviewComment(e.target.value)}
                placeholder="Share your experience... (optional)"
                rows={3}
                style={{
                  width: '100%', background: 'var(--bg-input)', border: '1.5px solid var(--border)',
                  borderRadius: 'var(--radius-sm)', padding: '12px 14px',
                  color: 'var(--text-1)', fontFamily: 'var(--font-body)', fontSize: 14,
                  resize: 'none', outline: 'none', marginBottom: 14, lineHeight: 1.5
                }}
              />

              <div style={{ display: 'flex', gap: 10 }}>
                <button className="btn btn-primary" onClick={submitReview} disabled={submittingReview}
                  style={{ flex: 1, padding: '12px 0' }}>
                  {submittingReview ? <span className="spinner spinner-sm" /> : (userReview ? 'Update' : 'Submit')}
                </button>
                <button onClick={() => setShowReviewForm(false)}
                  style={{
                    flex: 1, padding: '12px 0', borderRadius: 'var(--radius)',
                    border: '1.5px solid var(--border)', background: 'var(--bg-input)',
                    color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 600,
                    fontSize: 15, cursor: 'pointer'
                  }}>
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Review List */}
          {reviews.length === 0 ? (
            <div className="empty-state" style={{ padding: '28px 0' }}>
              <div className="empty-icon" style={{ display: 'flex', justifyContent: 'center' }}><StarFilled size={32} color="var(--text-3)" /></div>
              <div className="empty-sub">Be the first to review this shop</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {reviews.map((r, i) => (
                <div key={r.id} className="card card-sm stagger-in"
                  style={{
                    border: userReview?.id === r.id ? '1.5px solid var(--border-brand)' : undefined,
                    background: userReview?.id === r.id ? 'var(--brand-dim)' : undefined,
                    animationDelay: `${Math.min(i * 0.04, 0.3)}s`,
                  }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{
                        width: 30, height: 30, borderRadius: '50%',
                        background: 'var(--brand)', display: 'flex', alignItems: 'center',
                        justifyContent: 'center', color: '#fff',
                        fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, flexShrink: 0
                      }}>
                        {(r.profiles?.full_name || 'C')[0].toUpperCase()}
                      </div>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 13, fontFamily: 'var(--font-display)', lineHeight: 1 }}>
                          {r.profiles?.full_name || 'Customer'}
                          {userReview?.id === r.id && (
                            <span style={{ marginLeft: 6, fontSize: 11, color: 'var(--brand)', fontWeight: 600 }}>You</span>
                          )}
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>
                          {format(new Date(r.created_at), 'MMM d, yyyy')}
                        </div>
                      </div>
                    </div>
                    <StarRating value={r.rating} size={15} />
                  </div>
                  {r.comment && (
                    <p style={{ color: 'var(--text-2)', fontSize: 13, lineHeight: 1.55, marginLeft: 38 }}>{r.comment}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
