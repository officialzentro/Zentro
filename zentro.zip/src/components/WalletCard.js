import { useEffect, useState } from 'react';
import { fetchMyCredits } from '../lib/referrals';

// Timer SVG
const TimerIcon = () => (
  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="9"/>
    <polyline points="12 6 12 12 16 14"/>
    <polyline points="9 1 12 1 15 1"/>
  </svg>
);

const GiftIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 12 20 22 4 22 4 12"/>
    <rect x="2" y="7" width="20" height="5"/>
    <line x1="12" y1="22" x2="12" y2="7"/>
    <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/>
    <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
  </svg>
);

// mode: 'barber' = only show subscription days (referral reward)
//       'customer' = show booking credits (default legacy behaviour)
export default function WalletCard({ userId, mode = 'barber' }) {
  const [data, setData]     = useState({ creditTotal: 0, subscriptionDaysTotal: 0, rows: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!userId) return;
    fetchMyCredits(userId).then(d => { setData(d); setLoading(false); });
  }, [userId]);

  if (loading) {
    return <div className="skeleton" style={{ height: 96, borderRadius: 'var(--radius)' }} />;
  }

  const { creditTotal, subscriptionDaysTotal, rows } = data;

  // For barbers: only care about subscription days from referrals
  const hasDays    = subscriptionDaysTotal > 0;
  const hasCredits = mode === 'customer' && creditTotal > 0;

  if (!hasDays && !hasCredits) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '24px 16px' }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 8 }}>
          <GiftIcon />
        </div>
        <div style={{ fontWeight: 700, fontSize: 14.5, marginBottom: 2 }}>No referral rewards yet</div>
        <div style={{ fontSize: 12.5, color: 'var(--text-2)' }}>Refer other barbers to earn free subscription days</div>
      </div>
    );
  }

  const dayRows = rows.filter(r => r.kind === 'subscription_days');
  const creditRows = rows.filter(r => r.kind === 'credit');

  return (
    <div>
      {/* Subscription Days card (barber referral reward) */}
      {hasDays && (
        <div className="wallet-card" style={{
          background: 'linear-gradient(135deg, #CC8E00 0%, #FFB800 100%)',
          boxShadow: '0 8px 28px rgba(255,184,0,0.32)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8, opacity: 0.9 }}>
            <TimerIcon />
            <span style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6 }}>Free Subscription Days</span>
          </div>
          <div className="wallet-amount">{subscriptionDaysTotal} day{subscriptionDaysTotal !== 1 ? 's' : ''}</div>
          <div style={{ fontSize: 12.5, opacity: 0.9, marginTop: 4 }}>Added to your next renewal automatically</div>
        </div>
      )}

      {/* Booking Credits (customers only) */}
      {hasCredits && (
        <div className="wallet-card" style={{ marginTop: hasDays ? 14 : 0 }}>
          <div style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6, marginBottom: 8, opacity: 0.85 }}>
            Booking Credits
          </div>
          <div className="wallet-amount">Rs {creditTotal.toLocaleString()}</div>
          <div style={{ fontSize: 12.5, opacity: 0.85, marginTop: 4 }}>Applied automatically at checkout</div>
        </div>
      )}

      {/* Recent activity */}
      {(hasDays || hasCredits) && (dayRows.length > 0 || creditRows.length > 0) && (
        <>
          <div className="wallet-section-label">Recent Rewards</div>
          <div className="card" style={{ padding: '4px 16px' }}>
            {(mode === 'barber' ? dayRows : rows).slice(0, 6).map((r, i) => (
              <div key={r.id} className="ref-row stagger-in" style={{ animationDelay: `${i * 0.03}s` }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 13 }}>
                    {r.source === 'referral' ? 'Barber Referral' : r.source === 'admin' ? 'Admin Grant' : 'Reward'}
                  </div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-3)' }}>
                    {new Date(r.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })}
                  </div>
                </div>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14, color: r.kind === 'subscription_days' ? '#CC8E00' : 'var(--brand)' }}>
                  +{r.amount} {r.kind === 'subscription_days' ? 'day' + (r.amount !== 1 ? 's' : '') : 'Rs'}
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
