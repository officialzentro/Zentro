import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import {
  getOrCreateOpenTicket, fetchTicketMessages, sendTicketMessage, subscribeToTicket,
} from '../lib/support';

export default function SupportChat() {
  const { user, profile, authReady } = useAuth();
  const [open, setOpen]       = useState(false);
  const [ticket, setTicket]   = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText]       = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    if (!open || !user) return;
    let unsub = () => {};
    (async () => {
      setLoading(true);
      const t = await getOrCreateOpenTicket(user.id);
      setTicket(t);
      if (t) {
        const msgs = await fetchTicketMessages(t.id);
        setMessages(msgs);
        unsub = subscribeToTicket(t.id, (m) => setMessages(prev => [...prev, m]));
      }
      setLoading(false);
    })();
    return () => unsub();
  }, [open, user]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!text.trim() || !ticket) return;
    const role = profile?.role === 'barber' ? 'barber' : 'customer';
    const msg = await sendTicketMessage(ticket.id, user.id, role, text);
    if (msg) setMessages(prev => [...prev, msg]);
    setText('');
  };

  // Only show for logged-in users; not on auth pages, not before auth resolves
  if (!authReady || !user) return null;

  return (
    <>
      {/* Floating launcher button */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Customer support"
          style={{
            position: 'fixed', right: 16, bottom: 'calc(var(--bottom-h) + 16px)',
            zIndex: 200, width: 52, height: 52, borderRadius: '50%',
            background: 'var(--brand)', color: '#fff', border: 'none', cursor: 'pointer',
            boxShadow: 'var(--shadow-brand)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}
        >
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
          </svg>
        </button>
      )}

      {/* Chat panel */}
      {open && (
        <div
          style={{
            position: 'fixed', inset: 0, zIndex: 300,
            background: 'rgba(6,14,30,0.4)',
            display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
          }}
          onClick={() => setOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="fade-up"
            style={{
              width: '100%', maxWidth: 480, height: '70dvh',
              background: 'var(--bg-card)', borderRadius: '20px 20px 0 0',
              display: 'flex', flexDirection: 'column', overflow: 'hidden',
              boxShadow: 'var(--shadow-md)',
            }}
          >
            {/* Header */}
            <div style={{
              padding: '16px 18px', borderBottom: '1px solid var(--border)',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            }}>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16 }}>Support</div>
                <div style={{ fontSize: 12, color: 'var(--text-2)' }}>We usually reply within a day</div>
              </div>
              <button onClick={() => setOpen(false)} style={{
                width: 32, height: 32, borderRadius: 8, background: 'var(--bg-input)',
                border: 'none', cursor: 'pointer', fontSize: 16, color: 'var(--text-2)',
              }}>✕</button>
            </div>

            {/* Messages */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {loading && <div className="spinner" style={{ margin: '20px auto' }} />}
              {!loading && messages.length === 0 && (
                <div className="empty-state" style={{ padding: '30px 10px' }}>
                  <div className="empty-sub">Send us a message and we'll get back to you here.</div>
                </div>
              )}
              {messages.map(m => {
                const mine = m.sender_id === user.id;
                return (
                  <div key={m.id} style={{
                    alignSelf: mine ? 'flex-end' : 'flex-start',
                    maxWidth: '78%',
                    background: mine ? 'var(--brand)' : 'var(--bg-input)',
                    color: mine ? '#fff' : 'var(--text-1)',
                    borderRadius: 14,
                    padding: '9px 13px',
                    fontSize: 14, lineHeight: 1.4,
                  }}>
                    {!mine && (
                      <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-3)', marginBottom: 2 }}>
                        {m.sender_role === 'admin' ? 'Zentro Support' : m.sender_role}
                      </div>
                    )}
                    {m.message}
                  </div>
                );
              })}
              <div ref={bottomRef} />
            </div>

            {/* Composer */}
            <div style={{ display: 'flex', gap: 8, padding: '12px 14px', borderTop: '1px solid var(--border)' }}>
              <input
                className="input"
                placeholder="Type a message…"
                value={text}
                onChange={e => setText(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleSend(); }}
              />
              <button
                onClick={handleSend}
                disabled={!text.trim()}
                className="btn btn-primary btn-sm"
                style={{ flexShrink: 0 }}
              >Send</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
