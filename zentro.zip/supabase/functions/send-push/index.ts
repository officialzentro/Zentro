// supabase/functions/send-push/index.ts
//
// Replaces the default "Hello {name}" starter template that was
// deployed here — that template never sent any push notifications.
//
// This function is invoked from the app like:
//   supabase.functions.invoke('send-push', { body: { booking_id } })                                  // new booking -> notifies barber
//   supabase.functions.invoke('send-push', { body: { booking_id, event: 'status_changed', status } })  // barber confirmed/cancelled -> notifies customer
//   supabase.functions.invoke('send-push', { body: { booking_id, event: 'cancelled_by_customer' } })   // customer cancelled -> notifies barber
//
// Deploy with:
//   supabase functions deploy send-push
//
// Required secrets (set once, then redeploy is not needed for secret changes):
//   supabase secrets set VAPID_PUBLIC_KEY=BImYp-8ReYtmKDWkZBLgWCpnr3fRX-Hw7AzD19Lo0rm86czjj52y9kCpAHp9A1rvTHjWfk66hfgdWlwBnzKJSkI
//   supabase secrets set VAPID_PRIVATE_KEY=zDdsmnnUCpT3wa3TgGpBuWi0MIjU5UxLdgwpV6oSTHs
//   supabase secrets set VAPID_SUBJECT=mailto:officialzentro.pk@gmail.com
//
// SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are injected automatically
// by the Supabase platform for every Edge Function — you don't set those.

import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

const SUPABASE_URL  = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const VAPID_PUBLIC   = Deno.env.get("VAPID_PUBLIC_KEY")  || "BImYp-8ReYtmKDWkZBLgWCpnr3fRX-Hw7AzD19Lo0rm86czjj52y9kCpAHp9A1rvTHjWfk66hfgdWlwBnzKJSkI";
const VAPID_PRIVATE  = Deno.env.get("VAPID_PRIVATE_KEY") || "zDdsmnnUCpT3wa3TgGpBuWi0MIjU5UxLdgwpV6oSTHs";
const VAPID_SUBJECT  = Deno.env.get("VAPID_SUBJECT")     || "mailto:officialzentro.pk@gmail.com";

webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);

const supabase = createClient(SUPABASE_URL, SERVICE_ROLE);

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

function json(obj: unknown, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

  try {
    const payload = await req.json();
    const { booking_id, event = "created", status, user_id, user_ids, title: directTitle, body: directBody, url: directUrl } = payload;

    // Build a list of { id, title, body, url } targets, regardless of which
    // calling style was used (booking-based vs direct user-targeted/bulk).
    let targets: { id: string; title: string; body: string; url: string }[] = [];

    if (booking_id) {
      const { data: booking, error } = await supabase
        .from("bookings")
        .select(
          "id, status, customer_id, shops(name, owner_id), profiles(full_name), services(name), time_slots(slot_date, start_time)"
        )
        .eq("id", booking_id)
        .single();

      if (error || !booking) return json({ error: "booking not found" }, 404);

      const shopName     = booking.shops?.name || "Zentro";
      const ownerId      = booking.shops?.owner_id;
      const customerId   = booking.customer_id;
      const customerName = booking.profiles?.full_name || "A customer";
      const serviceName  = booking.services?.name || "a service";
      const date         = booking.time_slots?.slot_date || "";
      const time         = booking.time_slots?.start_time || "";

      let recipientId: string | null;
      let title: string;
      let body: string;

      if (event === "status_changed") {
        recipientId = customerId;
        const st = status || booking.status;
        title = `Booking ${st}`;
        body  = `Your ${serviceName} booking at ${shopName} on ${date} ${time} was ${st}.`;
      } else if (event === "cancelled_by_customer") {
        recipientId = ownerId;
        title = "Booking Cancelled";
        body  = `${customerName} cancelled their ${serviceName} booking on ${date} ${time}.`;
      } else {
        recipientId = ownerId;
        title = "New Booking!";
        body  = `${customerName} booked ${serviceName} on ${date} at ${time}.`;
      }

      if (!recipientId) return json({ skipped: true, reason: "no recipient" });
      targets = [{ id: recipientId, title, body, url: "/account" }];
    } else if (user_id || (user_ids && user_ids.length)) {
      const ids = user_ids && user_ids.length ? user_ids : [user_id];
      const title = directTitle || "Zentro";
      const body  = directBody || "";
      const url   = directUrl || "/account";
      targets = ids.map((id: string) => ({ id, title, body, url }));
    } else {
      return json({ error: "booking_id or user_id/user_ids required" }, 400);
    }

    let totalSent = 0;
    let totalSubs = 0;

    for (const target of targets) {
      const { data: subs } = await supabase
        .from("push_subscriptions")
        .select("id, endpoint, p256dh, auth")
        .eq("user_id", target.id);

      if (!subs || subs.length === 0) continue;
      totalSubs += subs.length;

      const wpPayload = JSON.stringify({ title: target.title, body: target.body, url: target.url });

      for (const sub of subs) {
        try {
          await webpush.sendNotification(
            { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
            wpPayload
          );
          totalSent++;
        } catch (err) {
          const statusCode = err?.statusCode;
          if (statusCode === 404 || statusCode === 410) {
            // Subscription is gone (uninstalled / expired) — clean it up.
            await supabase.from("push_subscriptions").delete().eq("id", sub.id);
          } else {
            console.error("push send failed:", err?.message || err);
          }
        }
      }
    }

    return json({ sent: totalSent, total: totalSubs, recipients: targets.length });
  } catch (err) {
    console.error(err);
    return json({ error: err?.message || "unknown error" }, 500);
  }
});
