import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import {
  fetchWalletBalance,
  fetchWalletHistory,
  fetchConversionRate,
  fetchMinSendAmount,
  lookupRecipientByEmail,
  sendCreditsToFriend,
} from '../lib/wallet';

// ── Icons ─────────────────────────────────────────────────────────────────────
const WalletIcon = () => (
  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>
  </svg>
);
const SendIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
  </svg>
);
const ArrowUpIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>
  </svg>
);
const ArrowDownIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>
  </svg>
);
const ScissorsIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>
  </svg>
);
const GiftIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/>
    <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
  </svg>
);
const QRIcon = ({ size = 18 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/>
    <rect x="3" y="14" width="7" height="7" rx="1"/><line x1="14" y1="14" x2="14" y2="14.01"/>
    <line x1="14" y1="18" x2="14" y2="18.01"/><line x1="18" y1="14" x2="18" y2="14.01"/>
    <line x1="18" y1="18" x2="18" y2="18.01"/><line x1="21" y1="14" x2="21" y2="21"/><line x1="14" y1="21" x2="21" y2="21"/>
  </svg>
);
const UsersIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
);
const BackIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="15 18 9 12 15 6"/>
  </svg>
);
const AvatarPlaceholder = ({ size = 56 }) => (
  <div style={{
    width: size, height: size, borderRadius: '50%', background: 'var(--brand-dim)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
  }}>
    <svg width={size * 0.5} height={size * 0.5} viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
    </svg>
  </div>
);

// ── Bottom sheet shell ─────────────────────────────────────────────────────────
function Sheet({ children, onClose, maxWidth = 480 }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.72)', zIndex: 999,
      display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
      backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
    }} onClick={e => e.target === e.currentTarget && onClose()}>
      <div style={{
        background: 'var(--bg, #F0F6FF)',
        borderRadius: '20px 20px 0 0',
        padding: '8px 0 0',
        width: '100%', maxWidth,
        maxHeight: '88vh', overflowY: 'auto',
        boxShadow: '0 -8px 40px rgba(0,0,0,0.32)',
        border: '1px solid rgba(0,0,0,0.06)',
      }}>
        {/* drag handle */}
        <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--border)', margin: '0 auto 20px' }} />
        <div style={{ padding: '0 20px 40px' }}>
          {children}
        </div>
      </div>
    </div>
  );
}

function SheetHeader({ title, onClose, onBack }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 22 }}>
      {onBack && (
        <button onClick={onBack} style={{ background: 'none', border: 'none', color: 'var(--text-1)', cursor: 'pointer', padding: 0, display: 'flex' }}>
          <BackIcon />
        </button>
      )}
      <span style={{ fontWeight: 800, fontSize: 17, flex: 1, color: 'var(--text-1)' }}>{title}</span>
      <button onClick={onClose} style={{
        background: 'var(--bg-input)', border: '1px solid var(--border)', width: 28, height: 28,
        borderRadius: '50%', fontSize: 16, color: 'var(--text-2)', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', lineHeight: 1,
      }}>×</button>
    </div>
  );
}

// ── Step 1: choose who to send to ─────────────────────────────────────────────
function ChooseRecipientType({ onClose, onPick }) {
  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="Send Credits" onClose={onClose} />
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 18 }}>Who are you sending to?</p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <button
          onClick={() => onPick('barber')}
          className="card"
          style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '16px', cursor: 'pointer', textAlign: 'left', border: '1.5px solid var(--border)', background: 'var(--surface)' }}
        >
          <div style={{ width: 44, height: 44, borderRadius: 12, background: 'rgba(245,158,11,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#F59E0B', flexShrink: 0 }}>
            <ScissorsIcon />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 14.5 }}>A Barber</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>Scan their shop QR code to pay</div>
          </div>
          <div style={{ color: 'var(--text-3)' }}><QRIcon /></div>
        </button>

        <button
          onClick={() => onPick('friend')}
          className="card"
          style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '16px', cursor: 'pointer', textAlign: 'left', border: '1.5px solid var(--border)', background: 'var(--surface)' }}
        >
          <div style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--brand-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)', flexShrink: 0 }}>
            <UsersIcon />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 14.5 }}>A Friend</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>Enter their email address</div>
          </div>
        </button>
      </div>
    </Sheet>
  );
}

// ── Barber flow: hands off to the existing Home-tab QR scanner ───────────────
function PayBarberFlow({ balance, minAmount, onClose, onBack }) {
  const navigate = useNavigate();

  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="Pay Barber" onClose={onClose} onBack={onBack} />

      <div style={{ textAlign: 'center', padding: '8px 4px 4px' }}>
        <div style={{
          width: 64, height: 64, borderRadius: 18, margin: '0 auto 18px',
          background: 'rgba(245,158,11,0.12)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#F59E0B',
        }}>
          <QRIcon size={30} />
        </div>

        <p style={{ fontSize: 14.5, fontWeight: 700, marginBottom: 8 }}>Scan the barber's QR to pay</p>
        <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.6, marginBottom: 24 }}>
          Use the QR scanner on the <b>Home</b> tab — it already opens the shop and shows their balance, payment box, and amount field right there.
        </p>

        <button
          className="btn btn-primary"
          style={{ width: '100%', marginBottom: 10 }}
          onClick={() => { onClose(); navigate('/'); }}
        >
          Go to Home → Scan QR
        </button>
        <button className="btn btn-ghost" style={{ width: '100%' }} onClick={onBack}>
          ← Back
        </button>

        <div style={{
          marginTop: 22, padding: '12px 14px', borderRadius: 12,
          background: 'var(--bg-input)', textAlign: 'left',
        }}>
          <p style={{ fontSize: 11.5, color: 'var(--text-3)', lineHeight: 1.5 }}>
            Your wallet balance is <b style={{ color: 'var(--brand)' }}>Rs {balance.toLocaleString()}</b>. Minimum payment amount is <b>Rs {minAmount}</b>.
          </p>
        </div>
      </div>
    </Sheet>
  );
}

// ── Friend flow: enter email → confirm identity → enter amount → send ────────
function SendFriendFlow({ userId, balance, minAmount, onClose, onBack, onSuccess, showToast }) {
  const [step, setStep]       = useState('email'); // 'email' | 'confirm'
  const [email, setEmail]     = useState('');
  const [amount, setAmount]   = useState('');
  const [recipient, setRecipient] = useState(null);
  const [looking, setLooking] = useState(false);
  const [sending, setSending] = useState(false);
  const [emailError, setEmailError] = useState('');

  const handleLookup = async () => {
    setEmailError('');
    if (!email.trim()) return setEmailError('Enter an email address');
    setLooking(true);
    const res = await lookupRecipientByEmail(userId, email);
    setLooking(false);
    if (!res.found) {
      setEmailError(res.error);
      return;
    }
    setRecipient(res);
    setStep('confirm');
  };

  const handleSend = async () => {
    const amt = Number(amount);
    if (!amt || amt < minAmount) return showToast('error', `Minimum send amount is Rs ${minAmount}`);
    if (amt > balance) return showToast('error', 'Insufficient balance');
    setSending(true);
    const res = await sendCreditsToFriend(userId, email, amt);
    setSending(false);
    if (res.success) {
      showToast('success', `Rs ${amt} sent to ${res.recipientName}!`);
      onSuccess(amt);
    } else {
      showToast('error', res.error);
    }
  };

  if (step === 'email') {
    return (
      <Sheet onClose={onClose}>
        <SheetHeader title="Send to Friend" onClose={onClose} onBack={onBack} />
        <div style={{ marginBottom: 14 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-2)', marginBottom: 6, textTransform: 'uppercase', letterSpacing: 0.5 }}>Recipient Email</div>
          <input
            className="input"
            type="email"
            placeholder="e.g. friend@email.com"
            value={email}
            onChange={e => { setEmail(e.target.value); setEmailError(''); }}
            onKeyDown={e => e.key === 'Enter' && handleLookup()}
            autoFocus
          />
          {emailError && <p style={{ color: 'var(--error)', fontSize: 12.5, marginTop: 8 }}>{emailError}</p>}
        </div>
        <button className="btn btn-primary" onClick={handleLookup} disabled={looking} style={{ width: '100%' }}>
          {looking ? <span className="spinner spinner-sm" /> : 'Continue →'}
        </button>
      </Sheet>
    );
  }

  // step === 'confirm'
  return (
    <Sheet onClose={onClose}>
      <SheetHeader title="Send to Friend" onClose={onClose} onBack={() => { setStep('email'); setRecipient(null); }} />

      {/* Recipient info card */}
      <div style={{
        display: 'flex', alignItems: 'center', gap: 14, padding: '14px',
        borderRadius: 14, background: 'var(--bg-input)', marginBottom: 18,
      }}>
        <AvatarPlaceholder />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 800, fontSize: 15 }}>{recipient.full_name || 'Zentro User'}</div>
          <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>{email}</div>
        </div>
      </div>

      <div style={{
        background: 'rgba(99,102,241,0.08)', border: '1.5px solid rgba(99,102,241,0.2)',
        borderRadius: 12, padding: '12px 16px', marginBottom: 18,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <div style={{ fontSize: 13, color: 'var(--text-2)', fontWeight: 600 }}>Your Balance</div>
        <div style={{ fontWeight: 800, fontSize: 17, color: 'var(--brand)' }}>Rs {balance.toLocaleString()}</div>
      </div>

      <div style={{ marginBottom: 22 }}>
        <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', marginBottom: 6 }}>Amount (Rs)</label>
        <div style={{ display: 'flex', gap: 8 }}>
          <input className="input" type="number" placeholder={`Min Rs ${minAmount}`}
            value={amount} onChange={e => setAmount(e.target.value)} autoFocus
            style={{ flex: 1, fontSize: 20, fontWeight: 800, marginBottom: 0 }} />
          <button onClick={() => setAmount(String(balance))}
            style={{ padding: '0 14px', borderRadius: 10, border: '1.5px solid var(--brand)', background: 'transparent', color: 'var(--brand)', fontWeight: 700, fontSize: 12.5, cursor: 'pointer', whiteSpace: 'nowrap' }}>
            Max
          </button>
        </div>
      </div>

      <button className="btn btn-primary" onClick={handleSend} disabled={sending || !amount || Number(amount) < minAmount} style={{ width: '100%' }}>
        {sending ? <span className="spinner spinner-sm" /> : <><SendIcon />&nbsp; Send Rs {Number(amount).toLocaleString() || '—'}</>}
      </button>
    </Sheet>
  );
}

// ── Transaction Row ───────────────────────────────────────────────────────────
function TxRow({ tx, userId }) {
  const isOut = tx.from_user_id === userId;
  const isBarberPay = tx.type === 'barber_payment';
  const isTransfer = tx.type === 'transfer';
  const isReferral = tx.type === 'referral' || tx.source === 'referral';
  const isAdminGrant = tx.source === 'admin';

  let icon, label, color;
  if (isBarberPay && isOut) {
    icon = <ScissorsIcon />; label = 'Paid to barber'; color = '#EF4444';
  } else if (isTransfer && isOut) {
    icon = <ArrowUpIcon />; label = 'Sent to friend'; color = '#EF4444';
  } else if (isTransfer && !isOut) {
    icon = <ArrowDownIcon />; label = 'Received from friend'; color = '#22C55E';
  } else if (isReferral) {
    icon = <GiftIcon />; label = 'Referral reward'; color = '#22C55E';
  } else if (isAdminGrant) {
    icon = <GiftIcon />; label = 'Admin grant'; color = '#22C55E';
  } else {
    icon = isOut ? <ArrowUpIcon /> : <ArrowDownIcon />;
    label = isOut ? 'Deducted' : 'Received';
    color = isOut ? '#EF4444' : '#22C55E';
  }

  const prefix = isOut ? '−' : '+';

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14,
      padding: '13px 0', borderBottom: '1px solid var(--border)',
    }}>
      <div style={{
        width: 36, height: 36, borderRadius: '50%',
        background: isOut ? 'rgba(239,68,68,0.12)' : 'rgba(34,197,94,0.12)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color, flexShrink: 0,
      }}>
        {icon}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 13.5 }}>{label}</div>
        {tx.note && <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 1 }}>{tx.note}</div>}
        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>
          {new Date(tx.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}
        </div>
      </div>
      <div style={{ fontWeight: 800, fontSize: 14, color, flexShrink: 0 }}>
        {prefix}Rs {Number(tx.amount).toLocaleString()}
      </div>
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function CustomerWallet() {
  const { user }                = useAuth();
  const navigate                = useNavigate();
  const { showToast, ToastEl }  = useToast();

  const [balance, setBalance]   = useState(0);
  const [history, setHistory]   = useState([]);
  const [rate, setRate]         = useState(100);
  const [minAmount, setMinAmount] = useState(10);
  const [loading, setLoading]   = useState(true);

  // 'closed' | 'choose' | 'barber' | 'friend'
  const [sendFlow, setSendFlow] = useState('closed');

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const [bal, hist, r, min] = await Promise.all([
      fetchWalletBalance(user.id),
      fetchWalletHistory(user.id),
      fetchConversionRate(),
      fetchMinSendAmount(),
    ]);
    setBalance(bal);
    setHistory(hist);
    setRate(r);
    setMinAmount(min);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    load();
  }, [user, load, navigate]);

  const closeSendFlow = () => setSendFlow('closed');

  const handleSendSuccess = (amt) => {
    setBalance(b => b - amt);
    setSendFlow('closed');
    load();
  };

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)', paddingBottom: 80 }}>
      {ToastEl}

      {/* Header */}
      <div style={{
        background: 'var(--surface)', borderBottom: '1px solid var(--border)',
        padding: '16px 20px 0', position: 'sticky', top: 0, zIndex: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <button onClick={() => navigate(-1)} style={{ background: 'none', border: 'none', color: 'var(--text-1)', cursor: 'pointer', padding: 0, display: 'flex' }}>
            <BackIcon />
          </button>
          <span style={{ fontWeight: 800, fontSize: 17 }}>My Wallet</span>
        </div>
      </div>

      <div style={{ padding: '20px 16px', maxWidth: 480, margin: '0 auto' }}>

        {/* Balance Card */}
        <div style={{
          background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)',
          borderRadius: 20, padding: '28px 24px', marginBottom: 20,
          boxShadow: '0 8px 32px rgba(99,102,241,0.25)',
          position: 'relative', overflow: 'hidden',
        }}>
          {/* Background glow */}
          <div style={{
            position: 'absolute', top: -30, right: -30, width: 120, height: 120,
            borderRadius: '50%', background: 'rgba(99,102,241,0.2)', filter: 'blur(30px)',
          }} />

          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, opacity: 0.75 }}>
            <WalletIcon />
            <span style={{ fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 1, color: '#fff' }}>Zentro Credits</span>
          </div>

          {loading ? (
            <div className="skeleton" style={{ height: 48, width: 160, borderRadius: 8, marginBottom: 8 }} />
          ) : (
            <div style={{ fontSize: 44, fontWeight: 900, color: '#fff', letterSpacing: -1, marginBottom: 4 }}>
              Rs {balance.toLocaleString()}
            </div>
          )}

          <div style={{ fontSize: 12.5, color: 'rgba(255,255,255,0.6)' }}>
            Rs {rate} = 1 barber subscription day
          </div>
        </div>

        {/* Send Action */}
        <button
          className="card"
          onClick={() => setSendFlow('choose')}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 14,
            padding: '16px', textAlign: 'left', cursor: 'pointer',
            border: '1.5px solid var(--border)', background: 'var(--surface)', marginBottom: 24,
          }}
        >
          <div style={{ width: 44, height: 44, borderRadius: 12, background: 'var(--brand-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)', flexShrink: 0 }}>
            <SendIcon />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontWeight: 700, fontSize: 14.5 }}>Send Credits</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>To a barber (scan QR) or a friend</div>
          </div>
        </button>

        {/* How it works */}
        <div className="card" style={{ padding: '16px', marginBottom: 20, background: 'rgba(99,102,241,0.06)', border: '1px solid rgba(99,102,241,0.15)' }}>
          <div style={{ fontWeight: 700, fontSize: 13, marginBottom: 10, color: 'var(--brand)' }}>How Credits Work</div>
          {[
            {
              icon: (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/>
                  <line x1="12" y1="22" x2="12" y2="7"/>
                  <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/>
                  <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
                </svg>
              ),
              text: 'Earn credits from referrals and admin rewards',
            },
            {
              icon: (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
                  <line x1="20" y1="4" x2="8.12" y2="15.88"/>
                  <line x1="14.47" y1="14.48" x2="20" y2="20"/>
                  <line x1="8.12" y1="8.12" x2="12" y2="12"/>
                </svg>
              ),
              text: `Scan a barber's QR code to pay them — they earn subscription days (Rs ${rate} = 1 day)`,
            },
            {
              icon: (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                  <circle cx="9" cy="7" r="4"/>
                  <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                  <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
              ),
              text: `Send credits to a friend by email address (min Rs ${minAmount})`,
            },
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, marginBottom: i < 2 ? 8 : 0 }}>
              <span style={{ color: 'var(--brand)', flexShrink: 0, marginTop: 1 }}>{item.icon}</span>
              <span style={{ fontSize: 12.5, color: 'var(--text-2)', lineHeight: 1.4 }}>{item.text}</span>
            </div>
          ))}
        </div>

        {/* Transaction History */}
        <div style={{ fontWeight: 800, fontSize: 14, marginBottom: 12, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-2)' }}>
          Transactions
        </div>

        {loading ? (
          [1, 2, 3].map(i => (
            <div key={i} className="skeleton" style={{ height: 60, borderRadius: 12, marginBottom: 10 }} />
          ))
        ) : history.length === 0 ? (
          <div className="card" style={{ padding: '32px 20px', textAlign: 'center' }}>
            <div style={{ width: 48, height: 48, borderRadius: 14, background: 'var(--brand-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)', margin: '0 auto 8px' }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
                <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>
              </svg>
            </div>
            <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 4 }}>No transactions yet</div>
            <div style={{ fontSize: 12.5, color: 'var(--text-3)' }}>Your credit history will appear here</div>
          </div>
        ) : (
          <div className="card" style={{ padding: '0 16px' }}>
            {history.map((tx, i) => (
              <TxRow key={tx.id || i} tx={tx} userId={user?.id} />
            ))}
          </div>
        )}
      </div>

      {/* ── Send Flow ── */}
      {sendFlow === 'choose' && (
        <ChooseRecipientType
          onClose={closeSendFlow}
          onPick={(type) => setSendFlow(type)}
        />
      )}

      {sendFlow === 'barber' && (
        <PayBarberFlow
          balance={balance}
          minAmount={minAmount}
          onClose={closeSendFlow}
          onBack={() => setSendFlow('choose')}
        />
      )}

      {sendFlow === 'friend' && (
        <SendFriendFlow
          userId={user?.id}
          balance={balance}
          minAmount={minAmount}
          onClose={closeSendFlow}
          onBack={() => setSendFlow('choose')}
          onSuccess={handleSendSuccess}
          showToast={showToast}
        />
      )}
    </div>
  );
}
