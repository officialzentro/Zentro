import { useEffect, useState, useCallback } from 'react';
import { useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { format, addDays } from 'date-fns';
import { Scissors, MapPin, Clock, StarFilled, Search } from '../lib/icons';
import { fetchWalletBalance, fetchConversionRate, fetchMinSendAmount, payBarberWithCredits } from '../lib/wallet';
import { sendNotification } from '../lib/referrals';

const PLAN_DEFAULTS = {
  basic:   { badge: false, priority: false },
  pro:     { badge: false, priority: true  },
  premium: { badge: true,  priority: true  },
};

function StarRating({ value, onChange, size = 28 }) {
  const [hovered, setHovered] = useState(0);
  return (
    <div style={{ display: 'flex', gap: 4 }}>
      {[1, 2, 3, 4, 5].map(n => (
        <span
          key={n}
          onClick={() => onChange && onChange(n)}
          onMouseEnter={() => onChange && setHovered(n)}
          onMouseLeave={() => onChange && setHovered(0)}
          style={{
            cursor: onChange ? 'pointer' : 'default',
            display: 'inline-flex',
            lineHeight: 1,
            userSelect: 'none',
          }}
        >
          <svg width={size} height={size} viewBox="0 0 24 24"
            fill={n <= (hovered || value) ? '#FF9500' : 'none'}
            stroke={n <= (hovered || value) ? '#FF9500' : 'var(--border-strong)'}
            strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"
            style={{ transition: 'fill 0.15s, stroke 0.15s' }}>
            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
          </svg>
        </span>
      ))}
    </div>
  );
}

export default function ShopDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const { showToast, ToastEl } = useToast();

  const [shop, setShop]           = useState(null);
  const [services, setServices]   = useState([]);
  const [reviews, setReviews]     = useState([]);
  const [slots, setSlots]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [plansConfig, setPlansConfig] = useState(PLAN_DEFAULTS);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [selectedSrv, setSelectedSrv]   = useState(null);
  const [booking, setBooking]     = useState(false);
  const [imgIdx, setImgIdx]       = useState(0);

  // Review state
  const [userReview, setUserReview]       = useState(null);   // existing review by this user
  const [completedBooking, setCompletedBooking] = useState(null); // a completed booking (eligibility)
  const [showReviewForm, setShowReviewForm]   = useState(false);
  const [reviewRating, setReviewRating]       = useState(5);
  const [reviewComment, setReviewComment]     = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  // Credit payment state
  const [walletBalance, setWalletBalance]   = useState(0);
  const [conversionRate, setConversionRate] = useState(100);
  const [minSendAmount, setMinSendAmount]   = useState(10);
  const [bookingLocation, setBookingLocation] = useState('salon'); // 'salon' | 'home'
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerCoords, setCustomerCoords]   = useState(null); // { lat, lng }
  const [locatingGPS, setLocatingGPS]         = useState(false);
  const [showPayModal, setShowPayModal]       = useState(false);  // QR scan-to-pay modal
  const [payAmount, setPayAmount]             = useState('');
  const [paying, setPaying]                   = useState(false);

  useEffect(() => {
    fetchShop();
    if (user) { fetchWalletBalance(user.id).then(setWalletBalance); fetchConversionRate().then(setConversionRate); }
    fetchMinSendAmount().then(setMinSendAmount);
    if (searchParams.get('pay') === '1') { setShowPayModal(true); }
    supabase.from('app_settings').select('value').eq('key', 'plans_config').maybeSingle().then(({ data }) => {
      if (data?.value) {
        try {
          const parsed = JSON.parse(data.value);
          setPlansConfig(t => {
            const merged = {};
            for (const k of ['basic', 'pro', 'premium']) merged[k] = { ...PLAN_DEFAULTS[k], ...(parsed[k] || {}) };
            return merged;
          });
        } catch {}
      }
    });
  }, [id]);

  useEffect(() => { fetchSlots(); }, [id, selectedDate]);

  useEffect(() => {
    if (user) checkUserReviewEligibility();
  }, [user, id]);

  const fetchShop = async () => {
    const [{ data: s }, { data: srv }, { data: rev }] = await Promise.all([
      supabase.from('shops').select('*').eq('id', id).maybeSingle(),
      supabase.from('services').select('*').eq('shop_id', id).eq('is_active', true),
      supabase.from('reviews').select('*, profiles(full_name)').eq('shop_id', id).order('created_at', { ascending: false }).limit(20),
    ]);
    setShop(s);
    setServices(srv || []);
    setReviews(rev || []);
    setLoading(false);
  };

  const fetchSlots = async () => {
    const { data } = await supabase
      .from('time_slots')
      .select('*')
      .eq('shop_id', id)
      .eq('slot_date', selectedDate)
      .eq('is_booked', false)
      .order('start_time');

    let result = data || [];
    const todayStr = format(new Date(), 'yyyy-MM-dd');
    if (selectedDate === todayStr) {
      const nowHHMM = format(new Date(), 'HH:mm:ss');
      result = result.filter(s => s.start_time > nowHHMM);
    }
    setSlots(result);
  };

  const checkUserReviewEligibility = async () => {
    // Check if user has already left a review
    const { data: existing } = await supabase
      .from('reviews')
      .select('*')
      .eq('shop_id', id)
      .eq('customer_id', user.id)
      .maybeSingle();
    setUserReview(existing || null);

    // Check if user has a completed booking at this shop
    const { data: completed } = await supabase
      .from('bookings')
      .select('id')
      .eq('shop_id', id)
      .eq('customer_id', user.id)
      .eq('status', 'completed')
      .limit(1)
      .maybeSingle();
    setCompletedBooking(completed || null);
  };

  const getGPSLocation = () => {
    if (!navigator.geolocation) {
      showToast('error', 'GPS not supported on this device');
      return;
    }
    setLocatingGPS(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCustomerCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLocatingGPS(false);
        showToast('success', 'Location captured');
      },
      (err) => {
        setLocatingGPS(false);
        showToast('error', 'Could not get GPS location — please type your address');
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const bookSlot = async () => {
    if (!user) return navigate('/login');
    if (!selectedSlot || !selectedSrv) return showToast('error', 'Select a service and time slot');
    if (bookingLocation === 'home' && !customerCoords && !customerAddress.trim()) {
      return showToast('error', 'Share your location or type your address for home service');
    }
    setBooking(true);

    // Calc total with home fee if applicable
    const homeFeeAmt = (bookingLocation === 'home' && shop?.home_fee) ? Number(shop.home_fee) : 0;

    const { data: newBooking, error } = await supabase.from('bookings').insert({
      shop_id: id,
      customer_id: user.id,
      time_slot_id: selectedSlot.id,
      service_id: selectedSrv.id,
      status: 'pending',
      booking_location: bookingLocation,
      home_fee_applied: homeFeeAmt || null,
      customer_lat: bookingLocation === 'home' ? (customerCoords?.lat || null) : null,
      customer_lng: bookingLocation === 'home' ? (customerCoords?.lng || null) : null,
      customer_address: bookingLocation === 'home' ? (customerAddress.trim() || null) : null,
    }).select('id').single();

    if (!error) {
      await supabase.from('time_slots').update({ is_booked: true }).eq('id', selectedSlot.id);

      showToast('success', 'Booking confirmed!');

      const bookedSlotTime = selectedSlot?.start_time?.slice(0, 5) || '';
      setSelectedSlot(null);
      fetchSlots();
      // In-app inbox notification (non-blocking)
      if (newBooking?.id && shop?.owner_id) {
        sendNotification(shop.owner_id, {
          title: 'New Booking!',
          body: `New ${selectedSrv?.name || 'service'} booking for ${bookedSlotTime}.`,
          type: 'booking_created',
          meta: { url: '/account' },
        }).catch(err => showToast('error', 'Notif failed: ' + err.message));
      }
    } else {
      console.error('[DB] booking error:', error);
      showToast('error', 'Booking failed: ' + error.message);
    }
    setBooking(false);
  };

  const submitReview = async () => {
    if (!user) return navigate('/login');
    if (reviewRating < 1) return showToast('error', 'Please select a rating');
    setSubmittingReview(true);

    if (userReview) {
      // Update existing review
      const { error } = await supabase
        .from('reviews')
        .update({ rating: reviewRating, comment: reviewComment.trim() || null })
        .eq('id', userReview.id);
      if (!error) {
        showToast('success', 'Review updated!');
        setUserReview({ ...userReview, rating: reviewRating, comment: reviewComment.trim() });
        setShowReviewForm(false);
        fetchShop();
      } else {
        showToast('error', 'Failed to update review');
      }
    } else {
      // Insert new review
      const { error } = await supabase.from('reviews').insert({
        shop_id: id,
        customer_id: user.id,
        rating: reviewRating,
        comment: reviewComment.trim() || null,
      });
      if (!error) {
        showToast('success', 'Review submitted! Thank you.');
        setShowReviewForm(false);
        checkUserReviewEligibility();
        fetchShop();
        if (shop?.owner_id) {
          sendNotification(shop.owner_id, {
            title: 'New Review!',
            body: `You received a new ${reviewRating}-star review${reviewComment.trim() ? ': "' + reviewComment.trim().slice(0, 80) + '"' : '.'}`,
            type: 'review',
          }).catch(() => {});
        }
      } else if (error.code === '23505') {
        showToast('error', 'You already reviewed this shop');
      } else {
        showToast('error', 'Failed to submit review');
      }
    }
    setSubmittingReview(false);
  };

  const avgRating = reviews.length > 0
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length)
    : null;

  // Generate next 7 days
  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { value: format(d, 'yyyy-MM-dd'), label: format(d, 'EEE'), day: format(d, 'd') };
  });

  if (loading) return (
    <div className="loading-screen">
      <div className="spinner" />
    </div>
  );

  if (!shop) return (
    <div className="empty-state" style={{ minHeight: '100dvh' }}>
      <div className="empty-icon"><Search size={36} color="var(--text-3)" /></div>
      <div className="empty-title">Shop not found</div>
      <button className="btn btn-secondary btn-sm" onClick={() => navigate('/')}>Go Home</button>
    </div>
  );

  const imgs = shop.images || [];
  const canReview = user && completedBooking;

  // ── QR pay handler ─────────────────────────────────────────────────────────
  const handleQRPay = async () => {
    const amt = Number(payAmount);
    if (!amt || amt < minSendAmount) return showToast('error', `Minimum amount is Rs ${minSendAmount}`);
    if (amt > walletBalance) return showToast('error', `Insufficient balance (Rs ${walletBalance})`);
    if (!shop?.owner_id) return showToast('error', 'Shop data not loaded yet');
    setPaying(true);
    const res = await payBarberWithCredits({
      customerId: user.id,
      barberId: shop.owner_id,
      creditsToUse: amt,
      bookingId: null,
    });
    setPaying(false);
    if (res.success) {
      setWalletBalance(b => b - amt);
      setPayAmount('');
      setShowPayModal(false);
      const msg = res.daysAwarded > 0
        ? `Rs ${amt} paid! Barber earned ${res.daysAwarded} subscription day${res.daysAwarded !== 1 ? 's' : ''}.`
        : `Rs ${amt} paid from your wallet!`;
      showToast('success', msg);
    } else {
      showToast('error', res.error);
    }
  };

  return (
    <div className="page">
      {ToastEl}

      {/* ── Pay with Credits Modal ────────────────────────────────────────── */}
      {showPayModal && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.72)', zIndex: 999,
          display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
          backdropFilter: 'blur(4px)', WebkitBackdropFilter: 'blur(4px)',
        }} onClick={e => e.target === e.currentTarget && setShowPayModal(false)}>
          <div style={{
            background: 'var(--bg, #F0F6FF)',
            borderRadius: '20px 20px 0 0',
            padding: '8px 0 0',
            width: '100%', maxWidth: 480,
            maxHeight: '88vh', overflowY: 'auto',
            boxShadow: '0 -8px 40px rgba(0,0,0,0.32)',
            border: '1px solid rgba(0,0,0,0.06)',
          }}>
            {/* Drag handle */}
            <div style={{ width: 36, height: 4, borderRadius: 2, background: 'var(--border)', margin: '0 auto 20px' }} />

            <div style={{ padding: '0 20px 44px' }}>
              {/* Header */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 22 }}>
                <span style={{ fontWeight: 800, fontSize: 17, flex: 1, color: 'var(--text-1)' }}>Pay with Credits</span>
                <button onClick={() => setShowPayModal(false)} style={{
                  background: 'var(--bg-input)', border: '1px solid var(--border)', width: 28, height: 28,
                  borderRadius: '50%', fontSize: 16, color: 'var(--text-2)', cursor: 'pointer',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', lineHeight: 1,
                }}>×</button>
              </div>

              {/* Shop info card */}
              <div style={{
                display: 'flex', alignItems: 'center', gap: 14, padding: '14px',
                borderRadius: 14, background: 'var(--bg-input)', marginBottom: 18,
              }}>
                <div style={{
                  width: 44, height: 44, borderRadius: 12,
                  background: 'rgba(245,158,11,0.12)', display: 'flex',
                  alignItems: 'center', justifyContent: 'center', color: '#F59E0B', flexShrink: 0,
                }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
                    <line x1="20" y1="4" x2="8.12" y2="15.88"/>
                    <line x1="14.47" y1="14.48" x2="20" y2="20"/>
                    <line x1="8.12" y1="8.12" x2="12" y2="12"/>
                  </svg>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontWeight: 800, fontSize: 15, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{shop?.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>Barber Shop</div>
                </div>
              </div>

              {/* Balance pill */}
              <div style={{
                background: 'rgba(99,102,241,0.08)', border: '1.5px solid rgba(99,102,241,0.2)',
                borderRadius: 12, padding: '12px 16px', marginBottom: 20,
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <div style={{ fontSize: 13, color: 'var(--text-2)', fontWeight: 600 }}>Your Balance</div>
                <div style={{ fontWeight: 800, fontSize: 17, color: 'var(--brand)' }}>Rs {walletBalance.toLocaleString()}</div>
              </div>

              {/* Amount input */}
              <div style={{ marginBottom: 8 }}>
                <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, display: 'block', marginBottom: 6 }}>Amount (Rs)</label>
                <div style={{ display: 'flex', gap: 8 }}>
                  <input className="input" type="number" placeholder={`Min Rs ${minSendAmount}`}
                    value={payAmount} onChange={e => setPayAmount(e.target.value)} autoFocus
                    style={{ flex: 1, fontSize: 20, fontWeight: 800, marginBottom: 0 }} />
                  <button onClick={() => setPayAmount(String(walletBalance))}
                    style={{ padding: '0 14px', borderRadius: 10, border: '1.5px solid var(--brand)', background: 'transparent', color: 'var(--brand)', fontWeight: 700, fontSize: 12.5, cursor: 'pointer', whiteSpace: 'nowrap' }}>
                    Max
                  </button>
                </div>
              </div>

              {/* Subscription days hint */}
              {Number(payAmount) > 0 && (
                <div style={{
                  fontSize: 12.5, color: 'var(--text-3)', marginBottom: 22,
                  padding: '10px 12px', borderRadius: 10, background: 'rgba(245,158,11,0.08)',
                  border: '1px solid rgba(245,158,11,0.2)',
                }}>
                  Barber earns <b style={{ color: '#F59E0B' }}>{Math.floor(Number(payAmount) / conversionRate)} subscription day{Math.floor(Number(payAmount) / conversionRate) !== 1 ? 's' : ''}</b> · Rs {conversionRate} per day
                </div>
              )}

              {/* CTA */}
              {user ? (
                <button className="btn btn-primary" onClick={handleQRPay}
                  disabled={paying || !payAmount || Number(payAmount) < minSendAmount}
                  style={{ width: '100%', fontSize: 16, marginTop: Number(payAmount) > 0 ? 0 : 14 }}>
                  {paying
                    ? <span className="spinner spinner-sm" />
                    : <>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ marginRight: 6 }}>
                          <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                        </svg>
                        Pay Rs {Number(payAmount).toLocaleString() || '—'}
                      </>
                  }
                </button>
              ) : (
                <button className="btn btn-primary" onClick={() => navigate('/login')} style={{ width: '100%' }}>Login to Pay</button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Back */}
      <div style={{ position: 'absolute', top: 16, left: 16, zIndex: 10 }}>
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
      </div>

      {/* Images */}
      <div style={{ position: 'relative', height: 260, background: 'var(--bg-input)', overflow: 'hidden' }}>
        {imgs.length > 0 ? (
          <img src={imgs[imgIdx]} alt={shop.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : (
          <div style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Scissors size={64} color="var(--text-3)" /></div>
        )}
        {imgs.length > 1 && (
          <>
            <button
              onClick={() => setImgIdx(i => (i - 1 + imgs.length) % imgs.length)}
              aria-label="Previous photo"
              style={{
                position: 'absolute', top: '50%', left: 10, transform: 'translateY(-50%)',
                width: 34, height: 34, borderRadius: '50%', border: 'none', cursor: 'pointer',
                background: 'rgba(0,0,0,0.4)', color: '#fff', display: 'flex',
                alignItems: 'center', justifyContent: 'center', zIndex: 5,
              }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="15 18 9 12 15 6"/>
              </svg>
            </button>
            <button
              onClick={() => setImgIdx(i => (i + 1) % imgs.length)}
              aria-label="Next photo"
              style={{
                position: 'absolute', top: '50%', right: 10, transform: 'translateY(-50%)',
                width: 34, height: 34, borderRadius: '50%', border: 'none', cursor: 'pointer',
                background: 'rgba(0,0,0,0.4)', color: '#fff', display: 'flex',
                alignItems: 'center', justifyContent: 'center', zIndex: 5,
              }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          </>
        )}
        {imgs.length > 1 && (
          <div style={{ position: 'absolute', bottom: 12, left: 0, right: 0, display: 'flex', justifyContent: 'center', gap: 6 }}>
            {imgs.map((_, i) => (
              <div key={i} onClick={() => setImgIdx(i)}
                style={{ width: i === imgIdx ? 20 : 6, height: 6, borderRadius: 3,
                  background: i === imgIdx ? 'var(--brand)' : 'rgba(255,255,255,0.4)',
                  transition: 'all 0.2s', cursor: 'pointer' }} />
            ))}
          </div>
        )}
      </div>

      <div style={{ padding: '20px 20px 0' }}>
        {/* Shop Info */}
        <div style={{ marginBottom: 24 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
            <h1 style={{ fontSize: 26 }}>{shop.name}</h1>
            {plansConfig[shop.subscription_tier]?.badge === true && shop.subscription_tier !== 'basic' && (
              <span className="badge badge-brand">{shop.subscription_tier}</span>
            )}
          </div>
          <p style={{ color: 'var(--text-2)', fontSize: 14, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}><MapPin size={14} color="var(--text-3)" /> {shop.address}, {shop.city}</p>

          {/* Gender & Home Service Badges */}
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 10 }}>
            {/* Gender badge */}
            {shop.gender_type && (
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 5,
                padding: '4px 10px', borderRadius: 20, fontSize: 12.5, fontWeight: 700,
                background: shop.gender_type === 'men' ? 'rgba(59,130,246,0.1)' : shop.gender_type === 'women' ? 'rgba(236,72,153,0.1)' : 'rgba(99,102,241,0.1)',
                color: shop.gender_type === 'men' ? '#3B82F6' : shop.gender_type === 'women' ? '#EC4899' : '#6366F1',
                border: `1px solid ${shop.gender_type === 'men' ? 'rgba(59,130,246,0.25)' : shop.gender_type === 'women' ? 'rgba(236,72,153,0.25)' : 'rgba(99,102,241,0.25)'}`,
              }}>
                {shop.gender_type === 'men' && (
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="10" cy="14" r="6"/><line x1="14.5" y1="9.5" x2="20" y2="4"/><polyline points="16 4 20 4 20 8"/>
                  </svg>
                )}
                {shop.gender_type === 'women' && (
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="8" r="6"/><line x1="12" y1="14" x2="12" y2="20"/><line x1="9" y1="17" x2="15" y2="17"/>
                  </svg>
                )}
                {shop.gender_type === 'both' && (
                  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="8" cy="14" r="4"/><circle cx="16" cy="8" r="4"/>
                    <line x1="8" y1="18" x2="8" y2="22"/><line x1="6" y1="20" x2="10" y2="20"/>
                    <line x1="19.2" y1="4.8" x2="22" y2="2"/><polyline points="20 2 22 2 22 4"/>
                  </svg>
                )}
                {shop.gender_type === 'men' ? 'Men' : shop.gender_type === 'women' ? 'Women' : 'Men & Women'}
              </span>
            )}

            {/* Home service badge */}
            {(shop.home_service === 'home_only' || shop.home_service === 'both') && (
              <span style={{
                display: 'inline-flex', alignItems: 'center', gap: 5,
                padding: '4px 10px', borderRadius: 20, fontSize: 12.5, fontWeight: 700,
                background: 'rgba(34,197,94,0.1)', color: '#16A34A',
                border: '1px solid rgba(34,197,94,0.25)',
              }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
                </svg>
                Home visits available{shop.home_fee ? ` +Rs ${Number(shop.home_fee).toLocaleString()}` : ''}
              </span>
            )}
          </div>

          {/* Rating Summary */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
            {avgRating ? (
              <>
                <StarRating value={Math.round(avgRating)} size={18} />
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, color: 'var(--text-1)' }}>
                  {avgRating.toFixed(1)}
                </span>
                <span style={{ fontSize: 13, color: 'var(--text-2)' }}>({reviews.length} review{reviews.length !== 1 ? 's' : ''})</span>
              </>
            ) : (
              <span style={{ fontSize: 13, color: 'var(--text-3)' }}>No reviews yet</span>
            )}
          </div>

          {shop.description && <p style={{ color: 'var(--text-2)', fontSize: 14, lineHeight: 1.6 }}>{shop.description}</p>}
        </div>

        {/* Services */}
        {services.length > 0 && (
          <div style={{ marginBottom: 28 }}>
            <p className="section-label">Services</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {services.map((srv, i) => (
                <div key={srv.id} onClick={() => setSelectedSrv(selectedSrv?.id === srv.id ? null : srv)}
                  className="tap-feedback fade-up"
                  style={{
                    padding: '14px 16px', borderRadius: 'var(--radius)',
                    border: `1.5px solid ${selectedSrv?.id === srv.id ? 'var(--brand)' : 'var(--border)'}`,
                    background: selectedSrv?.id === srv.id ? 'var(--brand-dim)' : 'var(--bg-card)',
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                    cursor: 'pointer', transition: 'all 0.2s',
                    animationDelay: `${Math.min(i * 0.04, 0.3)}s`,
                  }}>
                  <div>
                    <div style={{ fontWeight: 600, fontFamily: 'var(--font-display)', marginBottom: 2 }}>{srv.name}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-2)' }}>{srv.duration_minutes} min</div>
                  </div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--brand)', fontSize: 16 }}>
                    Rs {srv.price}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Date Picker */}
        <div style={{ marginBottom: 20 }}>
          <p className="section-label">Pick a Date</p>
          <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 8 }}>
            {dates.map(d => (
              <button key={d.value} onClick={() => { setSelectedDate(d.value); setSelectedSlot(null); }}
                style={{
                  flexShrink: 0, width: 56, padding: '10px 0',
                  borderRadius: 'var(--radius-sm)', border: `1.5px solid ${selectedDate === d.value ? 'var(--brand)' : 'var(--border)'}`,
                  background: selectedDate === d.value ? 'var(--brand-dim)' : 'var(--bg-input)',
                  color: selectedDate === d.value ? 'var(--brand)' : 'var(--text-2)',
                  fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2
                }}>
                <span style={{ fontSize: 10, textTransform: 'uppercase' }}>{d.label}</span>
                <span style={{ fontSize: 18 }}>{d.day}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Time Slots */}
        <div style={{ marginBottom: 28 }}>
          <p className="section-label">Available Slots</p>
          {slots.length === 0 ? (
            <div className="empty-state" style={{ padding: '30px 0' }}>
              <div className="empty-icon"><Clock size={32} color="var(--text-3)" /></div>
              <div className="empty-sub">No slots available for this date</div>
            </div>
          ) : (
            <div key={selectedDate} style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
              {slots.map((slot, i) => (
                <button key={slot.id} onClick={() => setSelectedSlot(selectedSlot?.id === slot.id ? null : slot)}
                  className={`chip pop-in${selectedSlot?.id === slot.id ? ' active' : ''}`}
                  style={{ animationDelay: `${Math.min(i * 0.025, 0.25)}s` }}>
                  {slot.start_time.slice(0, 5)}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Home / Salon Toggle ────────────────────────────────────────── */}
        {shop && (shop.home_service === 'home_only' || shop.home_service === 'both') && (
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Where do you want the service?</div>
            <div style={{ display: 'flex', gap: 10 }}>
              {[
                { val: 'salon', label: 'At Salon', icon: (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                  </svg>
                )},
                { val: 'home', label: `Home Visit${shop.home_fee ? ` +Rs ${Number(shop.home_fee).toLocaleString()}` : ''}`, icon: (
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
                  </svg>
                )},
              ].filter(o => shop.home_service !== 'home_only' || o.val === 'home').map(({ val, label, icon }) => (
                <button key={val} type="button"
                  onClick={() => setBookingLocation(val)}
                  style={{
                    flex: 1, padding: '11px 10px', borderRadius: 12, cursor: 'pointer',
                    border: `2px solid ${bookingLocation === val ? 'var(--brand)' : 'var(--border)'}`,
                    background: bookingLocation === val ? 'var(--brand-glow2)' : 'var(--bg-input)',
                    color: bookingLocation === val ? 'var(--brand)' : 'var(--text-2)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
                    fontSize: 13, fontWeight: 700, transition: 'all 0.18s',
                  }}>
                  {icon}{label}
                </button>
              ))}
            </div>

            {/* Home service — location capture */}
            {bookingLocation === 'home' && (
              <div style={{ marginTop: 12, background: 'var(--bg-card)', border: '1.5px solid var(--border)', borderRadius: 14, padding: 14 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-2)', marginBottom: 10 }}>
                  Where should the barber come?
                </div>
                <button type="button" onClick={getGPSLocation} disabled={locatingGPS}
                  style={{
                    width: '100%', padding: '11px 12px', borderRadius: 12, marginBottom: 10,
                    border: `2px solid ${customerCoords ? 'var(--success)' : 'var(--brand)'}`,
                    background: customerCoords ? 'var(--brand-glow2)' : 'var(--bg-input)',
                    color: customerCoords ? 'var(--success)' : 'var(--brand)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7,
                    fontSize: 13, fontWeight: 700, cursor: 'pointer',
                  }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
                  </svg>
                  {locatingGPS ? 'Getting location…' : customerCoords ? 'Location captured ✓' : 'Use My Current Location'}
                </button>
                <textarea
                  value={customerAddress}
                  onChange={e => setCustomerAddress(e.target.value)}
                  placeholder="Or type your address / landmark (e.g. House 12, Street 5, near Al-Falah Masjid)"
                  rows={2}
                  style={{
                    width: '100%', background: 'var(--bg-input)', border: '1.5px solid var(--border)',
                    borderRadius: 'var(--radius-sm)', padding: '10px 12px',
                    color: 'var(--text-1)', fontFamily: 'var(--font-body)', fontSize: 13,
                    resize: 'none', outline: 'none', lineHeight: 1.5,
                  }}
                />
                <p style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 8 }}>
                  Sharing GPS location is the most accurate way for the barber to find you. You can also add an address as backup.
                </p>
              </div>
            )}
          </div>
        )}

        {/* Book Button */}
        <button className="btn btn-primary" onClick={bookSlot} disabled={booking || !selectedSlot || !selectedSrv}
          style={{ marginBottom: 32 }}>
          {booking ? <span className="spinner spinner-sm" /> : (() => {
            const homeFee = (bookingLocation === 'home' && shop?.home_fee) ? Number(shop.home_fee) : 0;
            const baseTotal = (selectedSrv?.price || 0) + homeFee;
            return `Book — ${selectedSrv ? `Rs ${baseTotal.toLocaleString()}` : 'Select Service & Slot'}`;
          })()}
        </button>

        {/* ── Reviews Section ── */}
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <p className="section-label" style={{ margin: 0 }}>Reviews</p>
            {canReview && !showReviewForm && (
              <button
                onClick={() => {
                  if (userReview) {
                    setReviewRating(userReview.rating);
                    setReviewComment(userReview.comment || '');
                  }
                  setShowReviewForm(true);
                }}
                style={{
                  fontSize: 13, fontWeight: 600, fontFamily: 'var(--font-display)',
                  color: 'var(--brand)', background: 'var(--brand-dim)',
                  border: '1.5px solid var(--border-brand)', borderRadius: 'var(--radius-xs)',
                  padding: '6px 14px', cursor: 'pointer'
                }}>
                {userReview ? 'Edit Review' : '+ Write Review'}
              </button>
            )}
            {!user && (
              <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Login to review</span>
            )}
            {user && !completedBooking && !userReview && (
              <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Visit to review</span>
            )}
          </div>

          {/* Review Form */}
          {showReviewForm && (
            <div style={{
              background: 'var(--bg-card)', border: '1.5px solid var(--border-brand)',
              borderRadius: 'var(--radius)', padding: 18, marginBottom: 16,
              boxShadow: 'var(--shadow-brand)'
            }}>
              <p style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, marginBottom: 14 }}>
                {userReview ? 'Update your review' : 'Rate your experience'}
              </p>

              {/* Star picker */}
              <div style={{ marginBottom: 14 }}>
                <StarRating value={reviewRating} onChange={setReviewRating} size={34} />
              </div>

              {/* Comment */}
              <textarea
                value={reviewComment}
                onChange={e => setReviewComment(e.target.value)}
                placeholder="Share your experience... (optional)"
                rows={3}
                style={{
                  width: '100%', background: 'var(--bg-input)', border: '1.5px solid var(--border)',
                  borderRadius: 'var(--radius-sm)', padding: '12px 14px',
                  color: 'var(--text-1)', fontFamily: 'var(--font-body)', fontSize: 14,
                  resize: 'none', outline: 'none', marginBottom: 14, lineHeight: 1.5
                }}
              />

              <div style={{ display: 'flex', gap: 10 }}>
                <button className="btn btn-primary" onClick={submitReview} disabled={submittingReview}
                  style={{ flex: 1, padding: '12px 0' }}>
                  {submittingReview ? <span className="spinner spinner-sm" /> : (userReview ? 'Update' : 'Submit')}
                </button>
                <button onClick={() => setShowReviewForm(false)}
                  style={{
                    flex: 1, padding: '12px 0', borderRadius: 'var(--radius)',
                    border: '1.5px solid var(--border)', background: 'var(--bg-input)',
                    color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 600,
                    fontSize: 15, cursor: 'pointer'
                  }}>
                  Cancel
                </button>
              </div>
            </div>
          )}

          {/* Review List */}
          {reviews.length === 0 ? (
            <div className="empty-state" style={{ padding: '28px 0' }}>
              <div className="empty-icon" style={{ display: 'flex', justifyContent: 'center' }}><StarFilled size={32} color="var(--text-3)" /></div>
              <div className="empty-sub">Be the first to review this shop</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {reviews.map((r, i) => (
                <div key={r.id} className="card card-sm stagger-in"
                  style={{
                    border: userReview?.id === r.id ? '1.5px solid var(--border-brand)' : undefined,
                    background: userReview?.id === r.id ? 'var(--brand-dim)' : undefined,
                    animationDelay: `${Math.min(i * 0.04, 0.3)}s`,
                  }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{
                        width: 30, height: 30, borderRadius: '50%',
                        background: 'var(--brand)', display: 'flex', alignItems: 'center',
                        justifyContent: 'center', color: '#fff',
                        fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, flexShrink: 0
                      }}>
                        {(r.profiles?.full_name || 'C')[0].toUpperCase()}
                      </div>
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 13, fontFamily: 'var(--font-display)', lineHeight: 1 }}>
                          {r.profiles?.full_name || 'Customer'}
                          {userReview?.id === r.id && (
                            <span style={{ marginLeft: 6, fontSize: 11, color: 'var(--brand)', fontWeight: 600 }}>You</span>
                          )}
                        </div>
                        <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 2 }}>
                          {format(new Date(r.created_at), 'MMM d, yyyy')}
                        </div>
                      </div>
                    </div>
                    <StarRating value={r.rating} size={15} />
                  </div>
                  {r.comment && (
                    <p style={{ color: 'var(--text-2)', fontSize: 13, lineHeight: 1.55, marginLeft: 38 }}>{r.comment}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
