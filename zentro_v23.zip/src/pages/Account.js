import { useEffect, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { usePlanPerks } from '../hooks/usePlanPerks';
import { format, addDays } from 'date-fns';
import { uploadShopImage, deleteImage, uploadPaymentProof } from '../lib/imageUpload';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import { createPortal } from 'react-dom';
import L from 'leaflet';
import BarberGuide from '../components/BarberGuide';
import { useOnboarding } from '../components/OnboardingTutorial';
import WalletCard from '../components/WalletCard';
import { getOrCreateReferralCode, buildInviteLink, copyToClipboard, fetchMyReferrals, fetchMyCredits } from '../lib/referrals';

// ── SVG Icon set (no basic emojis) ────────────────────────────────────────────
const Icon = {
  scissors: (c='var(--brand)') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
      <line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/>
      <line x1="8.12" y1="8.12" x2="12" y2="12"/>
    </svg>
  ),
  grid: (c='var(--brand)') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
      <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
    </svg>
  ),
  clock: (c='var(--brand)') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
    </svg>
  ),
  card: (c='var(--brand)') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>
    </svg>
  ),
  calendar: (c='var(--text-2)') => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/>
      <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
    </svg>
  ),
  check: (c='var(--success)') => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>
  ),
  x: (c='#fff') => (
    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="3" strokeLinecap="round">
      <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
    </svg>
  ),
  signout: () => (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
      <polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
    </svg>
  ),
  upload: () => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="16 16 12 12 8 16"/><line x1="12" y1="12" x2="12" y2="21"/>
      <path d="M20.39 18.39A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.3"/>
    </svg>
  ),
  bolt: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
    </svg>
  ),
  trash: () => (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
    </svg>
  ),
  store: (c='var(--brand)') => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
      <polyline points="9 22 9 12 15 12 15 22"/>
    </svg>
  ),
  trending: (c='var(--brand)') => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>
    </svg>
  ),
  users: (c='var(--brand)') => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
      <circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
      <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  qr: () => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="5" height="5"/><rect x="16" y="3" width="5" height="5"/>
      <rect x="3" y="16" width="5" height="5"/>
      <path d="M21 16h-3a2 2 0 0 0-2 2v3"/><line x1="21" y1="21" x2="21" y2="21"/>
      <path d="M3.5 8.5v0"/><path d="M20.5 8.5v0"/><path d="M8.5 3.5v0"/>
      <path d="M13.5 3.5h1"/><path d="M13.5 13.5h3"/><path d="M13.5 7.5v4"/>
    </svg>
  ),
  download: () => (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
      <polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
    </svg>
  ),
  copy: (c='#fff') => (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
    </svg>
  ),
  share: (c='#fff') => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
      <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
    </svg>
  ),
  gift: (c='var(--brand)') => (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 12 20 22 4 22 4 12"/>
      <rect x="2" y="7" width="20" height="5"/>
      <line x1="12" y1="22" x2="12" y2="7"/>
      <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/>
      <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
    </svg>
  ),
  timer: (c='#CC8E00') => (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="9"/>
      <polyline points="12 6 12 12 16 14"/>
      <polyline points="9 1 12 1 15 1"/>
    </svg>
  ),
  barChart: (c='var(--brand)') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="20" x2="18" y2="10"/>
      <line x1="12" y1="20" x2="12" y2="4"/>
      <line x1="6" y1="20" x2="6" y2="14"/>
      <line x1="2" y1="20" x2="22" y2="20"/>
    </svg>
  ),
  checkCircle: (c='var(--success)') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
      <polyline points="22 4 12 14.01 9 11.01"/>
    </svg>
  ),
};

// ── QR Code ───────────────────────────────────────────────────────────────────
function ZentroQR({ shopId, shopName, size = 240 }) {
  const canvasRef = useRef(null);
  const [qrReady, setQrReady] = useState(false);

  useEffect(() => {
    if (!shopId) return;
    drawBrandedQR(`${window.location.origin}/shop/${shopId}`);
  }, [shopId]); // eslint-disable-line

  const drawBrandedQR = (text) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const s = size;
    canvas.width = s; canvas.height = s;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      ctx.drawImage(img, 0, 0, s, s);
      const cx = s/2, cy = s/2, r = s*0.16;
      ctx.beginPath(); ctx.arc(cx, cy, r+5, 0, Math.PI*2);
      ctx.fillStyle = '#F0F6FF'; ctx.fill();
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI*2);
      ctx.fillStyle = '#060E1E'; ctx.fill();
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI*2);
      ctx.strokeStyle = '#0080FF'; ctx.lineWidth = 2.5; ctx.stroke();
      const lineH = Math.round(r*0.38), topY = cy - Math.round(r*0.1);
      ctx.font = `900 ${lineH}px Sora, sans-serif`;
      const zenW = ctx.measureText('Zen').width;
      const troSize = Math.round(r*0.36);
      ctx.font = `900 ${troSize}px Sora, sans-serif`;
      const troW = ctx.measureText('tro').width;
      const startX = cx - (zenW+troW)/2;
      ctx.font = `900 ${lineH}px Sora, sans-serif`;
      ctx.fillStyle = '#FFFFFF'; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
      ctx.fillText('Zen', startX, topY);
      ctx.font = `900 ${troSize}px Sora, sans-serif`;
      ctx.fillStyle = '#0080FF'; ctx.fillText('tro', startX+zenW, topY);
      setQrReady(true);
    };
    img.onerror = () => { setQrReady(true); };
    img.src = `https://api.qrserver.com/v1/create-qr-code/?size=${s}x${s}&data=${encodeURIComponent(text)}&margin=1&color=060E1E&bgcolor=F0F6FF&ecc=H`;
  };

  const download = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `zentro-qr-${shopName?.replace(/\s+/g,'-').toLowerCase()}.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 16 }}>
      <div style={{ padding: 14, background: '#fff', borderRadius: 20,
        border: '1.5px solid var(--border-brand)', boxShadow: 'var(--shadow-brand)', position: 'relative' }}>
        <canvas ref={canvasRef} style={{ display: 'block', borderRadius: 10 }} />
        {!qrReady && (
          <div style={{ position: 'absolute', inset: 14, borderRadius: 10, background: 'var(--bg-input)',
            display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div className="spinner" />
          </div>
        )}
      </div>
      <p style={{ fontSize: 12, color: 'var(--text-2)', textAlign: 'center', lineHeight: 1.6 }}>
        Customers scan to book at <strong style={{ color: 'var(--brand)' }}>{shopName}</strong>
      </p>
      {qrReady && (
        <button className="btn btn-secondary btn-sm" onClick={download}
          style={{ width: 'auto', paddingLeft: 20, paddingRight: 20, display: 'flex', alignItems: 'center', gap: 6 }}>
          {Icon.download()} Download QR
        </button>
      )}
    </div>
  );
}

// ── Stat Card ─────────────────────────────────────────────────────────────────
function StatCard({ label, value, icon }) {
  return (
    <div style={{
      background: 'var(--bg-card)', borderRadius: 16, padding: '16px 12px',
      border: '1px solid var(--border)', textAlign: 'center',
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8,
    }}>
      <div style={{ width: 36, height: 36, borderRadius: 12, background: 'var(--brand-glow)',
        display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{icon}</div>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17, color: 'var(--text-1)' }}>{value}</div>
      <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
    </div>
  );
}

// ── Status pill ───────────────────────────────────────────────────────────────
function StatusPill({ status }) {
  const map = {
    pending:   { bg: 'rgba(255,149,0,0.1)',  border: 'rgba(255,149,0,0.25)',  color: 'var(--warning)',  label: 'Pending' },
    confirmed: { bg: 'rgba(0,200,100,0.1)',  border: 'rgba(0,200,100,0.25)', color: 'var(--success)', label: 'Confirmed' },
    completed: { bg: 'rgba(0,128,255,0.1)',  border: 'rgba(0,128,255,0.2)',  color: 'var(--brand)',   label: 'Completed' },
    cancelled: { bg: 'rgba(0,0,0,0.05)',     border: 'rgba(0,0,0,0.1)',      color: 'var(--text-3)',  label: 'Cancelled' },
  };
  const s = map[status] || map.pending;
  return (
    <span style={{ fontSize: 10, fontWeight: 700, fontFamily: 'var(--font-display)',
      color: s.color, background: s.bg, border: `1px solid ${s.border}`,
      padding: '3px 10px', borderRadius: 100, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
      {s.label}
    </span>
  );
}

// ── Dashboard Tab ─────────────────────────────────────────────────────────────
const PLAN_ICONS_DB = {
  basic: (color = '#8EA0BC') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 2l20 20M2 22 12 12 22 2"/><path d="M7 7l10 10"/>
    </svg>
  ),
  pro: (color = '#0080FF') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
    </svg>
  ),
  premium: (color = '#FFB800') => (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 4l5 8 5-6 5 6 5-8v14H2z"/>
    </svg>
  ),
};
const TIER_COLORS_DB = { basic: '#8EA0BC', pro: '#0080FF', premium: '#FFB800' };

function SubCountdownDB({ expiresAt }) {
  if (!expiresAt) return null;
  const exp  = new Date(expiresAt);
  const now  = new Date();
  const diff = exp - now;
  const expired = diff <= 0;
  const days = expired ? 0 : Math.ceil(diff / (1000 * 60 * 60 * 24));
  const isUrgent = !expired && days <= 7;
  return (
    <div style={{
      marginTop: 12, padding: '10px 14px', borderRadius: 10,
      background: expired ? 'rgba(255,59,59,0.08)' : isUrgent ? 'rgba(255,149,0,0.08)' : 'rgba(0,128,255,0.06)',
      border: `1px solid ${expired ? 'rgba(255,59,59,0.2)' : isUrgent ? 'rgba(255,149,0,0.25)' : 'rgba(0,128,255,0.15)'}`,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    }}>
      <div>
        <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, color: expired ? 'var(--error)' : isUrgent ? 'var(--warning)' : 'var(--text-3)', marginBottom: 3 }}>
          {expired ? 'Subscription Expired' : 'Subscription Active'}
        </div>
        <div style={{ fontSize: 13, fontWeight: 600, color: expired ? 'var(--error)' : 'var(--text-1)' }}>
          {expired ? 'Renew to continue' : `Expires ${exp.toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}`}
        </div>
      </div>
      {!expired && (
        <div style={{ textAlign: 'center', background: isUrgent ? 'rgba(255,149,0,0.12)' : 'var(--brand-glow)', borderRadius: 10, padding: '6px 12px', minWidth: 54 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: isUrgent ? 'var(--warning)' : 'var(--brand)', lineHeight: 1 }}>{days}</div>
          <div style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', color: isUrgent ? 'var(--warning)' : 'var(--brand)', letterSpacing: 0.5 }}>days left</div>
        </div>
      )}
    </div>
  );
}

function BarberReferralCardDB({ userId, showToast }) {
  const [refCode, setRefCode]       = useState(null);
  const [codeCopied, setCodeCopied] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [referrals, setReferrals]   = useState([]);
  const [rewardDays, setRewardDays] = useState(null);

  useEffect(() => {
    if (!userId) return;
    getOrCreateReferralCode(userId).then(row => setRefCode(row?.code || null));
    fetchMyReferrals(userId).then(setReferrals);
    supabase.from('app_settings').select('value').eq('key', 'referral_reward_days').maybeSingle()
      .then(({ data }) => { if (data?.value) setRewardDays(Number(data.value)); });
  }, [userId]);

  const handleCopyCode = async () => {
    if (!refCode) return;
    const ok = await copyToClipboard(refCode);
    if (ok) { setCodeCopied(true); showToast('success', 'Code copied!'); setTimeout(() => setCodeCopied(false), 1800); }
  };

  const handleShareLink = async () => {
    if (!refCode) return;
    const link = buildInviteLink(refCode);
    if (navigator.share) {
      try { await navigator.share({ title: 'Join Zentro as a Barber', text: `List your shop on Zentro — use my referral code ${refCode} when you sign up!`, url: link }); return; }
      catch { return; }
    }
    const ok = await copyToClipboard(link);
    if (ok) { setLinkCopied(true); showToast('success', 'Invite link copied!'); setTimeout(() => setLinkCopied(false), 1800); }
  };

  const confirmed = referrals.filter(r => r.status === 'rewarded' || r.status === 'confirmed').length;
  const pending   = referrals.filter(r => r.status === 'pending').length;

  return (
    <div style={{ marginBottom: 8 }}>
      <div style={{
        borderRadius: 18, overflow: 'hidden', marginBottom: 12,
        background: 'linear-gradient(135deg, #0a1628 0%, #0b1f3e 50%, #071430 100%)',
        border: '1.5px solid rgba(0,128,255,0.25)',
        boxShadow: '0 8px 32px rgba(0,128,255,0.12)',
      }}>
        <div style={{ height: 3, background: 'linear-gradient(90deg, var(--brand), #00c6ff)' }} />
        <div style={{ padding: '18px 18px 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <div style={{ width: 44, height: 44, borderRadius: 14, flexShrink: 0,
              background: 'linear-gradient(135deg, rgba(0,128,255,0.25), rgba(0,198,255,0.15))',
              border: '1.5px solid rgba(0,128,255,0.3)',
              display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              {Icon.gift('var(--brand)')}
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, color: '#fff' }}>Refer Barbers</div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', marginTop: 2 }}>
                {rewardDays != null ? `Earn ${rewardDays} free subscription day${rewardDays !== 1 ? 's' : ''} per referral` : 'Earn free subscription days per referral'}
              </div>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
            {[
              { label: 'Confirmed', value: confirmed, color: 'var(--success)' },
              { label: 'Pending',   value: pending,   color: '#FFB800' },
            ].map(s => (
              <div key={s.label} style={{ background: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: '12px 14px', border: '1px solid rgba(255,255,255,0.08)' }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24, color: s.color, lineHeight: 1 }}>{s.value}</div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', fontWeight: 600, marginTop: 3, textTransform: 'uppercase', letterSpacing: 0.5 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        {refCode && (
          <div style={{ margin: '0 18px 18px', background: 'rgba(0,128,255,0.1)', border: '1px solid rgba(0,128,255,0.2)', borderRadius: 12, padding: '10px 14px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 3 }}>Your Code</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: '#fff', letterSpacing: 2 }}>{refCode}</div>
            </div>
            <button onClick={handleCopyCode} style={{
              background: codeCopied ? 'var(--success)' : 'var(--brand)',
              border: 'none', borderRadius: 10, padding: '10px 14px',
              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
              transition: 'all 0.2s', color: '#fff',
              fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700,
            }}>
              {codeCopied ? Icon.check('#fff') : Icon.copy('#fff')}
              {codeCopied ? 'Copied' : 'Copy'}
            </button>
          </div>
        )}
      </div>
      <button onClick={handleShareLink} className="btn btn-primary" style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
        {Icon.share()}
        {linkCopied ? 'Link Copied!' : 'Share Invite Link'}
      </button>
      {referrals.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <SectionLabel>Recent Referrals</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {referrals.slice(0, 4).map(r => (
              <div key={r.id} style={{ background: 'var(--bg-card)', borderRadius: 12, padding: '10px 14px', border: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ width: 34, height: 34, borderRadius: 10, flexShrink: 0, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    {Icon.users('var(--brand)')}
                  </div>
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13 }}>{r.referee?.full_name || 'New Barber'}</div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{new Date(r.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })}</div>
                  </div>
                </div>
                <span className={`badge ${r.status === 'rewarded' || r.status === 'confirmed' ? 'badge-success' : 'badge-warning'}`} style={{ textTransform: 'capitalize' }}>{r.status}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function SubscriptionDaysCardDB({ userId }) {
  const [days, setDays] = useState(null);
  useEffect(() => {
    if (!userId) return;
    fetchMyCredits(userId).then(d => setDays(d.subscriptionDaysTotal));
  }, [userId]);
  if (!days) return null;
  return (
    <div style={{ marginBottom: 20, borderRadius: 14, background: 'linear-gradient(135deg, #CC8E00, #FFB800)', padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 14, boxShadow: '0 6px 24px rgba(255,184,0,0.25)' }}>
      {Icon.timer('#fff')}
      <div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6 }}>Referral Bonus</div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: '#fff' }}>+{days} free day{days !== 1 ? 's' : ''}</div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', marginTop: 1 }}>Added to your next renewal</div>
      </div>
    </div>
  );
}

function DashboardTab({ user, showToast, perks }) {
  const [shop, setShop]         = useState(null);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats]       = useState({ today: 0, total: 0, completed: 0 });
  const [loading, setLoading]   = useState(true);
  const [bTab, setBTab]         = useState('today');

  const { plansConfig, loading: plansLoading } = usePlanPerks(shop?.subscription_tier || 'basic');

  useEffect(() => { fetchData(); }, []); // eslint-disable-line

  const fetchData = async () => {
    const { data: shopData } = await supabase.from('shops').select('*').eq('owner_id', user.id).maybeSingle();
    setShop(shopData);
    if (!shopData) { setLoading(false); return; }
    const { data: bData } = await supabase
      .from('bookings')
      .select('*, profiles(full_name), services(name, price), time_slots(slot_date, start_time)')
      .eq('shop_id', shopData.id)
      .order('created_at', { ascending: false });
    const bs = bData || [];
    setBookings(bs);
    const today = format(new Date(), 'yyyy-MM-dd');
    const todayBs = bs.filter(b => b.time_slots?.slot_date === today && b.status !== 'cancelled');
    const completed = bs.filter(b => b.status === 'completed').length;
    setStats({ today: todayBs.length, total: bs.length, completed });
    setLoading(false);
  };

  const updateStatus = async (bookingId, status, slotId) => {
    await supabase.from('bookings').update({ status }).eq('id', bookingId);
    if (status === 'cancelled') await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
    showToast('success', `Booking ${status}`);
    fetchData();
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  if (!shop) return (
    <div style={{ textAlign: 'center', padding: '48px 0' }}>
      <div style={{ width: 56, height: 56, borderRadius: 18, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
        {Icon.store()}
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--text-1)', marginBottom: 6 }}>No shop yet</div>
      <div style={{ fontSize: 13, color: 'var(--text-3)' }}>Set up your shop in the Setup tab</div>
    </div>
  );

  const today      = format(new Date(), 'yyyy-MM-dd');
  const todayBs    = bookings.filter(b => b.time_slots?.slot_date === today);
  const upcomingBs = bookings.filter(b => b.time_slots?.slot_date > today && b.status !== 'cancelled');
  const pastBs     = bookings.filter(b => b.time_slots?.slot_date < today);
  const tabBs      = bTab === 'today' ? todayBs : bTab === 'upcoming' ? upcomingBs : bTab === 'past' ? pastBs : bookings;
  const currentTier = shop.subscription_tier || 'basic';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* ── Status banner ── */}
      {!shop.is_active && (
        <div style={{ background: 'rgba(255,149,0,0.08)', border: '1px solid rgba(255,149,0,0.2)', borderRadius: 12, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--warning)', flexShrink: 0 }} />
          <span style={{ fontSize: 13, color: 'var(--warning)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Pending admin approval</span>
        </div>
      )}

      {/* ── Stats Cards ── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
        {[
          { label: 'Today',  value: stats.today,     icon: Icon.calendar('var(--brand)'),         accent: 'var(--brand)' },
          { label: 'Total',  value: stats.total,     icon: Icon.barChart('var(--brand)'),          accent: 'var(--brand)' },
          { label: 'Done',   value: stats.completed, icon: Icon.checkCircle('var(--success)'),     accent: 'var(--success)' },
        ].map(s => (
          <div key={s.label} style={{ borderRadius: 16, background: 'var(--bg-card)', border: '1.5px solid var(--border)', padding: '16px 10px', textAlign: 'center', position: 'relative', overflow: 'hidden' }}>
            <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)', width: 40, height: 2, borderRadius: 2, background: s.accent }} />
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 8 }}>{s.icon}</div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22, color: s.accent, lineHeight: 1 }}>{s.value}</div>
            <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── Referral Bonus Banner ── */}
      <SubscriptionDaysCardDB userId={user?.id} />

      {/* ── Subscription Plans ── */}
      {!plansLoading && (
        <div>
          <SectionLabel>Subscription Plans</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {['basic', 'pro', 'premium'].map(tier => {
              const p      = plansConfig[tier];
              const active = currentTier === tier;
              const color  = TIER_COLORS_DB[tier];
              return (
                <div key={tier} style={{ borderRadius: 16, border: active ? `2px solid ${color}` : '2px solid var(--border)', background: active ? `${color}08` : 'var(--bg-card)', position: 'relative', padding: '16px 18px', boxShadow: active ? `0 4px 20px ${color}22` : 'var(--shadow-card)' }}>
                  {active && (
                    <span style={{ position: 'absolute', top: 12, right: 14, background: color, color: '#fff', fontSize: 10, fontWeight: 700, borderRadius: 6, padding: '2px 8px', letterSpacing: 0.5 }}>YOUR PLAN</span>
                  )}
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                    <span>{PLAN_ICONS_DB[tier] && PLAN_ICONS_DB[tier](color)}</span>
                    <div>
                      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16 }}>{p?.name}</div>
                      <div style={{ fontSize: 13, color, fontWeight: 700 }}>Rs {p?.price?.toLocaleString()} / mo</div>
                    </div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                    {[
                      { label: 'Photos',   value: `${p?.photos} uploads` },
                      { label: 'QR Code',  value: p?.qr       ? 'Included' : 'Not included' },
                      { label: 'Badge',    value: p?.badge    ? 'Included' : 'Not included' },
                      { label: 'Priority', value: p?.priority ? 'Included' : 'Not included' },
                    ].map(f => (
                      <div key={f.label} style={{ background: 'var(--bg-input)', borderRadius: 8, padding: '8px 10px' }}>
                        <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 2 }}>{f.label}</div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: f.value.includes('Not') ? 'var(--text-3)' : 'var(--text-1)' }}>{f.value}</div>
                      </div>
                    ))}
                  </div>
                  {active && <SubCountdownDB expiresAt={shop.subscription_expires_at} />}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Refer Barbers ── */}
      <div>
        <SectionLabel>Refer Barbers</SectionLabel>
        <BarberReferralCardDB userId={user?.id} showToast={showToast} />
      </div>

      {/* ── Bookings Tabs ── */}
      <div>
        <SectionLabel>Bookings</SectionLabel>
        <div style={{ display: 'flex', gap: 8, marginBottom: 14, overflowX: 'auto', paddingBottom: 2 }}>
          {[
            { key: 'today',    label: `Today (${todayBs.length})` },
            { key: 'upcoming', label: `Upcoming (${upcomingBs.length})` },
            { key: 'past',     label: `Past (${pastBs.length})` },
            { key: 'all',      label: `All (${bookings.length})` },
          ].map(t => (
            <button key={t.key} onClick={() => setBTab(t.key)} style={{
              flexShrink: 0, padding: '7px 14px', borderRadius: 20, border: 'none',
              cursor: 'pointer', fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)',
              background: bTab === t.key ? 'var(--brand)' : 'var(--bg-input)',
              color:      bTab === t.key ? '#fff'         : 'var(--text-2)',
              transition: 'all 0.15s',
            }}>{t.label}</button>
          ))}
        </div>
        {tabBs.length === 0 ? (
          <div style={{ background: 'var(--bg-input)', borderRadius: 12, padding: '16px', textAlign: 'center' }}>
            <div style={{ fontSize: 13, color: 'var(--text-3)', fontFamily: 'var(--font-display)' }}>No bookings here</div>
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {tabBs.map((b, i) => (
              <div key={b.id} className="stagger-in" style={{ animationDelay: `${Math.min(i * 0.04, 0.3)}s` }}>
                <BookingRowDB booking={b} onUpdate={updateStatus} />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── QR Code ── */}
      <div style={{ borderTop: '1px solid var(--border)', paddingTop: 20 }}>
        <SectionLabel>My Shop QR Code</SectionLabel>
        {perks?.qr ? (
          <ZentroQR shopId={shop.id} shopName={shop.name} size={220} />
        ) : (
          <div style={{ background: 'var(--bg-input)', borderRadius: 16, padding: '20px 18px', textAlign: 'center', border: '1.5px dashed var(--border)' }}>
            <div style={{ width: 44, height: 44, borderRadius: 14, background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px' }}>
              {Icon.qr()}
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-1)', marginBottom: 6 }}>QR Code not included</div>
            <div style={{ fontSize: 12, color: 'var(--text-3)', lineHeight: 1.6 }}>
              Upgrade to <strong style={{ color: 'var(--brand)' }}>Pro</strong> or <strong style={{ color: '#FFB800' }}>Premium</strong> to get your branded QR code
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13,
      color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 12 }}>
      {children}
    </div>
  );
}

function BookingRowDB({ booking: b, onUpdate }) {
  return (
    <div style={{ background: 'var(--bg-card)', borderRadius: 16, padding: '14px 16px',
      border: '1px solid var(--border)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 10 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-1)' }}>
          {b.profiles?.full_name || 'Customer'}
        </div>
        <StatusPill status={b.status} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, marginBottom: b.status === 'pending' || b.status === 'confirmed' ? 14 : 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-2)' }}>
          {Icon.scissors('var(--text-3)')}
          <span>{b.services?.name} — <strong style={{ color: 'var(--text-1)' }}>Rs {b.services?.price}</strong></span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--text-2)' }}>
          {Icon.clock('var(--text-3)')}
          <span>{b.time_slots?.start_time?.slice(0, 5)}</span>
        </div>
      </div>
      {b.status === 'pending' && (
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={() => onUpdate(b.id, 'confirmed', b.time_slot_id)}>Confirm</button>
          <button className="btn btn-danger btn-sm" style={{ flex: 1 }} onClick={() => onUpdate(b.id, 'cancelled', b.time_slot_id)}>Cancel</button>
        </div>
      )}
      {b.status === 'confirmed' && (
        <button className="btn btn-primary btn-sm" style={{ display: 'flex', alignItems: 'center', gap: 6 }}
          onClick={() => onUpdate(b.id, 'completed', b.time_slot_id)}>
          {Icon.check('#fff')} Mark Complete
        </button>
      )}
    </div>
  );
}

// ── Map helpers for SetupTab ───────────────────────────────────────────────────
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});
function makeBrandPin() {
  return L.divIcon({
    className: '', iconSize: [36, 44], iconAnchor: [18, 44],
    html: `<svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M18 2C9.16 2 2 9.16 2 18c0 12 16 24 16 24S34 30 34 18C34 9.16 26.84 2 18 2z" fill="#0080FF"/>
      <circle cx="18" cy="18" r="8" fill="white" opacity="0.95"/>
    </svg>`,
  });
}
function LocationPickerMap({ position, onPick }) {
  useMapEvents({ click(e) { onPick([e.latlng.lat, e.latlng.lng]); } });
  return position ? <Marker position={position} icon={makeBrandPin()} /> : null;
}

// ── Setup Tab ─────────────────────────────────────────────────────────────────
function SetupTab({ user, showToast, perks }) {
  const [shopId, setShopId]       = useState(null);
  const [loading, setLoading]     = useState(true);
  const [saving, setSaving]       = useState(false);
  const [uploadingImg, setUpImg]  = useState(false);
  const [services, setServices]   = useState([]);
  const [newSrv, setNewSrv]       = useState({ name: '', price: '', duration_minutes: 30 });
  const [showMap, setShowMap]     = useState(false);
  const [locating, setLocating]   = useState(false);
  const [showCoordInput, setShowCoordInput] = useState(false);
  const [coordInput, setCoordInput] = useState({ lat: '', lng: '' });
  const [form, setForm] = useState({ name: '', city: '', address: '', description: '', phone: '', images: [], lat: null, lng: null });

  useEffect(() => { loadExisting(); }, []); // eslint-disable-line

  const loadExisting = async () => {
    const { data: s } = await supabase.from('shops').select('*').eq('owner_id', user.id).maybeSingle();
    if (s) {
      setShopId(s.id);
      setForm({ name: s.name||'', city: s.city||'', address: s.address||'', description: s.description||'', phone: s.phone||'', images: s.images||[], lat: s.lat||null, lng: s.lng||null });
      const { data: srv } = await supabase.from('services').select('*').eq('shop_id', s.id);
      setServices(srv || []);
    }
    setLoading(false);
  };

  const detectLocation = () => {
    if (!navigator.geolocation) return showToast('error', 'Geolocation not supported');
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setForm(p => ({ ...p, lat: pos.coords.latitude, lng: pos.coords.longitude }));
        setLocating(false);
        showToast('success', 'Location detected!');
      },
      () => { setLocating(false); showToast('error', 'Could not detect location'); },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const uploadImage = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!shopId) return showToast('error', 'Save shop details first');
    const maxPhotos = perks?.photos ?? 3;
    if (form.images.length >= maxPhotos) return showToast('error', `Your plan allows max ${maxPhotos} photos`);
    setUpImg(true);
    try {
      const url = await uploadShopImage(file, shopId);
      const newImages = [...form.images, url];
      setForm(p => ({ ...p, images: newImages }));
      await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
      showToast('success', 'Image uploaded');
    } catch (err) { showToast('error', 'Upload failed: ' + err.message); }
    setUpImg(false);
  };

  const removeImage = async (url) => {
    const newImages = form.images.filter(i => i !== url);
    setForm(p => ({ ...p, images: newImages }));
    await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
    await deleteImage(url);
    showToast('success', 'Image removed');
  };

  const save = async () => {
    if (!form.name || !form.city || !form.address) return showToast('error', 'Name, city and address required');
    setSaving(true);
    if (shopId) {
      // Only update content fields — never overwrite tier/status/approval
      const { error } = await supabase.from('shops').update({
        name: form.name, city: form.city, address: form.address,
        description: form.description, phone: form.phone,
        lat: form.lat, lng: form.lng,
      }).eq('id', shopId);
      if (error) { setSaving(false); return showToast('error', error.message); }
      showToast('success', 'Shop updated!');
    } else {
      const { data, error } = await supabase.from('shops').insert({
        owner_id: user.id, name: form.name, city: form.city, address: form.address,
        description: form.description, phone: form.phone,
        lat: form.lat, lng: form.lng,
        images: [], is_active: false, subscription_status: 'pending', subscription_tier: 'basic',
      }).select().maybeSingle();
      if (error) { setSaving(false); return showToast('error', error.message); }
      if (data) setShopId(data.id);
      showToast('success', 'Shop created! Awaiting admin approval.');
    }
    setSaving(false);
  };

  const addService = async () => {
    if (!shopId) return showToast('error', 'Save shop details first');
    if (!newSrv.name || !newSrv.price) return showToast('error', 'Name and price required');
    const { data, error } = await supabase.from('services')
      .insert({ ...newSrv, shop_id: shopId, price: parseFloat(newSrv.price), is_active: true })
      .select().maybeSingle();
    if (error) return showToast('error', error.message);
    if (data) setServices(prev => [...prev, data]);
    setNewSrv({ name: '', price: '', duration_minutes: 30 });
    showToast('success', 'Service added');
  };

  const removeService = async (id) => {
    await supabase.from('services').delete().eq('id', id);
    setServices(prev => prev.filter(s => s.id !== id));
    showToast('success', 'Service removed');
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  const mapCenter = form.lat && form.lng ? [form.lat, form.lng] : [30.3753, 69.3451];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* Full-screen map picker portal */}
      {showMap && createPortal(
        <div style={{ position: 'fixed', inset: 0, zIndex: 3000, background: 'var(--bg)', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', background: 'var(--bg-nav)', borderBottom: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button onClick={() => setShowMap(false)} style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 10, width: 36, height: 36, cursor: 'pointer', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-1)' }}>←</button>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>Pin Your Shop</span>
            </div>
            <button onClick={() => setShowMap(false)} style={{ background: 'linear-gradient(135deg, var(--brand), var(--brand-2))', color: '#fff', border: 'none', borderRadius: 12, padding: '8px 20px', cursor: 'pointer', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>Done</button>
          </div>
          <div style={{ padding: '10px 20px', background: 'var(--brand-glow)', borderBottom: '1px solid var(--border-brand)', fontSize: 13, color: 'var(--brand)', fontFamily: 'var(--font-display)', fontWeight: 600, textAlign: 'center' }}>
            Tap anywhere on the map to drop a pin
          </div>
          <div style={{ flex: 1, position: 'relative' }}>
            <MapContainer center={mapCenter} zoom={form.lat ? 15 : 6} style={{ width: '100%', height: '100%' }} zoomControl attributionControl={false}>
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              <LocationPickerMap
                position={form.lat && form.lng ? [form.lat, form.lng] : null}
                onPick={([lat, lng]) => setForm(p => ({ ...p, lat, lng }))}
              />
            </MapContainer>
            <button onClick={detectLocation} disabled={locating} style={{ position: 'absolute', bottom: 20, right: 16, zIndex: 999, background: '#fff', border: '1.5px solid var(--border-brand)', borderRadius: 14, padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: 'var(--brand)', cursor: 'pointer', boxShadow: 'var(--shadow-md)' }}>
              {locating ? <span className="spinner spinner-sm" /> : <svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'><path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/></svg>} Use My GPS
            </button>
          </div>
          {form.lat && form.lng && (
            <div style={{ padding: '12px 20px', background: 'var(--bg-card)', borderTop: '1px solid var(--border)', fontSize: 12, color: 'var(--text-2)', fontFamily: 'var(--font-display)', textAlign: 'center' }}>
              <svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round' style={{display:'inline',verticalAlign:'middle',marginRight:4}}><path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/></svg> {form.lat.toFixed(6)}, {form.lng.toFixed(6)} — saved
            </div>
          )}
        </div>
      , document.body)}

      {/* Basic Info */}
      <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
        <SectionLabel>Basic Info</SectionLabel>
        {[
          { label: 'Shop Name *', key: 'name', placeholder: 'e.g. Cuts & Glory' },
          { label: 'City *',      key: 'city', placeholder: 'e.g. Lahore' },
          { label: 'Address *',   key: 'address', placeholder: 'Full address' },
          { label: 'Phone',       key: 'phone', placeholder: '+92 300 0000000' },
        ].map(f => (
          <div key={f.key} className="input-group">
            <label className="input-label">{f.label}</label>
            <input className="input" placeholder={f.placeholder} value={form[f.key]}
              onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} />
          </div>
        ))}
        <div className="input-group">
          <label className="input-label">Description</label>
          <textarea className="input" placeholder="Tell customers about your shop..."
            value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
        </div>

        {/* Location */}
        <div className="input-group">
          <label className="input-label">Shop Location on Map</label>
          {/* Status */}
          <div style={{ background: 'var(--bg-input)', border: '1.5px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '12px 14px', marginBottom: 10 }}>
            {form.lat && form.lng ? (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--brand)', fontFamily: 'var(--font-display)', marginBottom: 2, display:'flex', alignItems:'center', gap:5 }}><svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'><path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/></svg> Location set</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{form.lat.toFixed(6)}, {form.lng.toFixed(6)}</div>
                </div>
                <button onClick={() => { setForm(p => ({ ...p, lat: null, lng: null })); setShowCoordInput(false); }}
                  style={{ background: 'none', border: '1px solid var(--border)', borderRadius: 8, padding: '5px 10px', cursor: 'pointer', fontSize: 12, color: 'var(--error)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
                  Clear
                </button>
              </div>
            ) : (
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--warning, #f59e0b)', fontFamily: 'var(--font-display)' }}>
                <svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round' style={{display:'inline',verticalAlign:'middle',marginRight:6}}><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'/><line x1='12' y1='9' x2='12' y2='13'/><line x1='12' y1='17' x2='12.01' y2='17'/></svg> No pin set — use an option below
              </div>
            )}
          </div>
          {/* 3 options */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
            <button onClick={() => { setShowMap(true); setShowCoordInput(false); }}
              style={{ flex: 1, padding: '10px 4px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--border-brand)', background: 'var(--brand-dim)', color: 'var(--brand)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 11, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/></svg>
              Pin on Map
            </button>
            <button onClick={() => { setShowCoordInput(v => !v); setCoordInput({ lat: form.lat || '', lng: form.lng || '' }); }}
              style={{ flex: 1, padding: '10px 4px', borderRadius: 'var(--radius-sm)', border: `1.5px solid ${showCoordInput ? 'var(--brand)' : 'var(--border)'}`, background: showCoordInput ? 'var(--brand-dim)' : 'var(--bg-input)', color: showCoordInput ? 'var(--brand)' : 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 11, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/></svg>
              Coordinates
            </button>
            <button onClick={detectLocation} disabled={locating}
              style={{ flex: 1, padding: '10px 4px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--border)', background: 'var(--bg-input)', color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 11, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
              {locating ? <span className="spinner spinner-sm" /> : (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="2" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22" y2="12"/></svg>
              )}
              Use GPS
            </button>
          </div>
          {/* Coord input panel */}
          {showCoordInput && (
            <div style={{ background: 'var(--bg-card)', border: '1.5px solid var(--border-brand)', borderRadius: 'var(--radius-sm)', padding: '14px', marginBottom: 10 }}>
              <p style={{ fontSize: 12, color: 'var(--text-2)', fontFamily: 'var(--font-display)', marginBottom: 10 }}>
                Open Google Maps → long press your shop → copy the numbers shown
              </p>
              <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                <div style={{ flex: 1 }}>
                  <label style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, display: 'block', marginBottom: 4 }}>LATITUDE</label>
                  <input className="input" placeholder="e.g. 31.5204" type="number" step="any"
                    value={coordInput.lat} onChange={e => setCoordInput(p => ({ ...p, lat: e.target.value }))} />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, display: 'block', marginBottom: 4 }}>LONGITUDE</label>
                  <input className="input" placeholder="e.g. 74.3587" type="number" step="any"
                    value={coordInput.lng} onChange={e => setCoordInput(p => ({ ...p, lng: e.target.value }))} />
                </div>
              </div>
              <button onClick={() => {
                const lat = parseFloat(coordInput.lat);
                const lng = parseFloat(coordInput.lng);
                if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180)
                  return showToast('error', 'Invalid coordinates');
                setForm(p => ({ ...p, lat, lng }));
                setShowCoordInput(false);
                showToast('success', 'Coordinates set!');
              }} className="btn btn-primary" style={{ padding: '10px 0' }}>
                Apply Coordinates
              </button>
            </div>
          )}
          <p style={{ fontSize: 11, color: 'var(--text-3)' }}>Pinning your shop lets customers find you on the map</p>
        </div>

        {shopId && (
          <div className="input-group">
            <label className="input-label">
              Shop Photos ({form.images.length}/{perks?.photos ?? 3})
              {perks?.photos != null && (
                <span style={{ marginLeft: 8, fontSize: 10, color: 'var(--brand)', fontWeight: 700,
                  background: 'var(--brand-glow)', padding: '2px 8px', borderRadius: 100 }}>
                  Plan limit
                </span>
              )}
            </label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 4 }}>
              {form.images.map(url => (
                <div key={url} className="pop-in" style={{ position: 'relative', width: 76, height: 76 }}>
                  <img src={url} alt="" style={{ width: 76, height: 76, objectFit: 'cover', borderRadius: 12 }} />
                  <button onClick={() => removeImage(url)} style={{
                    position: 'absolute', top: -5, right: -5, width: 20, height: 20, borderRadius: '50%',
                    background: 'var(--error)', color: '#fff', border: 'none', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>{Icon.x()}</button>
                </div>
              ))}
              {form.images.length < (perks?.photos ?? 3) ? (
                <label style={{ width: 76, height: 76, borderRadius: 12, border: '2px dashed var(--border)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                  color: 'var(--text-3)', background: 'var(--bg-input)' }}>
                  {uploadingImg ? <span className="spinner spinner-sm" /> : <span style={{ fontSize: 22, lineHeight: 1 }}>+</span>}
                  <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadImage} disabled={uploadingImg} />
                </label>
              ) : (
                <div style={{ width: 76, height: 76, borderRadius: 12, border: '1.5px dashed var(--border)',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                  background: 'var(--bg-input)', gap: 4 }}>
                  <span style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, textAlign: 'center', lineHeight: 1.3 }}>
                    Limit<br/>reached
                  </span>
                </div>
              )}
            </div>
            {form.images.length >= (perks?.photos ?? 3) && (
              <p style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 4 }}>
                Upgrade your plan to add more photos
              </p>
            )}
          </div>
        )}

        <button className="btn btn-primary" onClick={save} disabled={saving}>
          {saving ? <span className="spinner spinner-sm" /> : shopId ? 'Update Shop' : 'Create Shop'}
        </button>
      </div>

      {/* Services */}
      <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
        <SectionLabel>Services</SectionLabel>
        {services.length > 0 && (
          <div style={{ marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 2 }}>
            {services.map(s => (
              <div key={s.id} className="pop-in" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
                <div>
                  <div style={{ fontWeight: 700, fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--text-1)' }}>{s.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>Rs {s.price} · {s.duration_minutes} min</div>
                </div>
                <button onClick={() => removeService(s.id)} style={{
                  background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 8,
                  padding: '6px 10px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4,
                  fontSize: 12, color: 'var(--error)', fontFamily: 'var(--font-display)', fontWeight: 700,
                }}>
                  {Icon.trash()} Remove
                </button>
              </div>
            ))}
          </div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <input className="input" placeholder="Service name" style={{ flex: 2 }}
              value={newSrv.name} onChange={e => setNewSrv(p => ({ ...p, name: e.target.value }))} />
            <input className="input" placeholder="Price" type="number" style={{ flex: 1 }}
              value={newSrv.price} onChange={e => setNewSrv(p => ({ ...p, price: e.target.value }))} />
          </div>
          <select className="input" value={newSrv.duration_minutes}
            onChange={e => setNewSrv(p => ({ ...p, duration_minutes: parseInt(e.target.value) }))}>
            {[15, 20, 30, 45, 60, 90].map(d => <option key={d} value={d}>{d} minutes</option>)}
          </select>
          <button className="btn btn-secondary" onClick={addService}>+ Add Service</button>
        </div>
      </div>
    </div>
  );
}

// ── Slots Tab ─────────────────────────────────────────────────────────────────
function SlotsTab({ user, showToast }) {
  const [shopId, setShopId]             = useState(null);
  const [loading, setLoading]           = useState(true);
  const [slots, setSlots]               = useState([]);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [generating, setGenerating]     = useState(false);
  const [genForm, setGenForm] = useState({ start: '09:00', end: '18:00', interval: 30, daysAhead: 7 });

  useEffect(() => { loadShop(); }, []); // eslint-disable-line
  useEffect(() => { if (shopId) loadSlots(); }, [shopId, selectedDate]); // eslint-disable-line

  const loadShop = async () => {
    const { data } = await supabase.from('shops').select('id').eq('owner_id', user.id).maybeSingle();
    if (data) setShopId(data.id);
    else showToast('error', 'Set up your shop first');
    setLoading(false);
  };

  const loadSlots = useCallback(async () => {
    const { data } = await supabase.from('time_slots').select('*').eq('shop_id', shopId).eq('slot_date', selectedDate).order('start_time');
    setSlots(data || []);
  }, [shopId, selectedDate]);

  const generateSlots = async () => {
    if (!shopId) return;
    setGenerating(true);
    const dates = Array.from({ length: genForm.daysAhead }, (_, i) => format(addDays(new Date(), i), 'yyyy-MM-dd'));
    const toInsert = [];
    for (const date of dates) {
      const [sh, sm] = genForm.start.split(':').map(Number);
      const [eh, em] = genForm.end.split(':').map(Number);
      let cur = sh*60+sm, end = eh*60+em;
      while (cur+genForm.interval <= end) {
        const hh = String(Math.floor(cur/60)).padStart(2,'0'), mm = String(cur%60).padStart(2,'0');
        const nh = String(Math.floor((cur+genForm.interval)/60)).padStart(2,'0'), nm = String((cur+genForm.interval)%60).padStart(2,'0');
        toInsert.push({ shop_id: shopId, slot_date: date, start_time: `${hh}:${mm}:00`, end_time: `${nh}:${nm}:00`, is_booked: false });
        cur += genForm.interval;
      }
    }
    const { error } = await supabase.from('time_slots').upsert(toInsert, { onConflict: 'shop_id,slot_date,start_time', ignoreDuplicates: true });
    setGenerating(false);
    if (error) return showToast('error', error.message);
    showToast('success', `Generated slots for ${genForm.daysAhead} days`);
    loadSlots();
  };

  const deleteSlot = async (id) => {
    await supabase.from('time_slots').delete().eq('id', id);
    setSlots(prev => prev.filter(s => s.id !== id));
  };

  const deleteAllForDate = async () => {
    await supabase.from('time_slots').delete().eq('shop_id', shopId).eq('slot_date', selectedDate).eq('is_booked', false);
    showToast('success', 'Cleared all free slots');
    loadSlots();
  };

  const dates = Array.from({ length: 14 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { value: format(d, 'yyyy-MM-dd'), label: format(d, 'EEE'), day: format(d, 'd') };
  });

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
        <SectionLabel>Generate Slots</SectionLabel>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">Start</label>
            <input className="input" type="time" value={genForm.start} onChange={e => setGenForm(p => ({ ...p, start: e.target.value }))} />
          </div>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">End</label>
            <input className="input" type="time" value={genForm.end} onChange={e => setGenForm(p => ({ ...p, end: e.target.value }))} />
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">Interval</label>
            <select className="input" value={genForm.interval} onChange={e => setGenForm(p => ({ ...p, interval: parseInt(e.target.value) }))}>
              {[15, 20, 30, 45, 60].map(v => <option key={v} value={v}>{v} min</option>)}
            </select>
          </div>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">Days Ahead</label>
            <select className="input" value={genForm.daysAhead} onChange={e => setGenForm(p => ({ ...p, daysAhead: parseInt(e.target.value) }))}>
              {[1, 3, 7, 14, 30].map(v => <option key={v} value={v}>{v} days</option>)}
            </select>
          </div>
        </div>
        <button className="btn btn-primary" onClick={generateSlots} disabled={generating || !shopId}
          style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {generating ? <span className="spinner spinner-sm" /> : <>{Icon.bolt()} Generate Slots</>}
        </button>
      </div>

      <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
        <SectionLabel>Manage Slots</SectionLabel>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 12, marginBottom: 14 }}>
          {dates.map(d => (
            <button key={d.value} onClick={() => setSelectedDate(d.value)} style={{
              flexShrink: 0, width: 48, padding: '8px 0', borderRadius: 12,
              border: `1.5px solid ${selectedDate === d.value ? 'var(--brand)' : 'var(--border)'}`,
              background: selectedDate === d.value ? 'var(--brand-glow)' : 'var(--bg-input)',
              color: selectedDate === d.value ? 'var(--brand)' : 'var(--text-2)',
              fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            }}>
              <span style={{ fontSize: 9, textTransform: 'uppercase' }}>{d.label}</span>
              <span style={{ fontSize: 16 }}>{d.day}</span>
            </button>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <span style={{ fontSize: 12, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
            {slots.length} slots · {selectedDate}
          </span>
          {slots.some(s => !s.is_booked) && (
            <button className="btn btn-danger btn-sm" onClick={deleteAllForDate}>Clear Free</button>
          )}
        </div>

        {slots.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '20px 0', color: 'var(--text-3)', fontSize: 13, fontFamily: 'var(--font-display)' }}>
            No slots — generate above
          </div>
        ) : (
          <div key={selectedDate} style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {slots.map((s, i) => (
              <div key={s.id} className="pop-in" style={{
                padding: '7px 12px', borderRadius: 10,
                border: `1.5px solid ${s.is_booked ? 'rgba(255,59,48,0.3)' : 'rgba(0,200,100,0.3)'}`,
                background: s.is_booked ? 'rgba(255,59,48,0.06)' : 'rgba(0,200,100,0.06)',
                display: 'flex', alignItems: 'center', gap: 7,
                animationDelay: `${Math.min(i * 0.02, 0.3)}s`,
              }}>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12,
                  color: s.is_booked ? 'var(--error)' : 'var(--success)' }}>
                  {s.start_time.slice(0, 5)}
                </span>
                {!s.is_booked && (
                  <button onClick={() => deleteSlot(s.id)} style={{ background: 'none', border: 'none',
                    color: 'var(--text-3)', cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center' }}>
                    {Icon.x('var(--text-3)')}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Payment Tab ───────────────────────────────────────────────────────────────
const DEFAULT_PLANS_PT = {
  basic:   { name: 'Basic',   price: 999,  photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, photos: 30, qr: true,  badge: true,  priority: true  },
};
const TIER_COLORS_PT = { basic: '#8EA0BC', pro: '#0080FF', premium: '#FFB800' };

function PaymentTab({ user, showToast }) {
  const [shop, setShop]             = useState(null);
  const [payments, setPayments]     = useState([]);
  const [settings, setSettings]     = useState({});
  const [plans, setPlans]           = useState(DEFAULT_PLANS_PT);
  const [loading, setLoading]       = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingProof, setUpProof] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [form, setForm] = useState({ txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });
  const [numCopied, setNumCopied] = useState(false);
  const copyAccountNumber = async (num) => {
    try { await navigator.clipboard.writeText(num); setNumCopied(true); showToast('success', 'Number copied!'); setTimeout(() => setNumCopied(false), 1800); } catch { showToast('error', 'Copy failed'); }
  };

  useEffect(() => { loadData(); }, []); // eslint-disable-line

  const loadData = async () => {
    const [{ data: s }, { data: pays }, { data: cfg }] = await Promise.all([
      supabase.from('shops').select('id, name, subscription_tier, subscription_status, subscription_expires_at').eq('owner_id', user.id).maybeSingle(),
      supabase.from('payment_submissions').select('*').eq('owner_id', user.id).order('submitted_at', { ascending: false }),
      supabase.from('app_settings').select('key, value'),
    ]);
    setShop(s);
    setPayments(pays || []);
    const map = {};
    (cfg || []).forEach(r => { map[r.key] = r.value; });
    setSettings(map);
    if (map.plans_config) {
      try {
        const parsed = JSON.parse(map.plans_config);
        const merged = {};
        for (const t of ['basic', 'pro', 'premium']) merged[t] = { ...DEFAULT_PLANS_PT[t], ...(parsed[t] || {}) };
        setPlans(merged);
      } catch {}
    }
    setLoading(false);
  };

  const uploadProof = async (e) => {
    const file = e.target.files[0];
    if (!file || !user) return;
    setUpProof(true);
    try {
      const url = await uploadPaymentProof(file, user.id);
      setForm(p => ({ ...p, screenshot_url: url }));
      showToast('success', 'Screenshot uploaded');
    } catch (err) { showToast('error', 'Upload failed: ' + err.message); }
    setUpProof(false);
  };

  const submit = async () => {
    if (!shop)         return showToast('error', 'No shop found');
    if (!selectedPlan) return showToast('error', 'Select a plan first');
    if (!form.txn_id)  return showToast('error', 'Transaction ID required');
    setSubmitting(true);
    const plan = plans[selectedPlan];
    const { error } = await supabase.from('payment_submissions').insert({
      shop_id: shop.id, owner_id: user.id, amount: plan.price,
      txn_id: form.txn_id, screenshot_url: form.screenshot_url,
      payment_method: form.payment_method,
      requested_tier: selectedPlan,
      status: 'pending', submitted_at: new Date().toISOString(),
    });
    setSubmitting(false);
    if (error) return showToast('error', error.message);
    showToast('success', 'Payment submitted! Admin will review soon.');
    setForm({ txn_id: '', screenshot_url: '', payment_method: 'jazzcash' });
    setSelectedPlan(null);
    loadData();
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  const accountNumber = form.payment_method === 'jazzcash' ? settings.jazzcash_number : settings.easypaisa_number;
  const accountName   = form.payment_method === 'jazzcash' ? settings.jazzcash_name   : settings.easypaisa_name;
  const currentTier   = shop?.subscription_tier || 'basic';
  const isActive      = shop?.subscription_status === 'active';

  // Subscription time remaining
  const expiresAt   = shop?.subscription_expires_at ? new Date(shop.subscription_expires_at) : null;
  const now         = new Date();
  const msLeft      = expiresAt ? expiresAt - now : null;
  const daysLeft    = msLeft !== null ? Math.ceil(msLeft / (1000 * 60 * 60 * 24)) : null;
  const isExpired   = daysLeft !== null && daysLeft <= 0;
  const isUrgent    = daysLeft !== null && daysLeft > 0 && daysLeft <= 5;
  const expiryColor = isExpired ? '#FF4444' : isUrgent ? '#FFB800' : 'rgba(255,255,255,0.9)';
  const barPct      = expiresAt && shop?.subscription_approved_at
    ? Math.max(0, Math.min(100, (msLeft / (new Date(shop.subscription_approved_at) - expiresAt)) * -100))
    : null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      {shop && (
        <div style={{ background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
          borderRadius: 20, padding: '18px 20px', color: '#fff' }}>
          <div style={{ fontSize: 11, opacity: 0.8, fontFamily: 'var(--font-display)', fontWeight: 700,
            textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 8 }}>Current Plan</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: expiresAt ? 14 : 0 }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24, textTransform: 'capitalize' }}>
              {plans[currentTier]?.name || currentTier}
            </span>
            <span style={{ background: 'rgba(255,255,255,0.2)', borderRadius: 100, padding: '4px 14px',
              fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-display)', textTransform: 'capitalize' }}>
              {shop.subscription_status || 'Pending'}
            </span>
          </div>

          {/* ── Subscription countdown ── */}
          {expiresAt && (
            <div>
              {/* Progress bar */}
              <div style={{ height: 5, background: 'rgba(255,255,255,0.15)', borderRadius: 10, overflow: 'hidden', marginBottom: 8 }}>
                <div style={{
                  height: '100%', borderRadius: 10,
                  width: `${daysLeft > 0 ? Math.min(100, Math.max(2, (daysLeft / 30) * 100)) : 0}%`,
                  background: isExpired ? '#FF4444' : isUrgent ? '#FFB800' : 'rgba(255,255,255,0.8)',
                  transition: 'width 0.5s',
                }} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <span style={{ fontSize: 13, fontFamily: 'var(--font-display)', fontWeight: 700, color: expiryColor, display: 'flex', alignItems: 'center' }}>
                  {(isExpired || isUrgent) && }
                  {isExpired
                    ? 'Subscription expired'
                    : isUrgent
                      ? `${daysLeft} day${daysLeft === 1 ? '' : 's'} left — renew soon!`
                      : `${daysLeft} day${daysLeft === 1 ? '' : 's'} remaining`}
                </span>
                <span style={{ fontSize: 11, opacity: 0.65, fontFamily: 'var(--font-display)', fontWeight: 600 }}>
                  Expires {expiresAt.toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}
                </span>
              </div>
            </div>
          )}

          {!expiresAt && isActive && (
            <p style={{ fontSize: 12, opacity: 0.7, marginTop: 4, fontFamily: 'var(--font-display)' }}>
              No expiry date set — contact admin
            </p>
          )}
        </div>
      )}

      {/* ── Plan Cards ── */}
      <SectionLabel>Choose a Plan</SectionLabel>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {['basic', 'pro', 'premium'].map(tier => {
          const p          = plans[tier];
          const isSelected = selectedPlan === tier;
          const isCurrent  = currentTier === tier && isActive;
          const color      = TIER_COLORS_PT[tier];
          return (
            <div key={tier} onClick={() => setSelectedPlan(tier)} style={{
              background: 'var(--bg-card)', borderRadius: 16, cursor: 'pointer',
              border: `2px solid ${isSelected ? color : isCurrent ? color + '66' : 'var(--border)'}`,
              padding: '14px 16px', position: 'relative',
              boxShadow: isSelected ? `0 4px 16px ${color}22` : 'none', transition: 'all 0.15s',
            }}>
              {isCurrent && (
                <span style={{ position: 'absolute', top: 10, right: 12, background: color, color: '#fff',
                  fontSize: 9, fontWeight: 800, borderRadius: 6, padding: '2px 8px',
                  letterSpacing: 0.5, fontFamily: 'var(--font-display)' }}>ACTIVE</span>
              )}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                <div style={{ width: 20, height: 20, borderRadius: '50%', flexShrink: 0,
                  border: `2px solid ${isSelected ? color : 'var(--border)'}`,
                  background: isSelected ? color : 'transparent',
                  display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  {isSelected && <div style={{ width: 7, height: 7, borderRadius: '50%', background: '#fff' }} />}
                </div>
                <div style={{ width: 28, height: 28, borderRadius: 8, background: `${color}18`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  {PLAN_ICONS[tier] && PLAN_ICONS[tier](color)}
                </div>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, color: isSelected ? color : 'var(--text-1)' }}>{p?.name}</div>
                  <div style={{ fontSize: 12, color: color, fontWeight: 700 }}>Rs {p?.price?.toLocaleString()} / mo</div>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 5 }}>
                {[
                  { label: 'Photos',   value: `${p?.photos} uploads`, hasBool: false },
                  { label: 'QR Code',  bool: p?.qr },
                  { label: 'Badge',    bool: p?.badge },
                  { label: 'Priority', bool: p?.priority },
                ].map(f => (
                  <div key={f.label} style={{ background: 'var(--bg-input)', borderRadius: 8, padding: '6px 10px',
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 600, textTransform: 'uppercase' }}>{f.label}</div>
                    {f.hasBool === false
                      ? <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-1)' }}>{f.value}</div>
                      : f.bool
                        ? <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        : <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                    }
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* ── Payment form — only when plan selected ── */}
      {selectedPlan && (
        <>
          {(accountNumber || accountName) && (
            <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
              <SectionLabel>Send Rs {plans[selectedPlan]?.price?.toLocaleString()} To</SectionLabel>
              <div style={{ display: 'flex', gap: 8, marginBottom: 14 }}>
                {['jazzcash', 'easypaisa'].map(m => (
                  <button key={m} onClick={() => setForm(p => ({ ...p, payment_method: m }))}
                    className={`btn ${form.payment_method === m ? 'btn-primary' : 'btn-secondary'} btn-sm`}
                    style={{ flex: 1, textTransform: 'capitalize' }}>{m}</button>
                ))}
              </div>
              {accountNumber && (
                <div style={{ background: 'var(--bg-input)', borderRadius: 12, padding: '14px 16px' }}>
                  {accountName && <p style={{ fontSize: 12, color: 'var(--text-2)', marginBottom: 5 }}>
                    Account Name: <strong style={{ color: 'var(--text-1)' }}>{accountName}</strong></p>}
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
                    <p style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 20, color: 'var(--brand)', margin: 0 }}>{accountNumber}</p>
                    <button onClick={() => copyAccountNumber(accountNumber)} style={{
                      background: numCopied ? 'var(--success)' : 'var(--brand)',
                      border: 'none', borderRadius: 10, padding: '10px 14px',
                      cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                      flexShrink: 0, transition: 'all 0.2s', color: '#fff',
                      fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700,
                    }}>
                      {numCopied
                        ? <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                        : <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                      }
                      {numCopied ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
          <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
            <SectionLabel>Submit Payment Proof</SectionLabel>
            <div className="input-group">
              <label className="input-label">Transaction ID</label>
              <input className="input" placeholder="TXN ID from receipt" value={form.txn_id}
                onChange={e => setForm(p => ({ ...p, txn_id: e.target.value }))} />
            </div>
            <div className="input-group">
              <label className="input-label">Payment Screenshot</label>
              {form.screenshot_url ? (
                <div style={{ position: 'relative', marginBottom: 8 }}>
                  <img src={form.screenshot_url} alt="proof" style={{ width: '100%', borderRadius: 12, maxHeight: 180, objectFit: 'cover' }} />
                  <button onClick={() => setForm(p => ({ ...p, screenshot_url: '' }))}
                    style={{ position: 'absolute', top: 8, right: 8, background: 'var(--error)', color: '#fff',
                      border: 'none', borderRadius: 8, padding: '4px 10px', cursor: 'pointer', fontSize: 11,
                      fontFamily: 'var(--font-display)', fontWeight: 700 }}>Remove</button>
                </div>
              ) : (
                <label style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                  padding: '18px', border: '2px dashed var(--border)', borderRadius: 12,
                  background: 'var(--bg-input)', cursor: 'pointer', color: 'var(--text-2)', fontSize: 13 }}>
                  {uploadingProof ? <span className="spinner spinner-sm" /> : <>{Icon.upload()} Upload Screenshot</>}
                  <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadProof} disabled={uploadingProof} />
                </label>
              )}
            </div>
            <button className="btn btn-primary" onClick={submit} disabled={submitting}>
              {submitting ? <span className="spinner spinner-sm" /> : `Submit · ${plans[selectedPlan]?.name} Plan`}
            </button>
          </div>
        </>
      )}

      {payments.length > 0 && (
        <div>
          <SectionLabel>Payment History</SectionLabel>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {payments.map((p, i) => (
              <div key={p.id} className="stagger-in" style={{ background: 'var(--bg-card)', borderRadius: 16, padding: '14px 16px', border: '1px solid var(--border)', animationDelay: `${Math.min(i * 0.04, 0.3)}s` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
                  <div>
                    <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16 }}>Rs {p.amount}</span>
                    {p.requested_tier && (
                      <span style={{ marginLeft: 8, fontSize: 11, fontWeight: 700, color: TIER_COLORS_PT[p.requested_tier] || 'var(--brand)', textTransform: 'capitalize' }}>
                        · {p.requested_tier}
                      </span>
                    )}
                  </div>
                  <StatusPill status={p.status === 'approved' ? 'confirmed' : p.status === 'rejected' ? 'cancelled' : 'pending'} />
                </div>
                <p style={{ fontSize: 12, color: 'var(--text-2)', margin: '0 0 2px' }}>TXN: {p.txn_id} · {p.payment_method}</p>
                <p style={{ fontSize: 11, color: 'var(--text-3)', margin: 0 }}>{new Date(p.submitted_at).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Customer Booking Card ─────────────────────────────────────────────────────
function BookingCard({ booking: b, onCancel }) {
  return (
    <div style={{ background: 'var(--bg-card)', borderRadius: 18, padding: '16px', border: '1px solid var(--border)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 12 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, color: 'var(--text-1)' }}>{b.shops?.name}</div>
        <StatusPill status={b.status} />
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 5, marginBottom: b.status === 'pending' ? 14 : 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 13, color: 'var(--text-2)' }}>
          {Icon.scissors('var(--text-3)')}
          <span>{b.services?.name} — <strong style={{ color: 'var(--brand)' }}>Rs {b.services?.price}</strong></span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 13, color: 'var(--text-2)' }}>
          {Icon.calendar()}
          <span>{b.time_slots?.slot_date} at {b.time_slots?.start_time?.slice(0, 5)}</span>
        </div>
      </div>
      {b.status === 'pending' && (
        <button className="btn btn-danger btn-sm" onClick={onCancel}>Cancel Booking</button>
      )}
    </div>
  );
}

// ── Main Account Page ─────────────────────────────────────────────────────────
export default function Account() {
  const { user, profile, signOut, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [bookings, setBookings]   = useState([]);
  const [bTab, setBTab]           = useState('upcoming');
  const [bLoading, setBLoading]   = useState(true);
  const [barberTab, setBarberTab] = useState('dashboard');
  const [shopTier, setShopTier]   = useState(null);

  // Load plan perks from app_settings — live, admin-controlled
  const { perks, loading: perksLoading } = usePlanPerks(shopTier || 'basic');

  // Show barber tutorial only once
  const { TutorialEl } = useOnboarding(profile?.role === 'barber' ? 'barber' : null);

  useEffect(() => {
    if (!authReady) return;

    if (profile?.role !== 'barber') {
      fetchBookings();
    } else {
      // Load shop tier so plan perks are correct
      supabase.from('shops').select('subscription_tier').eq('owner_id', user.id).maybeSingle()
        .then(({ data }) => { if (data?.subscription_tier) setShopTier(data.subscription_tier); });
    }
  }, [user, authReady, profile]); // eslint-disable-line

  const fetchBookings = async () => {
    const { data } = await supabase
      .from('bookings')
      .select('*, shops(name, address), services(name, price), time_slots(slot_date, start_time)')
      .eq('customer_id', user.id)
      .order('created_at', { ascending: false });
    setBookings(data || []);
    setBLoading(false);
  };

  const cancel = async (id, slotId) => {
    const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', id);
    if (!error) {
      await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
      showToast('success', 'Booking cancelled');
      fetchBookings();
    } else showToast('error', 'Failed to cancel');
  };

  const handleSignOut = async () => { await signOut(); navigate('/'); };

  if (!authReady) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!user) return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '40px 24px 100px', textAlign: 'center' }}>
      {/* Brand icon */}
      <div style={{
        width: 72, height: 72, borderRadius: 22,
        background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        marginBottom: 24, boxShadow: 'var(--shadow-brand)',
      }}>
        {Icon.scissors('#fff')}
      </div>
      <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 26, marginBottom: 8, color: 'var(--text-1)' }}>
        Apna Account
      </h2>
      <p style={{ color: 'var(--text-2)', fontSize: 15, marginBottom: 36, maxWidth: 280, lineHeight: 1.6 }}>
        Bookings dekhne aur manage karne ke liye sign in karo
      </p>
      <button
        className="btn btn-primary"
        style={{ width: '100%', maxWidth: 320, marginBottom: 14 }}
        onClick={() => navigate('/login')}
      >
        Sign In
      </button>
      <button
        className="btn"
        style={{ width: '100%', maxWidth: 320, background: 'var(--bg-card)', border: '1px solid var(--border)', color: 'var(--text-1)' }}
        onClick={() => navigate('/register')}
      >
        Register — Free hai
      </button>
    </div>
  );

  const today    = format(new Date(), 'yyyy-MM-dd');
  const upcoming = bookings.filter(b => b.time_slots?.slot_date >= today && b.status !== 'cancelled');
  const past     = bookings.filter(b => b.time_slots?.slot_date < today  || b.status === 'cancelled');
  const list     = bTab === 'upcoming' ? upcoming : past;
  const isBarber = profile?.role === 'barber';

  const barberTabs = [
    { id: 'dashboard', label: 'Dashboard', short: 'Dash', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
        <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
      </svg>
    )},
    { id: 'setup', label: 'Setup', short: 'Setup', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
        <polyline points="9 22 9 12 15 12 15 22"/>
      </svg>
    )},
    { id: 'slots', label: 'Slots', short: 'Slots', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
      </svg>
    )},
    { id: 'payment', label: 'Payment', short: 'Pay', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>
      </svg>
    )},
    { id: 'guide', label: 'Guide', short: 'Guide', icon: (c='currentColor') => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/>
        <line x1="12" y1="8" x2="12" y2="12"/>
        <line x1="12" y1="16" x2="12.01" y2="16"/>
      </svg>
    )},
  ];

  return (
    <div className="page">
      {TutorialEl}
      {ToastEl}
      <div className="topnav">
        <div className="topnav-logo">Zen<span style={{ color: 'var(--brand)' }}>tro</span></div>
        <span style={{ fontSize: 13, color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>Account</span>
      </div>

      <div style={{ padding: '20px 20px 0' }}>

        {/* Profile Hero */}
        <div className="fade-up" style={{ marginBottom: 20 }}>
          <div style={{
            background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
            borderRadius: 22, padding: '18px 20px', color: '#fff',
            display: 'flex', alignItems: 'center', gap: 14,
            boxShadow: 'var(--shadow-brand)',
          }}>
            <div style={{
              width: 52, height: 52, borderRadius: 18,
              background: 'rgba(255,255,255,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22,
              flexShrink: 0, border: '2px solid rgba(255,255,255,0.35)',
            }}>
              {profile?.full_name?.[0]?.toUpperCase() || '?'}
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17, marginBottom: 2 }}>
                {profile?.full_name}
              </div>
              <div style={{ fontSize: 12, opacity: 0.8, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', marginBottom: 6 }}>
                {user.email}
              </div>
              <span style={{ background: 'rgba(255,255,255,0.2)', borderRadius: 100, padding: '2px 10px',
                fontSize: 10, fontWeight: 700, fontFamily: 'var(--font-display)', textTransform: 'capitalize' }}>
                {profile?.role}
              </span>
            </div>
            <button onClick={handleSignOut} style={{
              background: 'rgba(255,255,255,0.15)', border: '1px solid rgba(255,255,255,0.25)',
              borderRadius: 12, padding: '9px 12px', color: '#fff', cursor: 'pointer',
              display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0,
            }}>
              {Icon.signout()}
            </button>
          </div>
        </div>

        {/* BARBER: Tab bar */}
        {isBarber && (
          <>
            {/* ── Barber Nav: scroll row of icon+label pills, active gets brand bg ── */}
            <div style={{ marginBottom: 20, position: 'relative' }}>
              {/* Scrollable track */}
              <div style={{
                display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 2,
                scrollbarWidth: 'none', msOverflowStyle: 'none',
              }}>
                {barberTabs.map(t => {
                  const active = barberTab === t.id;
                  return (
                    <button key={t.id} onClick={() => setBarberTab(t.id)} style={{
                      flexShrink: 0,
                      display: 'flex', alignItems: 'center', gap: 8,
                      padding: active ? '10px 18px' : '10px 14px',
                      borderRadius: 50,
                      border: active ? 'none' : '1.5px solid var(--border)',
                      cursor: 'pointer', transition: 'all 0.2s cubic-bezier(0.34,1.56,0.64,1)',
                      background: active ? 'var(--brand)' : 'var(--bg-card)',
                      color: active ? '#fff' : 'var(--text-2)',
                      boxShadow: active ? '0 4px 14px rgba(0,128,255,0.35)' : 'none',
                    }}>
                      <span style={{ display: 'flex', alignItems: 'center', opacity: active ? 1 : 0.6, transition: 'opacity 0.2s' }}>
                        {t.icon(active ? '#fff' : 'var(--text-2)')}
                      </span>
                      <span style={{
                        fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700,
                        maxWidth: active ? 80 : 0,
                        overflow: 'hidden', whiteSpace: 'nowrap',
                        transition: 'max-width 0.25s ease, opacity 0.2s',
                        opacity: active ? 1 : 0,
                      }}>{t.label}</span>
                    </button>
                  );
                })}
              </div>
              {/* Fade-out edge hint */}
              <div style={{ position: 'absolute', right: 0, top: 0, bottom: 2, width: 24, background: 'linear-gradient(to right, transparent, var(--bg-page))', pointerEvents: 'none' }} />
            </div>

            <div className="fade-in">
              {barberTab === 'dashboard' && <DashboardTab user={user} showToast={showToast} perks={perks} />}
              {barberTab === 'setup'     && <SetupTab     user={user} showToast={showToast} perks={perks} />}
              {barberTab === 'slots'     && <SlotsTab     user={user} showToast={showToast} />}
              {barberTab === 'payment'   && <PaymentTab   user={user} showToast={showToast} />}
              {barberTab === 'guide'     && <BarberGuide />}
            </div>
          </>
        )}

        {/* CUSTOMER: Bookings */}
        {!isBarber && (
          <>
            <div
              className="card tap-feedback fade-up"
              onClick={() => navigate('/invite')}
              style={{
                display: 'flex', alignItems: 'center', gap: 12, marginBottom: 18,
                cursor: 'pointer', border: '1.5px solid var(--border-brand)',
                background: 'var(--brand-glow2)',
              }}
            >
              <div style={{
                width: 42, height: 42, borderRadius: 12, flexShrink: 0,
                background: 'linear-gradient(135deg, var(--brand), var(--brand-2))',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}>
                {Icon.scissors('#fff')}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15 }}>Invite Friends</div>
                <div style={{ fontSize: 12.5, color: 'var(--text-2)' }}>Earn booking credits for every signup</div>
              </div>
              <span style={{ color: 'var(--brand)', fontSize: 18, flexShrink: 0 }}>›</span>
            </div>

            <div style={{ marginBottom: 18 }}>
              <WalletCard userId={user.id} mode={isBarber ? "barber" : "customer"} />
            </div>

            <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
              {['upcoming', 'past'].map(t => (
                <button key={t} onClick={() => setBTab(t)}
                  className={`chip${bTab === t ? ' active' : ''}`}
                  style={{ textTransform: 'capitalize' }}>
                  {t} ({t === 'upcoming' ? upcoming.length : past.length})
                </button>
              ))}
            </div>
            {bLoading ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {[1, 2].map(i => <div key={i} className="skeleton" style={{ height: 130, borderRadius: 18 }} />)}
              </div>
            ) : list.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '48px 0' }}>
                <div style={{ width: 56, height: 56, borderRadius: 18, background: 'var(--brand-glow)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 14px' }}>
                  {Icon.scissors()}
                </div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16, color: 'var(--text-1)', marginBottom: 6 }}>
                  {bTab === 'upcoming' ? 'No upcoming bookings' : 'No past bookings'}
                </div>
                <div style={{ fontSize: 13, color: 'var(--text-3)', marginBottom: 20 }}>
                  Browse shops and book your next cut
                </div>
                <button className="btn btn-primary btn-sm" onClick={() => navigate('/')}>Explore Shops</button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                {list.map((b, i) => (
                  <div key={b.id} className="fade-up" style={{ animationDelay: `${i * 0.05}s` }}>
                    <BookingCard booking={b} onCancel={() => cancel(b.id, b.time_slot_id)} />
                  </div>
                ))}
              </div>
            )}
          </>
        )}
        <div style={{ height: 80 }} />
      </div>
    </div>
  );
}
