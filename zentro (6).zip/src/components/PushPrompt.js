import { useCallback, useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { enablePush, getPushStatus, pushConfigured } from '../lib/push';
import useLang from '../hooks/useLang';

const KEY = 'zentro_push_dismissed_at';
const SKEY = 'zentro_push_dismissed_session';
const DAY = 86400000;

// Banner that makes sure notifications really work on this phone.
// It checks every time the app is opened and shows:
//  - "Turn on" (opens the phone's permission box) when notifications are off,
//  - steps to unblock when the phone has blocked them.
// Barbers are asked on every app open until it works (a missed booking costs them money).
// Customers are asked again every 3 days. It never shows once notifications really work.
export default function PushPrompt() {
  const { user, profile } = useAuth();
  const { tr } = useLang();
  const [mode, setMode] = useState(null); // null | 'off' | 'retry' | 'blocked'
  const isBarber = profile?.role === 'barber';

  const dismissedRecently = useCallback(() => {
    try {
      if (sessionStorage.getItem(SKEY) === '1') return true;
      if (isBarber) return false;
      const at = Number(localStorage.getItem(KEY)) || 0;
      return !!at && Date.now() - at < 3 * DAY;
    } catch (e) { return false; }
  }, [isBarber]);

  const check = useCallback(async () => {
    if (!pushConfigured || !user) return setMode(null);
    const s = await getPushStatus();
    if ((s === 'off' || s === 'blocked') && !dismissedRecently()) setMode(s);
    else setMode(null);
  }, [user, dismissedRecently]);

  useEffect(() => {
    if (!user) { setMode(null); return undefined; }
    const t = setTimeout(check, 3500);
    const onVis = () => { if (document.visibilityState === 'visible') setTimeout(check, 3500); };
    document.addEventListener('visibilitychange', onVis);
    return () => { clearTimeout(t); document.removeEventListener('visibilitychange', onVis); };
  }, [user, check]);

  if (!mode) return null;

  const turnOn = () => {
    enablePush();
    setMode(null);
    setTimeout(async () => {
      const s = await getPushStatus();
      if (s === 'on') return;
      setMode(s === 'blocked' ? 'blocked' : 'retry');
    }, 5000);
  };
  const later = () => {
    try {
      sessionStorage.setItem(SKEY, '1');
      localStorage.setItem(KEY, String(Date.now()));
    } catch (e) { /* ignore */ }
    setMode(null);
  };
  const recheck = async () => {
    const s = await getPushStatus();
    setMode(s === 'on' ? null : (s === 'blocked' ? 'blocked' : 'retry'));
  };

  let text;
  if (mode === 'blocked') {
    text = tr(
      'Notifications are blocked on this phone. Open phone Settings, Apps, Zentro (or Chrome), Notifications, allow them, then open Zentro again.',
      'Is phone par notifications block hain. Phone Settings, Apps, Zentro (ya Chrome), Notifications mein allow karo, phir Zentro dubara kholo.'
    );
  } else if (mode === 'retry') {
    text = tr(
      'Notifications are still off. Tap Turn on and choose Allow.',
      'Notifications abhi bhi off hain. On karo dabao aur Allow chuno.'
    );
  } else {
    text = isBarber
      ? tr('Turn on notifications so you never miss a new booking', 'Notifications on karo taake koi nayi booking miss na ho')
      : tr('Turn on notifications for booking updates and reminders', 'Booking updates aur reminders ke liye notifications on karo');
  }

  return (
    <div style={{
      position: 'fixed', left: 12, right: 12, top: 'calc(env(safe-area-inset-top, 0px) + 12px)', zIndex: 3000,
      background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 14,
      padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10,
      boxShadow: '0 8px 24px rgba(0,0,0,0.18)', maxWidth: 480, margin: '0 auto',
    }}>
      <div style={{ flex: 1, fontSize: 13, color: 'var(--text-1)', fontWeight: 600, lineHeight: 1.4 }}>{text}</div>
      <button onClick={later} style={{ background: 'none', border: 'none', color: 'var(--text-3)', fontSize: 12, cursor: 'pointer' }}>{tr('Later', 'Baad mein')}</button>
      {mode === 'blocked'
        ? <button className="btn btn-primary btn-sm" onClick={recheck}>{tr('Check again', 'Dobara check')}</button>
        : <button className="btn btn-primary btn-sm" onClick={turnOn}>{tr('Turn on', 'On karo')}</button>}
    </div>
  );
}
