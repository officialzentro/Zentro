import { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { enablePush, pushConfigured } from '../lib/push';

// Small banner that asks the user to turn on notifications with one tap.
export default function PushPrompt() {
  const { user } = useAuth();
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!pushConfigured || !user || typeof Notification === 'undefined') return setShow(false);
    let dismissed = false;
    try { dismissed = localStorage.getItem('zentro_push_dismissed') === '1'; } catch (e) { /* ignore */ }
    setShow(Notification.permission === 'default' && !dismissed);
  }, [user]);

  if (!show) return null;

  const turnOn = () => {
    enablePush();
    setShow(false);
  };
  const later = () => {
    try { localStorage.setItem('zentro_push_dismissed', '1'); } catch (e) { /* ignore */ }
    setShow(false);
  };

  return (
    <div style={{
      position: 'fixed', left: 12, right: 12, top: 'calc(env(safe-area-inset-top, 0px) + 12px)', zIndex: 3000,
      background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 14,
      padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10,
      boxShadow: '0 8px 24px rgba(0,0,0,0.18)', maxWidth: 480, margin: '0 auto',
    }}>
      <div style={{ flex: 1, fontSize: 13, color: 'var(--text-1)', fontWeight: 600 }}>
        Turn on notifications to get booking alerts
      </div>
      <button onClick={later} style={{ background: 'none', border: 'none', color: 'var(--text-3)', fontSize: 12, cursor: 'pointer' }}>Later</button>
      <button className="btn btn-primary btn-sm" onClick={turnOn}>Turn on</button>
    </div>
  );
}
