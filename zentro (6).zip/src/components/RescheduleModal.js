// RescheduleModal — customer moves a booking to another free slot of the same shop.

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { addDays, format, parseISO } from 'date-fns';
import { supabase } from '../lib/supabase';
import { sendNotification } from '../lib/referrals';
import useLang from '../hooks/useLang';

function to12h(t) {
  if (!t) return '';
  const [hh, mm] = t.split(':');
  const h = parseInt(hh, 10);
  return `${((h + 11) % 12) + 1}:${mm} ${h >= 12 ? 'PM' : 'AM'}`;
}

export default function RescheduleModal({ booking, onClose, onDone, showToast }) {
  const { tr } = useLang();
  const [slots, setSlots]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [date, setDate]       = useState(null);
  const [picked, setPicked]   = useState(null);
  const [saving, setSaving]   = useState(false);

  const load = async () => {
    const today = new Date();
    const from  = format(today, 'yyyy-MM-dd');
    const to    = format(addDays(today, 7), 'yyyy-MM-dd');
    const { data } = await supabase.from('time_slots').select('*')
      .eq('shop_id', booking.shop_id).eq('is_booked', false)
      .gte('slot_date', from).lte('slot_date', to)
      .order('slot_date').order('start_time');
    const nowHM = format(new Date(), 'HH:mm:ss');
    const list  = (data || []).filter(s => s.slot_date !== from || s.start_time > nowHM);
    setSlots(list);
    setLoading(false);
    setDate(d => (d && list.some(s => s.slot_date === d) ? d : (list[0]?.slot_date || null)));
    setPicked(p => (p && list.some(s => s.id === p.id) ? p : null));
  };

  useEffect(() => { load(); }, []); // eslint-disable-line

  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const dates = [...new Set(slots.map(s => s.slot_date))];
  const daySlots = slots.filter(s => s.slot_date === date);

  const confirm = async () => {
    if (!picked || saving) return;
    setSaving(true);
    const oldSlotId = booking.time_slot_id;
    const { data: rows, error } = await supabase.from('bookings')
      .update({ time_slot_id: picked.id, status: 'pending' })
      .eq('id', booking.id).in('status', ['pending', 'confirmed'])
      .select('id');
    if (error || !rows || rows.length === 0) {
      setSaving(false);
      if (error && error.code === '23505') {
        showToast('error', tr('Someone just took this slot. Pick another', 'Yeh slot abhi kisi aur ne le liya. Dusra chuno'));
        load();
      } else {
        showToast('error', error ? tr('Could not reschedule: ', 'Reschedule nahi hua: ') + error.message : tr('This booking is no longer active', 'Yeh booking ab active nahi hai'));
      }
      return;
    }
    await supabase.from('time_slots').update({ is_booked: true }).eq('id', picked.id);
    await supabase.from('time_slots').update({ is_booked: false }).eq('id', oldSlotId);
    if (booking.shops?.owner_id) {
      sendNotification(booking.shops.owner_id, {
        title: 'Booking rescheduled',
        body: `${booking.services?.name || 'Booking'} moved to ${picked.slot_date} at ${to12h(picked.start_time)}. Please confirm.`,
        type: 'booking_rescheduled',
        meta: { url: '/account' },
      }).catch(() => {});
    }
    showToast('success', tr('Booking rescheduled. The barber will confirm again', 'Booking reschedule ho gayi. Barber dobara confirm karega'));
    setSaving(false);
    onDone();
  };

  const body = (
    <div className="fade-in" onClick={onClose} style={{
      position: 'fixed', inset: 0, zIndex: 9000, background: 'rgba(6,14,30,0.6)',
      display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{
        width: '100%', maxWidth: 440, maxHeight: '82vh', overflowY: 'auto',
        background: 'var(--bg-card)', borderRadius: '24px 24px 0 0', padding: '20px 20px 28px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 18, color: 'var(--text-1)' }}>{tr('Change time', 'Time badlo')}</div>
          <button onClick={onClose} aria-label="Close" style={{ background: 'var(--bg-input)', border: 'none', borderRadius: 10, width: 36, height: 36, cursor: 'pointer', color: 'var(--text-1)', fontSize: 18, lineHeight: 1 }}>&times;</button>
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 16 }}>
          {tr('Now', 'Abhi')}: {booking.time_slots?.slot_date} {tr('at', 'at')} {to12h(booking.time_slots?.start_time)}
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: 30 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>
        ) : dates.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '24px 0', fontSize: 13, color: 'var(--text-3)' }}>
            {tr('No free slots in the next 7 days.', 'Agle 7 din mein koi khali slot nahi hai.')}
          </div>
        ) : (
          <>
            <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 6, marginBottom: 12 }}>
              {dates.map(d => (
                <button key={d} onClick={() => { setDate(d); setPicked(null); }} style={{
                  flexShrink: 0, padding: '8px 14px', borderRadius: 999, cursor: 'pointer', fontSize: 12, fontWeight: 700,
                  fontFamily: 'var(--font-display)', border: 'none',
                  background: date === d ? 'var(--brand)' : 'var(--bg-input)',
                  color: date === d ? '#fff' : 'var(--text-2)',
                }}>{format(parseISO(d), 'EEE d MMM')}</button>
              ))}
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginBottom: 14 }}>
              {daySlots.map(s => (
                <button key={s.id} onClick={() => setPicked(s)} style={{
                  padding: '11px 4px', borderRadius: 12, cursor: 'pointer', fontSize: 13, fontWeight: 700,
                  fontFamily: 'var(--font-display)',
                  border: `1.5px solid ${picked?.id === s.id ? 'var(--brand)' : 'var(--border)'}`,
                  background: picked?.id === s.id ? 'var(--brand-glow)' : 'var(--bg-input)',
                  color: picked?.id === s.id ? 'var(--brand)' : 'var(--text-1)',
                }}>{to12h(s.start_time)}</button>
              ))}
            </div>
            {booking.status === 'confirmed' && (
              <div style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 12, lineHeight: 1.5 }}>
                {tr('The barber will need to confirm the new time again.', 'Naye time par barber ko dobara confirm karna hoga.')}
              </div>
            )}
            <button className="btn btn-primary" style={{ width: '100%' }} disabled={!picked || saving} onClick={confirm}>
              {saving ? <span className="spinner spinner-sm" /> : tr('Confirm new time', 'Naya time pakka karo')}
            </button>
          </>
        )}
      </div>
    </div>
  );

  return createPortal(body, document.body);
}
