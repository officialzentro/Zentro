import { useEffect, useState } from 'react';
import { TutorialPrompt } from './TutorialVideo';

// ─── Keys stored in localStorage so tutorials only show once ────────────────
const KEY_CUSTOMER = 'zentro_onboarded_customer_v1';
const KEY_BARBER   = 'zentro_onboarded_barber_v1';

// ─── Customer tutorial steps ─────────────────────────────────────────────────
const CUSTOMER_STEPS = [
  {
    icon: (
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
      </svg>
    ),
    title: 'Barber Dhundho',
    body: 'Home screen par apne sheher ke barbers list hain. Location allow karo toh nearby wale pehle nazar aate hain.',
  },
  {
    icon: (
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
        <line x1="16" y1="2" x2="16" y2="6"/>
        <line x1="8" y1="2" x2="8" y2="6"/>
        <line x1="3" y1="10" x2="21" y2="10"/>
        <circle cx="12" cy="16" r="1.5" fill="var(--brand)"/>
      </svg>
    ),
    title: 'Slot Book Karo',
    body: 'Shop tap karo, apni service choose karo, aur available time slot select karo. Done!',
  },
  {
    icon: (
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 6 9 17 4 12"/>
      </svg>
    ),
    title: 'Confirmation Milegi',
    body: 'Booking confirm hone par Account tab mein apni appointment nazar aayegi. Barber accept kar le toh aaram se time par pohonch jaao!',
  },
  {
    icon: (
      <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
      </svg>
    ),
    title: 'Review Do',
    body: 'Haircut ke baad barber ko rating do. Isse doosron ko acha barber dhundne mein madad milti hai!',
  },
];

// ─── Dot indicator ────────────────────────────────────────────────────────────
function Dots({ total, current }) {
  return (
    <div style={{ display: 'flex', gap: 6, justifyContent: 'center', marginBottom: 24 }}>
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} style={{
          width: i === current ? 20 : 6, height: 6,
          borderRadius: 3,
          background: i === current ? 'var(--brand)' : 'rgba(255,255,255,0.2)',
          transition: 'all 0.3s',
        }} />
      ))}
    </div>
  );
}

// ─── Tutorial overlay ─────────────────────────────────────────────────────────
function TutorialOverlay({ steps, onDone }) {
  const [step, setStep] = useState(0);
  const current = steps[step];
  const isLast  = step === steps.length - 1;

  return (
    <div className="fade-in" style={{
      position: 'fixed', inset: 0, zIndex: 9999,
      background: 'rgba(6,14,30,0.96)',
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      padding: '40px 28px',
    }}>
      {/* Logo */}
      <div style={{
        fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22,
        marginBottom: 40, letterSpacing: '-0.5px',
      }}>
        <span style={{ color: '#fff' }}>Zen</span>
        <span style={{ color: 'var(--brand)' }}>tro</span>
      </div>

      {/* Card */}
      <div key={step} className="pop-in" style={{
        width: '100%', maxWidth: 340,
        background: 'var(--bg-card)',
        border: '1.5px solid var(--border)',
        borderRadius: 24, padding: '32px 28px 28px',
        textAlign: 'center',
      }}>
        {/* Icon */}
        <div style={{
          width: 80, height: 80, borderRadius: 24,
          background: 'var(--brand-glow)',
          border: '1.5px solid var(--border-brand)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto 22px',
        }}>
          {current.icon}
        </div>

        {/* Step counter */}
        <p style={{
          fontSize: 10, fontWeight: 800, letterSpacing: 1.2,
          textTransform: 'uppercase', color: 'var(--brand)',
          marginBottom: 8, fontFamily: 'var(--font-display)',
        }}>
          Step {step + 1} of {steps.length}
        </p>

        <h2 style={{
          fontFamily: 'var(--font-display)', fontWeight: 900,
          fontSize: 20, marginBottom: 12, color: 'var(--text-1)',
          letterSpacing: '-0.3px',
        }}>
          {current.title}
        </h2>
        <p style={{
          fontSize: 14, color: 'var(--text-2)', lineHeight: 1.65,
          fontFamily: 'var(--font-display)', fontWeight: 500,
          marginBottom: 28,
        }}>
          {current.body}
        </p>

        <Dots total={steps.length} current={step} />

        <button
          className="btn btn-primary"
          style={{ width: '100%', marginBottom: isLast ? 0 : 10, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
          onClick={() => isLast ? onDone() : setStep(s => s + 1)}
        >
          {isLast ? (
            <>
              Let's Go!
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5z"/>
                <path d="M19 15l.75 2.25L22 18l-2.25.75L19 21l-.75-2.25L16 18l2.25-.75z"/>
                <path d="M5 3l.5 1.5L7 5l-1.5.5L5 7l-.5-1.5L3 5l1.5-.5z"/>
              </svg>
            </>
          ) : 'Next →'}
        </button>

        {!isLast && (
          <button
            onClick={onDone}
            style={{
              background: 'none', border: 'none', cursor: 'pointer',
              color: 'var(--text-3)', fontSize: 13,
              fontFamily: 'var(--font-display)', fontWeight: 600,
              width: '100%', padding: '8px 0',
            }}
          >
            Skip Tutorial
          </button>
        )}
      </div>
    </div>
  );
}

// ─── Exported hook — call once in Account / Home after auth ──────────────────
// Only shows for NEW users (account created within last 10 minutes).
// Existing / returning users are skipped automatically.
export function useOnboarding(role, user) {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (!role) return;
    const key = role === 'barber' ? KEY_BARBER : KEY_CUSTOMER;

    // Already dismissed before — never show again
    if (localStorage.getItem(key)) return;

    // If we have user info, check account age
    if (user?.created_at) {
      const ageMs = Date.now() - new Date(user.created_at).getTime();
      const tenMinutes = 10 * 60 * 1000;
      if (ageMs > tenMinutes) {
        // Existing user — mark as seen silently so it never pops up
        localStorage.setItem(key, '1');
        return;
      }
    }

    setShow(true);
  }, [role, user]);

  const dismiss = () => {
    const key = role === 'barber' ? KEY_BARBER : KEY_CUSTOMER;
    localStorage.setItem(key, '1');
    setShow(false);
  };

  const TutorialEl = show
    ? (role === 'barber'
        ? <TutorialPrompt onDone={dismiss} />
        : <TutorialOverlay steps={CUSTOMER_STEPS} onDone={dismiss} />)
    : null;

  return { TutorialEl };
}
