// ReminderPrefs — customer chooses when booking reminders arrive.
// Saved on the profile as reminder_prefs (see zentro_reminders.sql).

import { useState } from 'react';
import { supabase } from '../lib/supabase';
import useLang from '../hooks/useLang';

const DEFAULTS = { day: true, hours2: true, min30: false };
const OPTIONS = [
  { key: 'day',    en: '1 day before',    ur: '1 din pehle' },
  { key: 'hours2', en: '2 hours before',  ur: '2 ghante pehle' },
  { key: 'min30',  en: '30 min before',   ur: '30 min pehle' },
];

export default function ReminderPrefs({ user, profile, refreshProfile, showToast }) {
  const { tr } = useLang();
  const saved = profile?.reminder_prefs;
  const fromProfile = { ...DEFAULTS, ...(saved && typeof saved === 'object' ? saved : {}) };
  const [local, setLocal]   = useState(null);
  const [saving, setSaving] = useState(false);
  const prefs = local || fromProfile;
  const anyOn = OPTIONS.some(o => prefs[o.key]);

  const toggle = async (key) => {
    if (saving || !user?.id) return;
    const next = { ...prefs, [key]: !prefs[key] };
    setLocal(next);
    setSaving(true);
    const { error } = await supabase.from('profiles').update({ reminder_prefs: next }).eq('id', user.id);
    setSaving(false);
    if (error) {
      setLocal(null);
      showToast('error', tr('Could not save the reminder. Please try again', 'Reminder save nahi hua. Dobara try karo'));
      return;
    }
    if (refreshProfile) refreshProfile();
  };

  return (
    <div className="card fade-up" style={{ marginBottom: 18, padding: '16px 18px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
        <div style={{ width: 36, height: 36, borderRadius: 10, background: 'var(--brand-dim)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)', flexShrink: 0 }}>
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" /><path d="M13.7 21a2 2 0 0 1-3.4 0" />
          </svg>
        </div>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontWeight: 700, fontSize: 14 }}>{tr('Booking reminders', 'Booking reminder')}</div>
          <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 1 }}>
            {anyOn ? tr('Applied to every booking automatically', 'Har booking par apne aap lagta hai') : tr('Reminders are off', 'Reminder band hai')}
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {OPTIONS.map(o => {
          const on = !!prefs[o.key];
          return (
            <button key={o.key} type="button" aria-pressed={on} onClick={() => toggle(o.key)} style={{
              padding: '9px 14px', borderRadius: 999, cursor: 'pointer', fontSize: 13, fontWeight: 700,
              fontFamily: 'var(--font-display)',
              border: `1.5px solid ${on ? 'var(--brand)' : 'var(--border)'}`,
              background: on ? 'var(--brand)' : 'var(--bg-input)',
              color: on ? '#fff' : 'var(--text-2)',
            }}>{tr(o.en, o.ur)}</button>
          );
        })}
      </div>
      <div style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 10, lineHeight: 1.5 }}>
        {tr('Reminders also arrive on your phone (if push notifications are on). You get none for cancelled or completed bookings.', 'Reminder phone par bhi aata hai (push notifications on hon to). Cancel ya complete hui booking par nahi aata.')}
      </div>
    </div>
  );
}
