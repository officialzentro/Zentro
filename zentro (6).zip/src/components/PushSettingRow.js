import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { enablePush, getPushStatus, sendPushChecked, ensureLinked, pushConfigured } from '../lib/push';

// Settings row: shows if notifications are on for this phone, and lets the user turn them on.
export default function PushSettingRow({ bare = false }) {
  const { user } = useAuth();
  const [status, setStatus] = useState('loading');
  const [sent, setSent] = useState(false);
  const [result, setResult] = useState('');

  const refresh = useCallback(() => { getPushStatus().then(setStatus); }, []);
  useEffect(() => { refresh(); }, [refresh]);

  if (!pushConfigured || status === 'unsupported') return null;

  const turnOn = () => {
    enablePush();
    setTimeout(refresh, 2500);
    setTimeout(refresh, 6000);
  };
  const test = async () => {
    setSent(true);
    setResult('');
    const linked = await ensureLinked(user?.id);
    if (!linked) {
      setResult('This phone could not be linked to your account. Close the app, open it again, and try once more.');
      setSent(false);
      return;
    }
    const wait = (ms) => new Promise((res) => setTimeout(res, ms));
    const msg = { title: 'Zentro test', body: 'Notifications are working on this phone.' };
    await wait(2500); // OneSignal needs a moment to save the link
    let r = await sendPushChecked(user?.id, msg);
    if (!r.ok && String(r.reason).includes('invalid_aliases')) {
      await wait(5000);
      r = await sendPushChecked(user?.id, msg);
    }
    setResult(r.ok ? 'Test sent. It should arrive in a few seconds.' : 'Test failed: ' + r.reason);
    setSent(false);
  };

  const text = {
    loading: 'Checking…',
    on: 'On. You will get booking alerts.',
    off: 'Off. Tap Turn on to get booking alerts.',
    blocked: 'Blocked. Open phone Settings, Apps, Zentro (or Chrome), Notifications and allow them.',
  }[status];

  const btn = { border: 'none', borderRadius: 8, padding: '7px 12px', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-display)' };
  const inner = (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 13.5 }}>Notifications</div>
        <div style={{ fontSize: 11.5, color: status === 'on' ? 'var(--success, #16a34a)' : 'var(--text-3)', marginTop: 2 }}>{text}</div>
      </div>
      {status === 'off' && <button onClick={turnOn} style={{ ...btn, background: 'var(--brand)', color: '#fff' }}>Turn on</button>}
      {status === 'on' && <button onClick={test} disabled={sent} style={{ ...btn, background: 'var(--bg-input)', color: 'var(--brand)' }}>{sent ? 'Sending…' : 'Send test'}</button>}
    </div>
  );
  const resultLine = result ? <div style={{ fontSize: 11.5, marginTop: 8, color: result.startsWith('Test sent') ? 'var(--success, #16a34a)' : 'var(--danger, #dc2626)' }}>{result}</div> : null;
  if (bare) return <div style={{ padding: '14px 0', borderBottom: '1px solid var(--border)' }}>{inner}{resultLine}</div>;
  return <div className="card fade-up" style={{ marginBottom: 18, padding: '14px 16px' }}>{inner}{resultLine}</div>;
}
