// TutorialVideo — barber tutorial (YouTube) split into 6 step clips.
// Plays inside the app. Each step plays only its own part of the video.

import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import useLang from '../hooks/useLang';

export const TUTORIAL_VIDEO_ID = 'wWaMBwrBzEM';
export const TUTORIAL_URL = 'https://youtube.com/shorts/' + TUTORIAL_VIDEO_ID;

// Times are in seconds, taken from the video itself (intro 0:00-0:04, outro 0:53-0:58)
export const TUTORIAL_STEPS = [
  { id: 'account',  en: 'Create account',      title: 'Account banao',    start: 4.5,  end: 11 },
  { id: 'shop',     en: 'Set up your shop',    title: 'Shop setup karo',  start: 11,   end: 24 },
  { id: 'slots',    en: 'Make slots',          title: 'Slots banao',      start: 24,   end: 31.5 },
  { id: 'plan',     en: 'Choose a plan',       title: 'Plan chuno',       start: 31.5, end: 38 },
  { id: 'bookings', en: 'Manage bookings',     title: 'Bookings manage',  start: 38,   end: 44.5 },
  { id: 'qr',       en: 'Put up your QR code', title: 'QR code lagao',    start: 44.5, end: 53 },
];

const HIDE_KEY = 'zentro_tutorial_card_hidden_v1';

// ── YouTube IFrame API (loaded once) ──────────────────────────────────────────
let ytPromise = null;
function loadYT() {
  if (window.YT && window.YT.Player) return Promise.resolve(window.YT);
  if (ytPromise) return ytPromise;
  ytPromise = new Promise((resolve) => {
    const prev = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      if (typeof prev === 'function') prev();
      resolve(window.YT);
    };
    const s = document.createElement('script');
    s.src = 'https://www.youtube.com/iframe_api';
    s.async = true;
    document.head.appendChild(s);
  });
  return ytPromise;
}

function rangeOf(id) {
  if (id === 'all') return { start: 0, end: null };
  const s = TUTORIAL_STEPS.find(x => x.id === id);
  return s ? { start: s.start, end: s.end } : { start: 0, end: null };
}

const PlayIcon = ({ size = 14 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
    <polygon points="6 4 20 12 6 20 6 4" />
  </svg>
);

const CloseIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
  </svg>
);

const ReplayIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="1 4 1 10 7 10" />
    <path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10" />
  </svg>
);

// ── Modal player ──────────────────────────────────────────────────────────────
export function TutorialModal({ stepId = 'all', onClose }) {
  const { tr } = useLang();
  const [sel, setSel]     = useState(stepId);
  const [ended, setEnded] = useState(false);
  const [now, setNow]     = useState(0);
  const hostRef   = useRef(null);
  const playerRef = useRef(null);
  const selRef    = useRef(sel);
  const guardRef  = useRef(0);
  selRef.current = sel;

  // Create the player once
  useEffect(() => {
    let cancelled = false;
    const first = rangeOf(stepId);
    loadYT().then((YT) => {
      if (cancelled || !hostRef.current) return;
      const mount = document.createElement('div');
      hostRef.current.appendChild(mount);
      playerRef.current = new YT.Player(mount, {
        videoId: TUTORIAL_VIDEO_ID,
        width: '100%',
        height: '100%',
        playerVars: { playsinline: 1, rel: 0, modestbranding: 1, autoplay: 1, start: Math.floor(first.start) },
        events: {
          onReady: (e) => {
            guardRef.current = Date.now() + 900;
            try { e.target.seekTo(first.start, true); e.target.playVideo(); } catch (err) { /* ignore */ }
          },
          onStateChange: (e) => {
            if (e.data === 0) setEnded(true);
          },
        },
      });
    });
    return () => {
      cancelled = true;
      try { if (playerRef.current && playerRef.current.destroy) playerRef.current.destroy(); } catch (err) { /* ignore */ }
      playerRef.current = null;
    };
  }, []);

  // Watch the time: stop at the end of the chosen step
  useEffect(() => {
    const timer = setInterval(() => {
      const p = playerRef.current;
      if (!p || typeof p.getCurrentTime !== 'function') return;
      let t = 0;
      try { t = p.getCurrentTime() || 0; } catch (err) { return; }
      setNow(t);
      if (Date.now() < guardRef.current) return;
      const { start, end } = rangeOf(selRef.current);
      if (end != null && t >= end) {
        guardRef.current = Date.now() + 900;
        try { p.pauseVideo(); p.seekTo(start, true); } catch (err) { /* ignore */ }
        setEnded(true);
      }
    }, 250);
    return () => clearInterval(timer);
  }, []);

  // Close with Escape
  useEffect(() => {
    const onKey = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const choose = (id) => {
    setSel(id);
    setEnded(false);
    const r = rangeOf(id);
    guardRef.current = Date.now() + 900;
    const p = playerRef.current;
    if (p && typeof p.seekTo === 'function') {
      try { p.seekTo(r.start, true); p.playVideo(); } catch (err) { /* ignore */ }
    }
  };

  // Which step is showing right now
  let activeIdx = TUTORIAL_STEPS.findIndex(s => s.id === sel);
  if (sel === 'all') {
    activeIdx = TUTORIAL_STEPS.findIndex(s => now >= s.start && now < s.end);
  }
  const active = activeIdx >= 0 ? TUTORIAL_STEPS[activeIdx] : null;
  const nextStep = sel !== 'all' && activeIdx >= 0 ? TUTORIAL_STEPS[activeIdx + 1] : null;

  const chip = (id, label, isOn) => (
    <button key={id} onClick={() => choose(id)} style={{
      flexShrink: 0, border: `1.5px solid ${isOn ? 'var(--brand)' : 'var(--border)'}`,
      background: isOn ? 'var(--brand-glow)' : 'var(--bg-card)',
      color: isOn ? 'var(--brand)' : 'var(--text-2)',
      borderRadius: 999, padding: '7px 12px', fontSize: 12, fontWeight: 700,
      fontFamily: 'var(--font-display)', cursor: 'pointer', whiteSpace: 'nowrap',
    }}>{label}</button>
  );

  const body = (
    <div className="fade-in" onClick={onClose} style={{
      position: 'fixed', inset: 0, zIndex: 10000,
      background: 'rgba(6,14,30,0.94)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 16,
    }}>
      <div onClick={(e) => e.stopPropagation()} style={{ width: '100%', maxWidth: 360 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10, gap: 10 }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ fontSize: 10, fontWeight: 800, letterSpacing: 1.2, textTransform: 'uppercase', color: 'var(--brand)', fontFamily: 'var(--font-display)' }}>
              {active ? tr(`Step ${activeIdx + 1} of ${TUTORIAL_STEPS.length}`, `Step ${activeIdx + 1} / ${TUTORIAL_STEPS.length}`) : tr('Zentro Guide', 'Zentro Guide')}
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17, color: '#fff', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {active ? tr(active.en, active.title) : tr('Zentro in 1 minute', 'Zentro 1 minute mein')}
            </div>
          </div>
          <button onClick={onClose} aria-label="Close" style={{
            width: 36, height: 36, borderRadius: 10, flexShrink: 0,
            background: 'rgba(255,255,255,0.1)', border: 'none', cursor: 'pointer', color: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}><CloseIcon /></button>
        </div>

        {/* Video */}
        <div style={{
          position: 'relative', margin: '0 auto', background: '#000', borderRadius: 18, overflow: 'hidden',
          height: 'min(64vh, 560px)', aspectRatio: '9 / 16', maxWidth: '100%',
        }}>
          <div ref={hostRef} style={{ position: 'absolute', inset: 0 }} className="zt-frame" />
          {ended && (
            <div style={{
              position: 'absolute', inset: 0, background: 'rgba(6,14,30,0.82)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, padding: 20,
            }}>
              <button className="btn btn-primary" onClick={() => choose(sel)} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <ReplayIcon /> {tr('Watch again', 'Dobara dekho')}
              </button>
              {nextStep && (
                <button onClick={() => choose(nextStep.id)} style={{
                  background: 'rgba(255,255,255,0.12)', border: 'none', color: '#fff', cursor: 'pointer',
                  borderRadius: 12, padding: '11px 18px', fontSize: 13, fontWeight: 700, fontFamily: 'var(--font-display)',
                }}>{tr('Next step', 'Agla step')}: {tr(nextStep.en, nextStep.title)}</button>
              )}
            </div>
          )}
        </div>

        {/* Step chips */}
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', padding: '12px 0 4px' }}>
          {chip('all', tr('Full video', 'Poori video'), sel === 'all')}
          {TUTORIAL_STEPS.map((s, i) => chip(s.id, `${i + 1}. ${tr(s.en, s.title)}`, sel === s.id))}
        </div>

        <a href={TUTORIAL_URL} target="_blank" rel="noopener noreferrer" style={{
          display: 'block', textAlign: 'center', marginTop: 8, fontSize: 12, fontWeight: 600,
          color: 'var(--text-3)', fontFamily: 'var(--font-display)',
        }}>{tr('If the video does not play, open it on YouTube', 'Video na chale to YouTube par kholo')}</a>
      </div>
    </div>
  );

  return createPortal(body, document.body);
}

// ── Small "Watch this step" button ────────────────────────────────────────────
export function WatchStepButton({ stepId, label, compact = false, style }) {
  const { tr } = useLang();
  const [open, setOpen] = useState(false);
  return (
    <>
      <button onClick={() => setOpen(true)} style={{
        display: 'inline-flex', alignItems: 'center', gap: 7,
        background: 'var(--brand-glow)', border: '1px solid var(--border-brand)', color: 'var(--brand)',
        borderRadius: 10, padding: compact ? '7px 11px' : '9px 14px',
        fontSize: compact ? 12 : 13, fontWeight: 700, fontFamily: 'var(--font-display)', cursor: 'pointer',
        ...style,
      }}>
        <PlayIcon size={compact ? 11 : 12} /> {label || tr('Watch this step', 'Yeh step video mein dekho')}
      </button>
      {open && <TutorialModal stepId={stepId} onClose={() => setOpen(false)} />}
    </>
  );
}

// ── Card for the barber Home screen (new barbers) ─────────────────────────────
export function TutorialHomeCard() {
  const { tr } = useLang();
  const [hidden, setHidden] = useState(() => {
    try { return !!localStorage.getItem(HIDE_KEY); } catch (err) { return false; }
  });
  const [open, setOpen] = useState(false);

  if (hidden) return null;

  const hide = () => {
    try { localStorage.setItem(HIDE_KEY, '1'); } catch (err) { /* ignore */ }
    setHidden(true);
  };

  return (
    <>
      <div style={{
        background: 'var(--bg-card)', border: '1.5px solid var(--border-brand)', borderRadius: 18,
        padding: 16, marginBottom: 16, display: 'flex', alignItems: 'center', gap: 14,
      }}>
        <button onClick={() => setOpen(true)} aria-label="Watch the guide" style={{
          width: 52, height: 52, borderRadius: 16, flexShrink: 0, cursor: 'pointer',
          background: 'var(--brand)', border: 'none', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><PlayIcon size={20} /></button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, color: 'var(--text-1)' }}>{tr('Learn Zentro in 1 minute', '1 minute mein Zentro seekho')}</div>
          <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2, lineHeight: 1.4 }}>{tr('From shop setup to QR code, 6 steps', 'Shop setup se QR code tak, 6 steps')}</div>
        </div>
        <button onClick={hide} style={{
          background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)',
          fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)', flexShrink: 0, padding: 4,
        }}>{tr('Hide', 'Chhupao')}</button>
      </div>
      {open && <TutorialModal stepId="all" onClose={() => setOpen(false)} />}
    </>
  );
}

// ── Prompt right after a barber signs up ──────────────────────────────────────
export function TutorialPrompt({ onDone }) {
  const { tr } = useLang();
  const [open, setOpen] = useState(false);

  if (open) {
    return <TutorialModal stepId="all" onClose={onDone} />;
  }

  return (
    <div className="fade-in" style={{
      position: 'fixed', inset: 0, zIndex: 9999, background: 'rgba(6,14,30,0.96)',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      padding: '40px 28px',
    }}>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22, marginBottom: 36, letterSpacing: '-0.5px' }}>
        <span style={{ color: '#fff' }}>Zen</span><span style={{ color: 'var(--brand)' }}>tro</span>
      </div>
      <div className="pop-in" style={{
        width: '100%', maxWidth: 340, background: 'var(--bg-card)', border: '1.5px solid var(--border)',
        borderRadius: 24, padding: '30px 26px 24px', textAlign: 'center',
      }}>
        <div style={{
          width: 72, height: 72, borderRadius: 22, margin: '0 auto 20px', color: 'var(--brand)',
          background: 'var(--brand-glow)', border: '1.5px solid var(--border-brand)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><PlayIcon size={28} /></div>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: 'var(--text-1)', marginBottom: 10, letterSpacing: '-0.3px' }}>
          {tr('1 minute guide', '1 minute ki guide')}
        </h2>
        <p style={{ fontSize: 14, color: 'var(--text-2)', lineHeight: 1.6, fontFamily: 'var(--font-display)', fontWeight: 500, marginBottom: 24 }}>
          {tr('Shop setup, slots, plan, bookings and QR code. See everything in one short video.', 'Shop setup, slots, plan, bookings aur QR code. Sab kuch ek chhoti video mein dekho.')}
        </p>
        <button className="btn btn-primary" style={{ width: '100%', marginBottom: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }} onClick={() => setOpen(true)}>
          <PlayIcon size={13} /> {tr('Watch video', 'Video dekho')}
        </button>
        <button onClick={onDone} style={{
          background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-3)', fontSize: 13,
          fontFamily: 'var(--font-display)', fontWeight: 600, width: '100%', padding: '8px 0',
        }}>{tr('Later', 'Baad mein')}</button>
      </div>
    </div>
  );
}
