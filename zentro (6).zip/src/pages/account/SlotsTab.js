import { useCallback, useEffect, useState } from 'react';
import { format, addDays } from 'date-fns';
import { supabase } from '../../lib/supabase';
import useLang from '../../hooks/useLang';
import { Icon, SectionLabel } from './shared';

export default function SlotsTab({ user, showToast }) {
  const [shopId, setShopId]             = useState(null);
  const [loading, setLoading]           = useState(true);
  const [slots, setSlots]               = useState([]);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [generating, setGenerating]     = useState(false);
  const [genForm, setGenForm] = useState({ start: '09:00', end: '18:00', interval: 30, daysAhead: 7 });
  const { tr } = useLang();
  // Auto-renew: available only after zentro_auto_features.sql has been run
  const [auto, setAuto]             = useState({ avail: false, enabled: false });
  const [autoSaving, setAutoSaving] = useState(false);

  useEffect(() => { loadShop(); }, []); // eslint-disable-line
  useEffect(() => { if (shopId) loadSlots(); }, [shopId, selectedDate]); // eslint-disable-line

  const loadShop = async () => {
    const { data } = await supabase.from('shops').select('id').eq('owner_id', user.id).maybeSingle();
    if (data) { setShopId(data.id); loadAuto(data.id); }
    else showToast('error', tr('Set up your shop first', 'Pehle apni shop setup karo'));
    setLoading(false);
  };

  const loadAuto = async (id) => {
    const { data, error } = await supabase.from('slot_auto_settings').select('*').eq('shop_id', String(id)).maybeSingle();
    if (error) { setAuto({ avail: false, enabled: false }); return; }
    setAuto({ avail: true, enabled: !!data?.enabled });
    if (data && data.enabled) {
      setGenForm({
        start: String(data.start_time || '09:00').slice(0, 5),
        end: String(data.end_time || '18:00').slice(0, 5),
        interval: data.interval_minutes || 30,
        daysAhead: data.days_ahead || 7,
      });
    }
  };

  const saveAuto = async (enabled, quiet) => {
    if (!shopId) return;
    setAutoSaving(true);
    const { error } = await supabase.from('slot_auto_settings').upsert({
      shop_id: String(shopId), enabled,
      start_time: genForm.start, end_time: genForm.end,
      interval_minutes: genForm.interval, days_ahead: genForm.daysAhead,
      updated_at: new Date().toISOString(),
    }, { onConflict: 'shop_id' });
    setAutoSaving(false);
    if (error) { if (!quiet) showToast('error', error.message); return; }
    setAuto(a => ({ ...a, enabled }));
    if (!quiet) showToast('success', enabled ? tr('Slots will renew by themselves every day', 'Slots roz khud naye ban jayenge') : tr('Auto-renew is off', 'Auto-renew band hai'));
  };

  const loadSlots = useCallback(async () => {
    const { data } = await supabase.from('time_slots').select('*').eq('shop_id', shopId).eq('slot_date', selectedDate).order('start_time');
    setSlots(data || []);
  }, [shopId, selectedDate]);

  const generateSlots = async () => {
    if (!shopId) return;
    setGenerating(true);
    const dates = Array.from({ length: genForm.daysAhead }, (_, i) => format(addDays(new Date(), i), 'yyyy-MM-dd'));
    const toInsert = [];
    for (const date of dates) {
      const [sh, sm] = genForm.start.split(':').map(Number);
      const [eh, em] = genForm.end.split(':').map(Number);
      let cur = sh*60+sm, end = eh*60+em;
      while (cur+genForm.interval <= end) {
        const hh = String(Math.floor(cur/60)).padStart(2,'0'), mm = String(cur%60).padStart(2,'0');
        const nh = String(Math.floor((cur+genForm.interval)/60)).padStart(2,'0'), nm = String((cur+genForm.interval)%60).padStart(2,'0');
        toInsert.push({ shop_id: shopId, slot_date: date, start_time: `${hh}:${mm}:00`, end_time: `${nh}:${nm}:00`, is_booked: false });
        cur += genForm.interval;
      }
    }
    const { error } = await supabase.from('time_slots').upsert(toInsert, { onConflict: 'shop_id,slot_date,start_time', ignoreDuplicates: true });
    setGenerating(false);
    if (error) return showToast('error', error.message);
    showToast('success', tr(`Generated slots for ${genForm.daysAhead} days`, `${genForm.daysAhead} din ke slots ban gaye`));
    if (auto.enabled) saveAuto(true, true); // keep the saved auto-renew times in step
    loadSlots();
  };

  const deleteSlot = async (id) => {
    await supabase.from('time_slots').delete().eq('id', id);
    setSlots(prev => prev.filter(s => s.id !== id));
  };

  const deleteAllForDate = async () => {
    await supabase.from('time_slots').delete().eq('shop_id', shopId).eq('slot_date', selectedDate).eq('is_booked', false);
    showToast('success', tr('Cleared all free slots', 'Saare khali slots hata diye'));
    loadSlots();
  };

  const dates = Array.from({ length: 14 }, (_, i) => {
    const d = addDays(new Date(), i);
    return { value: format(d, 'yyyy-MM-dd'), label: format(d, 'EEE'), day: format(d, 'd') };
  });

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
        <SectionLabel>{tr('Generate Slots', 'Slots banao')}</SectionLabel>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 10 }}>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">{tr('Start', 'Shuru')}</label>
            <input className="input" type="time" value={genForm.start} onChange={e => setGenForm(p => ({ ...p, start: e.target.value }))} />
          </div>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">{tr('End', 'Khatam')}</label>
            <input className="input" type="time" value={genForm.end} onChange={e => setGenForm(p => ({ ...p, end: e.target.value }))} />
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">{tr('Interval', 'Wakfa')}</label>
            <select className="input" value={genForm.interval} onChange={e => setGenForm(p => ({ ...p, interval: parseInt(e.target.value) }))}>
              {[15, 20, 30, 45, 60].map(v => <option key={v} value={v}>{v} {tr('min', 'min')}</option>)}
            </select>
          </div>
          <div className="input-group" style={{ marginBottom: 0 }}>
            <label className="input-label">{tr('Days Ahead', 'Kitne din aage')}</label>
            <select className="input" value={genForm.daysAhead} onChange={e => setGenForm(p => ({ ...p, daysAhead: parseInt(e.target.value) }))}>
              {[1, 3, 7, 14, 30].map(v => <option key={v} value={v}>{v} {tr('days', 'din')}</option>)}
            </select>
          </div>
        </div>
        <button className="btn btn-primary" onClick={generateSlots} disabled={generating || !shopId}
          style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          {generating ? <span className="spinner spinner-sm" /> : <>{Icon.bolt()} {tr('Generate Slots', 'Slots banao')}</>}
        </button>

        {auto.avail && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--border)' }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700, fontFamily: 'var(--font-display)', color: 'var(--text-1)' }}>{tr('Renew slots automatically', 'Slots khud renew hon')}</div>
              <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2, lineHeight: 1.4 }}>
                {tr('Every night, new days are added with the times above, so your shop never runs out of slots.', 'Har raat in times ke saath naye din add hote hain, taake shop ke slots kabhi khatam na hon.')}
              </div>
            </div>
            <button role="switch" aria-checked={auto.enabled} disabled={autoSaving || !shopId} onClick={() => saveAuto(!auto.enabled)} style={{
              width: 48, height: 28, borderRadius: 14, border: 'none', cursor: 'pointer', flexShrink: 0, position: 'relative',
              background: auto.enabled ? 'var(--brand)' : 'var(--border)', transition: 'background 0.18s',
            }}>
              <span style={{ position: 'absolute', top: 3, left: auto.enabled ? 23 : 3, width: 22, height: 22, borderRadius: '50%', background: '#fff', transition: 'left 0.18s' }} />
            </button>
          </div>
        )}
      </div>

      <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: '18px 16px', border: '1px solid var(--border)' }}>
        <SectionLabel>{tr('Manage Slots', 'Slots manage karo')}</SectionLabel>
        <div style={{ display: 'flex', gap: 8, overflowX: 'auto', paddingBottom: 12, marginBottom: 14 }}>
          {dates.map(d => (
            <button key={d.value} onClick={() => setSelectedDate(d.value)} style={{
              flexShrink: 0, width: 48, padding: '8px 0', borderRadius: 12,
              border: `1.5px solid ${selectedDate === d.value ? 'var(--brand)' : 'var(--border)'}`,
              background: selectedDate === d.value ? 'var(--brand-glow)' : 'var(--bg-input)',
              color: selectedDate === d.value ? 'var(--brand)' : 'var(--text-2)',
              fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            }}>
              <span style={{ fontSize: 9, textTransform: 'uppercase' }}>{d.label}</span>
              <span style={{ fontSize: 16 }}>{d.day}</span>
            </button>
          ))}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <span style={{ fontSize: 12, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
            {slots.length} {tr('slots', 'slots')} · {selectedDate}
          </span>
          {slots.some(s => !s.is_booked) && (
            <button className="btn btn-danger btn-sm" onClick={deleteAllForDate}>{tr('Clear Free', 'Khali hatao')}</button>
          )}
        </div>

        {slots.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '20px 0', color: 'var(--text-3)', fontSize: 13, fontFamily: 'var(--font-display)' }}>
            {tr('No slots — generate above', 'Koi slot nahi — upar se banao')}
          </div>
        ) : (
          <div key={selectedDate} style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {slots.map((s, i) => (
              <div key={s.id} className="pop-in" style={{
                padding: '7px 12px', borderRadius: 10,
                border: `1.5px solid ${s.is_booked ? 'rgba(255,59,48,0.3)' : 'rgba(0,200,100,0.3)'}`,
                background: s.is_booked ? 'rgba(255,59,48,0.06)' : 'rgba(0,200,100,0.06)',
                display: 'flex', alignItems: 'center', gap: 7,
                animationDelay: `${Math.min(i * 0.02, 0.3)}s`,
              }}>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12,
                  color: s.is_booked ? 'var(--error)' : 'var(--success)' }}>
                  {s.start_time.slice(0, 5)}
                </span>
                {!s.is_booked && (
                  <button onClick={() => deleteSlot(s.id)} style={{ background: 'none', border: 'none',
                    color: 'var(--text-3)', cursor: 'pointer', padding: 0, display: 'flex', alignItems: 'center' }}>
                    {Icon.x('var(--text-3)')}
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ── Payment Tab ───────────────────────────────────────────────────────────────
