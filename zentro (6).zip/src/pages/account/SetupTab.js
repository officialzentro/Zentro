import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import useLang from '../../hooks/useLang';
import { uploadShopImage, deleteImage } from '../../lib/imageUpload';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import { createPortal } from 'react-dom';
import L from 'leaflet';
import { Icon, SectionLabel } from './shared';

function makeBrandPin() {
  return L.divIcon({
    className: '', iconSize: [36, 44], iconAnchor: [18, 44],
    html: `<svg width="36" height="44" viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M18 2C9.16 2 2 9.16 2 18c0 12 16 24 16 24S34 30 34 18C34 9.16 26.84 2 18 2z" fill="#0080FF"/>
      <circle cx="18" cy="18" r="8" fill="white" opacity="0.95"/>
    </svg>`,
  });
}
function LocationPickerMap({ position, onPick }) {
  useMapEvents({ click(e) { onPick([e.latlng.lat, e.latlng.lng]); } });
  return position ? <Marker position={position} icon={makeBrandPin()} /> : null;
}


// ── Collapsible section used on the Shop Setup page ─────────────
function SetupSection({ title, summary, done, open, onToggle, children }) {
  return (
    <div style={{ background: 'var(--bg-card)', borderRadius: 20, border: `1.5px solid ${open ? 'var(--brand)' : 'var(--border)'}`, overflow: 'hidden' }}>
      <button type="button" onClick={onToggle} style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 12, padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left' }}>
        <div style={{ width: 36, height: 36, borderRadius: 12, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
          background: done ? 'rgba(34,197,94,0.15)' : 'var(--brand-glow)', color: done ? 'var(--success, #22c55e)' : 'var(--brand)' }}>
          {done
            ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>
            : <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10" /></svg>}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-1)' }}>{title}</div>
          <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{summary}</div>
        </div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"
          style={{ flexShrink: 0, transform: open ? 'rotate(90deg)' : 'none', transition: 'transform 0.18s' }}><polyline points="9 6 15 12 9 18" /></svg>
      </button>
      {open && <div style={{ padding: '0 16px 18px' }}>{children}</div>}
    </div>
  );
}

// ── Setup Tab ─────────────────────────────────────────────────────────────────
export default function SetupTab({ user, showToast, perks }) {
  const [shopId, setShopId]       = useState(null);
  const [shopTier, setShopTier]   = useState('basic');
  const [loading, setLoading]     = useState(true);
  const [saving, setSaving]       = useState(false);
  const [uploadingImg, setUpImg]  = useState(false);
  const [services, setServices]   = useState([]);
  const [newSrv, setNewSrv]       = useState({ name: '', price: '', duration_minutes: 30 });
  const [showMap, setShowMap]     = useState(false);
  const [openSec, setOpenSec]   = useState(null);
  const { tr } = useLang();
  const [locating, setLocating]   = useState(false);
  const [showCoordInput, setShowCoordInput] = useState(false);
  const [coordInput, setCoordInput] = useState({ lat: '', lng: '' });
  const [form, setForm] = useState({ name: '', city: '', address: '', description: '', phone: '', images: [], lat: null, lng: null, gender_type: 'men', home_service: 'salon_only', home_fee: '' });

  useEffect(() => { loadExisting(); }, []); // eslint-disable-line

  const doneBasic  = !!(form.name.trim() && form.city.trim() && form.address.trim());
  const doneLoc    = !!(form.lat && form.lng);
  const doneSrv    = services.length > 0;
  const donePhotos = form.images.length > 0;
  const doneCount  = [doneBasic, doneLoc, doneSrv, donePhotos].filter(Boolean).length;

  // Open the first unfinished section once, after the shop has loaded
  useEffect(() => {
    if (loading || openSec !== null) return;
    setOpenSec(!doneBasic ? 'basic' : !doneLoc ? 'location' : !doneSrv ? 'services' : (shopId && !donePhotos) ? 'photos' : '');
  }, [loading]); // eslint-disable-line
  const toggleSec = (id) => setOpenSec(openSec === id ? '' : id);

  const loadExisting = async () => {
    const { data: s } = await supabase.from('shops').select('*').eq('owner_id', user.id).maybeSingle();
    if (s) {
      setShopId(s.id);
      setShopTier(s.subscription_tier || 'basic');
      setForm({ name: s.name||'', city: s.city||'', address: s.address||'', description: s.description||'', phone: s.phone||'', images: s.images||[], lat: s.lat||null, lng: s.lng||null, gender_type: s.gender_type||'men', home_service: s.home_service||'salon_only', home_fee: s.home_fee ? String(s.home_fee) : '' });
      const { data: srv } = await supabase.from('services').select('*').eq('shop_id', s.id);
      setServices(srv || []);
    }
    setLoading(false);
  };

  const detectLocation = () => {
    if (!navigator.geolocation) return showToast('error', 'Geolocation not supported');
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setForm(p => ({ ...p, lat: pos.coords.latitude, lng: pos.coords.longitude }));
        setLocating(false);
        showToast('success', 'Location detected!');
      },
      () => { setLocating(false); showToast('error', 'Could not detect location'); },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const uploadImage = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (!shopId) return showToast('error', 'Save shop details first');

    // Re-fetch the live plan config at upload time — catches any admin change
    // made mid-session instead of trusting the perks loaded when the page opened.
    let maxPhotos = perks?.photos ?? 3;
    try {
      const { data: freshCfg } = await supabase
        .from('app_settings').select('value').eq('key', 'plans_config').maybeSingle();
      if (freshCfg?.value) {
        const parsed = JSON.parse(freshCfg.value);
        const tier = shopTier || 'basic';
        if (parsed[tier]?.photos != null) maxPhotos = parsed[tier].photos;
      }
    } catch {}

    if (form.images.length >= maxPhotos) return showToast('error', `Your plan allows max ${maxPhotos} photos`);
    setUpImg(true);
    try {
      const url = await uploadShopImage(file, shopId);
      const newImages = [...form.images, url];
      setForm(p => ({ ...p, images: newImages }));
      await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
      showToast('success', 'Image uploaded');
    } catch (err) { showToast('error', 'Upload failed: ' + err.message); }
    setUpImg(false);
  };

  const removeImage = async (url) => {
    const newImages = form.images.filter(i => i !== url);
    setForm(p => ({ ...p, images: newImages }));
    await supabase.from('shops').update({ images: newImages }).eq('id', shopId);
    await deleteImage(url);
    showToast('success', 'Image removed');
  };

  const save = async () => {
    if (!form.name || !form.city || !form.address) return showToast('error', 'Name, city and address required');
    setSaving(true);
    if (shopId) {
      // Only update content fields — never overwrite tier/status/approval
      const { error } = await supabase.from('shops').update({
        name: form.name, city: form.city, address: form.address,
        description: form.description, phone: form.phone,
        lat: form.lat, lng: form.lng,
        gender_type: form.gender_type,
        home_service: form.home_service,
        home_fee: form.home_fee ? parseFloat(form.home_fee) : null,
      }).eq('id', shopId);
      if (error) { setSaving(false); return showToast('error', error.message); }
      showToast('success', 'Shop updated!');
    } else {
      const { data, error } = await supabase.from('shops').insert({
        owner_id: user.id, name: form.name, city: form.city, address: form.address,
        description: form.description, phone: form.phone,
        lat: form.lat, lng: form.lng,
        gender_type: form.gender_type,
        home_service: form.home_service,
        home_fee: form.home_fee ? parseFloat(form.home_fee) : null,
        images: [], is_active: false, subscription_status: 'pending', subscription_tier: 'basic',
      }).select().maybeSingle();
      if (error) { setSaving(false); return showToast('error', error.message); }
      if (data) setShopId(data.id);
      showToast('success', 'Shop created! Awaiting admin approval.');
    }
    setSaving(false);
  };

  const addService = async () => {
    if (!shopId) return showToast('error', 'Save shop details first');
    if (!newSrv.name || !newSrv.price) return showToast('error', 'Name and price required');
    const { data, error } = await supabase.from('services')
      .insert({ ...newSrv, shop_id: shopId, price: parseFloat(newSrv.price), is_active: true })
      .select().maybeSingle();
    if (error) return showToast('error', error.message);
    if (data) setServices(prev => [...prev, data]);
    setNewSrv({ name: '', price: '', duration_minutes: 30 });
    showToast('success', 'Service added');
  };

  const removeService = async (id) => {
    await supabase.from('services').delete().eq('id', id);
    setServices(prev => prev.filter(s => s.id !== id));
    showToast('success', 'Service removed');
  };

  if (loading) return <div style={{ textAlign: 'center', padding: 40 }}><div className="spinner" style={{ margin: '0 auto' }} /></div>;

  const mapCenter = form.lat && form.lng ? [form.lat, form.lng] : [30.3753, 69.3451];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* Full-screen map picker portal */}
      {showMap && createPortal(
        <div style={{ position: 'fixed', inset: 0, zIndex: 3000, background: 'var(--bg)', display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 20px', background: 'var(--bg-nav)', borderBottom: '1px solid var(--border)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <button onClick={() => setShowMap(false)} style={{ background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 10, width: 36, height: 36, cursor: 'pointer', fontSize: 18, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--text-1)' }}>←</button>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>Pin Your Shop</span>
            </div>
            <button onClick={() => setShowMap(false)} style={{ background: 'linear-gradient(135deg, var(--brand), var(--brand-2))', color: '#fff', border: 'none', borderRadius: 12, padding: '8px 20px', cursor: 'pointer', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>Done</button>
          </div>
          <div style={{ padding: '10px 20px', background: 'var(--brand-glow)', borderBottom: '1px solid var(--border-brand)', fontSize: 13, color: 'var(--brand)', fontFamily: 'var(--font-display)', fontWeight: 600, textAlign: 'center' }}>
            Tap anywhere on the map to drop a pin
          </div>
          <div style={{ flex: 1, position: 'relative' }}>
            <MapContainer center={mapCenter} zoom={form.lat ? 15 : 6} style={{ width: '100%', height: '100%' }} zoomControl attributionControl={false}>
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              <LocationPickerMap
                position={form.lat && form.lng ? [form.lat, form.lng] : null}
                onPick={([lat, lng]) => setForm(p => ({ ...p, lat, lng }))}
              />
            </MapContainer>
            <button onClick={detectLocation} disabled={locating} style={{ position: 'absolute', bottom: 20, right: 16, zIndex: 999, background: '#fff', border: '1.5px solid var(--border-brand)', borderRadius: 14, padding: '10px 16px', display: 'flex', alignItems: 'center', gap: 8, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: 'var(--brand)', cursor: 'pointer', boxShadow: 'var(--shadow-md)' }}>
              {locating ? <span className="spinner spinner-sm" /> : <svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'><path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/></svg>} Use My GPS
            </button>
          </div>
          {form.lat && form.lng && (
            <div style={{ padding: '12px 20px', background: 'var(--bg-card)', borderTop: '1px solid var(--border)', fontSize: 12, color: 'var(--text-2)', fontFamily: 'var(--font-display)', textAlign: 'center' }}>
              <svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round' style={{display:'inline',verticalAlign:'middle',marginRight:4}}><path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/></svg> {form.lat.toFixed(6)}, {form.lng.toFixed(6)} — saved
            </div>
          )}
        </div>
      , document.body)}

      {/* Progress */}
      <div style={{ background: 'var(--bg-card)', borderRadius: 20, padding: 16, border: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-1)' }}>{tr(`${doneCount} of 4 complete`, `4 mein se ${doneCount} pura`)}</div>
          <div style={{ fontSize: 12, color: 'var(--text-3)' }}>{doneCount === 4 ? tr('All set', 'Sab tayyar hai') : tr('Open a section and finish it', 'Section kholo aur pura karo')}</div>
        </div>
        <div style={{ height: 8, borderRadius: 4, background: 'var(--border)', marginTop: 10 }}>
          <div style={{ width: `${doneCount * 25}%`, height: 8, borderRadius: 4, background: 'var(--brand)', transition: 'width 0.3s' }} />
        </div>
      </div>

      <SetupSection title={tr('Shop basics', 'Shop ki basic info')} done={doneBasic} open={openSec === 'basic'} onToggle={() => toggleSec('basic')}
        summary={doneBasic ? `${form.name} | ${form.city}` : tr('Name, city and address', 'Name, city aur address')}>
        {[
          { label: tr('Shop Name *', 'Shop ka naam *'), key: 'name', placeholder: 'e.g. Cuts & Glory' },
          { label: tr('City *', 'Shehar *'),      key: 'city', placeholder: 'e.g. Lahore' },
          { label: tr('Address *', 'Address *'),   key: 'address', placeholder: 'Full address' },
          { label: tr('Phone', 'Phone'),       key: 'phone', placeholder: '+92 300 0000000' },
        ].map(f => (
          <div key={f.key} className="input-group">
            <label className="input-label">{f.label}</label>
            <input className="input" placeholder={f.placeholder} value={form[f.key]}
              onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} />
          </div>
        ))}
        <div className="input-group">
          <label className="input-label">{tr('Description', 'Tafseel')}</label>
          <textarea className="input" placeholder="Tell customers about your shop..."
            value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} />
        </div>

        {/* ── Gender Type ── */}
        <div className="input-group">
          <label className="input-label">{tr('Serves', 'Kis ke liye')}</label>
          <div style={{ display: 'flex', gap: 10 }}>
            {[
              { val: 'men', label: tr('Men', 'Mard'), icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="10" cy="14" r="6"/><line x1="14.5" y1="9.5" x2="20" y2="4"/><polyline points="16 4 20 4 20 8"/></svg> },
              { val: 'women', label: tr('Women', 'Aurtein'), icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="8" r="6"/><line x1="12" y1="14" x2="12" y2="20"/><line x1="9" y1="17" x2="15" y2="17"/></svg> },
              { val: 'both', label: tr('Both', 'Dono'), icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="8" cy="14" r="4"/><circle cx="16" cy="8" r="4"/><line x1="8" y1="18" x2="8" y2="22"/><line x1="6" y1="20" x2="10" y2="20"/><line x1="19.2" y1="4.8" x2="22" y2="2"/><polyline points="20 2 22 2 22 4"/></svg> },
            ].map(({ val, label, icon }) => (
              <button key={val} type="button" onClick={() => setForm(p => ({ ...p, gender_type: val }))} style={{
                flex: 1, padding: '12px 8px', borderRadius: 12, cursor: 'pointer',
                border: `2px solid ${form.gender_type === val ? 'var(--brand)' : 'var(--border)'}`,
                background: form.gender_type === val ? 'var(--brand-glow2)' : 'var(--bg-input)',
                color: form.gender_type === val ? 'var(--brand)' : 'var(--text-2)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, transition: 'all 0.18s',
              }}>
                {icon}
                <span style={{ fontSize: 12, fontWeight: 700 }}>{label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* ── Home Service ── */}
        <div className="input-group">
          <label className="input-label">{tr('Service Location', 'Service ki jagah')}</label>
          <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
            {[
              { val: 'salon_only', label: tr('Salon Only', 'Sirf salon'), icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg> },
              { val: 'home_only', label: tr('Home Only', 'Sirf ghar par'), icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg> },
              { val: 'both', label: tr('Both', 'Dono'), icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="18" cy="18" r="4"/><line x1="18" y1="16" x2="18" y2="18"/><line x1="16" y1="18" x2="20" y2="18"/></svg> },
            ].map(({ val, label, icon }) => (
              <button key={val} type="button" onClick={() => setForm(p => ({ ...p, home_service: val }))} style={{
                flex: 1, padding: '12px 8px', borderRadius: 12, cursor: 'pointer',
                border: `2px solid ${form.home_service === val ? 'var(--brand)' : 'var(--border)'}`,
                background: form.home_service === val ? 'var(--brand-glow2)' : 'var(--bg-input)',
                color: form.home_service === val ? 'var(--brand)' : 'var(--text-2)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, transition: 'all 0.18s',
              }}>
                {icon}
                <span style={{ fontSize: 12, fontWeight: 700 }}>{label}</span>
              </button>
            ))}
          </div>
          {(form.home_service === 'home_only' || form.home_service === 'both') && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontSize: 13, color: 'var(--text-2)', whiteSpace: 'nowrap' }}>{tr('Extra home visit fee (Rs)', 'Ghar par aane ki extra fee (Rs)')}</span>
              <input className="input" type="number" placeholder="e.g. 200" style={{ flex: 1, marginBottom: 0 }}
                value={form.home_fee} onChange={e => setForm(p => ({ ...p, home_fee: e.target.value }))} />
            </div>
          )}
        </div>
      </SetupSection>

      <SetupSection title={tr('Location on map', 'Map par location')} done={doneLoc} open={openSec === 'location'} onToggle={() => toggleSec('location')}
        summary={doneLoc ? tr('Pin is set', 'Pin laga hua hai') : tr('Pin your shop on the map', 'Map par pin lagao')}>
        <div className="input-group">
          <label className="input-label">{tr('Shop Location on Map', 'Shop ki location map par')}</label>
          {/* Status */}
          <div style={{ background: 'var(--bg-input)', border: '1.5px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '12px 14px', marginBottom: 10 }}>
            {form.lat && form.lng ? (
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--brand)', fontFamily: 'var(--font-display)', marginBottom: 2, display:'flex', alignItems:'center', gap:5 }}><svg width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round'><path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z'/><circle cx='12' cy='10' r='3'/></svg> Location set</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{form.lat.toFixed(6)}, {form.lng.toFixed(6)}</div>
                </div>
                <button onClick={() => { setForm(p => ({ ...p, lat: null, lng: null })); setShowCoordInput(false); }}
                  style={{ background: 'none', border: '1px solid var(--border)', borderRadius: 8, padding: '5px 10px', cursor: 'pointer', fontSize: 12, color: 'var(--error)', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
                  Clear
                </button>
              </div>
            ) : (
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--warning, #f59e0b)', fontFamily: 'var(--font-display)' }}>
                <svg width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='currentColor' strokeWidth='2' strokeLinecap='round' strokeLinejoin='round' style={{display:'inline',verticalAlign:'middle',marginRight:6}}><path d='M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'/><line x1='12' y1='9' x2='12' y2='13'/><line x1='12' y1='17' x2='12.01' y2='17'/></svg> No pin set — use an option below
              </div>
            )}
          </div>
          {/* 3 options */}
          <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
            <button onClick={() => { setShowMap(true); setShowCoordInput(false); }}
              style={{ flex: 1, padding: '10px 4px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--border-brand)', background: 'var(--brand-dim)', color: 'var(--brand)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 11, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/></svg>
              Pin on Map
            </button>
            <button onClick={() => { setShowCoordInput(v => !v); setCoordInput({ lat: form.lat || '', lng: form.lng || '' }); }}
              style={{ flex: 1, padding: '10px 4px', borderRadius: 'var(--radius-sm)', border: `1.5px solid ${showCoordInput ? 'var(--brand)' : 'var(--border)'}`, background: showCoordInput ? 'var(--brand-dim)' : 'var(--bg-input)', color: showCoordInput ? 'var(--brand)' : 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 11, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="6"/><line x1="12" y1="18" x2="12" y2="22"/><line x1="2" y1="12" x2="6" y2="12"/><line x1="18" y1="12" x2="22" y2="12"/></svg>
              Coordinates
            </button>
            <button onClick={detectLocation} disabled={locating}
              style={{ flex: 1, padding: '10px 4px', borderRadius: 'var(--radius-sm)', border: '1.5px solid var(--border)', background: 'var(--bg-input)', color: 'var(--text-2)', fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 11, cursor: 'pointer', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 5 }}>
              {locating ? <span className="spinner spinner-sm" /> : (
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="5"/><line x1="12" y1="19" x2="12" y2="22"/><line x1="2" y1="12" x2="5" y2="12"/><line x1="19" y1="12" x2="22" y2="12"/></svg>
              )}
              Use GPS
            </button>
          </div>
          {/* Coord input panel */}
          {showCoordInput && (
            <div style={{ background: 'var(--bg-card)', border: '1.5px solid var(--border-brand)', borderRadius: 'var(--radius-sm)', padding: '14px', marginBottom: 10 }}>
              <p style={{ fontSize: 12, color: 'var(--text-2)', fontFamily: 'var(--font-display)', marginBottom: 10 }}>
                Open Google Maps → long press your shop → copy the numbers shown
              </p>
              <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
                <div style={{ flex: 1 }}>
                  <label style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, display: 'block', marginBottom: 4 }}>LATITUDE</label>
                  <input className="input" placeholder="e.g. 31.5204" type="number" step="any"
                    value={coordInput.lat} onChange={e => setCoordInput(p => ({ ...p, lat: e.target.value }))} />
                </div>
                <div style={{ flex: 1 }}>
                  <label style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, display: 'block', marginBottom: 4 }}>LONGITUDE</label>
                  <input className="input" placeholder="e.g. 74.3587" type="number" step="any"
                    value={coordInput.lng} onChange={e => setCoordInput(p => ({ ...p, lng: e.target.value }))} />
                </div>
              </div>
              <button onClick={() => {
                const lat = parseFloat(coordInput.lat);
                const lng = parseFloat(coordInput.lng);
                if (isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180)
                  return showToast('error', 'Invalid coordinates');
                setForm(p => ({ ...p, lat, lng }));
                setShowCoordInput(false);
                showToast('success', 'Coordinates set!');
              }} className="btn btn-primary" style={{ padding: '10px 0' }}>
                Apply Coordinates
              </button>
            </div>
          )}
          <p style={{ fontSize: 11, color: 'var(--text-3)' }}>{tr('Pinning your shop lets customers find you on the map', 'Pin lagane se customers aapko map par dhoond sakte hain')}</p>
        </div>

      </SetupSection>

      <SetupSection title={tr('Services', 'Services')} done={doneSrv} open={openSec === 'services'} onToggle={() => toggleSec('services')}
        summary={doneSrv ? `${services.length} ${tr(services.length === 1 ? 'service' : 'services', 'services')}` : tr('Add your services', 'Services add karo')}>
        {services.length > 0 && (
          <div style={{ marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 2 }}>
            {services.map(s => (
              <div key={s.id} className="pop-in" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
                <div>
                  <div style={{ fontWeight: 700, fontFamily: 'var(--font-display)', fontSize: 13, color: 'var(--text-1)' }}>{s.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 2 }}>Rs {s.price} · {s.duration_minutes} min</div>
                </div>
                <button onClick={() => removeService(s.id)} style={{
                  background: 'var(--bg-input)', border: '1px solid var(--border)', borderRadius: 8,
                  padding: '6px 10px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4,
                  fontSize: 12, color: 'var(--error)', fontFamily: 'var(--font-display)', fontWeight: 700,
                }}>
                  {Icon.trash()} {tr('Remove', 'Hatao')}
                </button>
              </div>
            ))}
          </div>
        )}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <div style={{ display: 'flex', gap: 10 }}>
            <input className="input" placeholder={tr('Service name', 'Service ka naam')} style={{ flex: 2 }}
              value={newSrv.name} onChange={e => setNewSrv(p => ({ ...p, name: e.target.value }))} />
            <input className="input" placeholder={tr('Price', 'Qeemat')} type="number" style={{ flex: 1 }}
              value={newSrv.price} onChange={e => setNewSrv(p => ({ ...p, price: e.target.value }))} />
          </div>
          <select className="input" value={newSrv.duration_minutes}
            onChange={e => setNewSrv(p => ({ ...p, duration_minutes: parseInt(e.target.value) }))}>
            {[15, 20, 30, 45, 60, 90].map(d => <option key={d} value={d}>{d} {tr('minutes', 'minute')}</option>)}
          </select>
          <button className="btn btn-secondary" onClick={addService}>+ {tr('Add Service', 'Service add karo')}</button>
        </div>
      </SetupSection>

      {shopId && (
        <SetupSection title={tr('Photos', 'Photos')} done={donePhotos} open={openSec === 'photos'} onToggle={() => toggleSec('photos')}
          summary={tr(`${form.images.length} of ${perks?.photos ?? 3} photos`, `${perks?.photos ?? 3} mein se ${form.images.length} photos`)}>
          <div className="input-group">
            <label className="input-label">
              Shop Photos ({form.images.length}/{perks?.photos ?? 3})
              {perks?.photos != null && (
                <span style={{ marginLeft: 8, fontSize: 10, color: 'var(--brand)', fontWeight: 700,
                  background: 'var(--brand-glow)', padding: '2px 8px', borderRadius: 100 }}>
                  Plan limit
                </span>
              )}
            </label>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginBottom: 4 }}>
              {form.images.map(url => (
                <div key={url} className="pop-in" style={{ position: 'relative', width: 76, height: 76 }}>
                  <img src={url} alt="" style={{ width: 76, height: 76, objectFit: 'cover', borderRadius: 12 }} />
                  <button onClick={() => removeImage(url)} style={{
                    position: 'absolute', top: -5, right: -5, width: 20, height: 20, borderRadius: '50%',
                    background: 'var(--error)', color: '#fff', border: 'none', cursor: 'pointer',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>{Icon.x()}</button>
                </div>
              ))}
              {form.images.length < (perks?.photos ?? 3) ? (
                <label style={{ width: 76, height: 76, borderRadius: 12, border: '2px dashed var(--border)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
                  color: 'var(--text-3)', background: 'var(--bg-input)' }}>
                  {uploadingImg ? <span className="spinner spinner-sm" /> : <span style={{ fontSize: 22, lineHeight: 1 }}>+</span>}
                  <input type="file" accept="image/*" style={{ display: 'none' }} onChange={uploadImage} disabled={uploadingImg} />
                </label>
              ) : (
                <div style={{ width: 76, height: 76, borderRadius: 12, border: '1.5px dashed var(--border)',
                  display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
                  background: 'var(--bg-input)', gap: 4 }}>
                  <span style={{ fontSize: 11, color: 'var(--text-3)', fontFamily: 'var(--font-display)', fontWeight: 700, textAlign: 'center', lineHeight: 1.3 }}>
                    Limit<br/>reached
                  </span>
                </div>
              )}
            </div>
            {form.images.length >= (perks?.photos ?? 3) && (
              <p style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 4 }}>
                Upgrade your plan to add more photos
              </p>
            )}
          </div>
        </SetupSection>
      )}

      <div style={{ position: 'sticky', bottom: 0, zIndex: 5, padding: '10px 0 6px', background: 'linear-gradient(to top, var(--bg) 70%, transparent)' }}>
        <button className="btn btn-primary" onClick={save} disabled={saving}>
          {saving ? <span className="spinner spinner-sm" /> : shopId ? tr('Update Shop', 'Shop update karo') : tr('Create Shop', 'Shop banao')}
        </button>
      </div>
    </div>
  );
}

// ── Slots Tab ─────────────────────────────────────────────────────────────────
