import { createContext, useContext, useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';
import { initPush, logoutPush } from '../lib/push';

const AuthCtx = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser]         = useState(null);
  const [profile, setProfile]   = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [profileReady, setProfileReady] = useState(false);
  const resolvedRef = useRef(false);

  const resolve = () => {
    if (!resolvedRef.current) {
      resolvedRef.current = true;
      setAuthReady(true);
    }
  };

  const fetchProfile = async (uid) => {
    try {
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', uid)
        .maybeSingle();
      setProfile(data || null);
    } catch {
      setProfile(null);
    } finally {
      setProfileReady(true);
      resolve();
    }
  };

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      const u = session?.user ?? null;
      setUser(u);
      if (u) {
        fetchProfile(u.id);
      } else {
        resolve();
      }
    }).catch(() => resolve());

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      const u = session?.user ?? null;
      setUser(u);
      resolvedRef.current = false; // allow re-resolve
      if (u) {
        setProfileReady(false);
        fetchProfile(u.id);
      } else {
        setProfile(null);
        resolve();
      }
    });

    return () => subscription.unsubscribe();
  }, []); // eslint-disable-line

  useEffect(() => { if (user?.id) initPush(user.id); }, [user?.id]);

  const signOut = async () => {
    logoutPush();
    await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
  };

  const refreshProfile = () => user && fetchProfile(user.id);

  return (
    <AuthCtx.Provider value={{ user, profile, authReady, profileReady, signOut, refreshProfile }}>
      {children}
    </AuthCtx.Provider>
  );
}

export const useAuth = () => useContext(AuthCtx);
