import { useEffect, useState } from 'react';

// ── Shared language store ──────────────────────────────────────────────────────
// One language for the whole app ('en' or 'ur' = Roman Urdu).
// Every screen that calls useLang() updates together the moment someone taps the toggle,
// and the choice is remembered after the app is closed.
//
// Usage:
//   const { lang, tr, LangToggleBtn } = useLang();
//   tr('Bookings', 'Bookings')   // English first, Roman Urdu second

const KEY = 'zentro_lang';
const listeners = new Set();

function readSaved() {
  try { return localStorage.getItem(KEY) === 'ur' ? 'ur' : 'en'; } catch (e) { return 'en'; }
}

let current = readSaved();

function setCurrent(next) {
  if (next === current) return;
  current = next;
  try { localStorage.setItem(KEY, next); } catch (e) { /* ignore */ }
  listeners.forEach(fn => fn(next));
}

// Keep several open tabs in step
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === KEY) {
      const next = e.newValue === 'ur' ? 'ur' : 'en';
      if (next !== current) { current = next; listeners.forEach(fn => fn(next)); }
    }
  });
}

export function getLang() { return current; }

export function LangToggleBtn({ style = {} }) {
  const { lang, toggleLang } = useLang();
  return (
    <button
      onClick={toggleLang}
      aria-label={lang === 'en' ? 'Switch to Roman Urdu' : 'Switch to English'}
      title={lang === 'en' ? 'Roman Urdu mein switch karo' : 'Switch to English'}
      style={{
        background: 'var(--bg-card)', border: '1px solid var(--border)',
        borderRadius: '50%', width: 36, height: 36,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer', flexShrink: 0, ...style,
      }}
    >
      {lang === 'en' ? (
        // Show Urdu chars when in English mode (tap to go Urdu)
        <svg width="20" height="20" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
          <text x="2" y="20" fontFamily="serif" fontSize="18" fill="var(--text-2)" fontWeight="bold">ا</text>
          <text x="14" y="20" fontFamily="serif" fontSize="11" fill="var(--brand)" fontWeight="bold">ر</text>
        </svg>
      ) : (
        // Show EN when in Urdu mode (tap to go English)
        <svg width="20" height="20" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
          <text x="1" y="19" fontFamily="sans-serif" fontSize="13" fill="var(--text-2)" fontWeight="bold">EN</text>
        </svg>
      )}
    </button>
  );
}

export default function useLang() {
  const [lang, setLang] = useState(current);

  useEffect(() => {
    listeners.add(setLang);
    if (current !== lang) setLang(current); // missed a change between render and subscribe
    return () => { listeners.delete(setLang); };
  }, []);

  const toggleLang = () => setCurrent(current === 'en' ? 'ur' : 'en');
  const tr = (en, ur) => (lang === 'ur' ? ur : en);

  return { lang, toggleLang, tr, LangToggleBtn };
}
