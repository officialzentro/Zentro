import { useEffect, useRef } from 'react';

// Calls `callback` every `interval` ms while the app is open and visible,
// and once more when the person comes back to the app (tab, phone unlock, internet back).
// It never runs while the page is hidden or offline, so it saves battery and data.
export default function useAutoRefresh(callback, interval = 30000, enabled = true) {
  const ref = useRef(callback);
  ref.current = callback;

  useEffect(() => {
    if (!enabled) return undefined;
    let last = Date.now();

    const run = () => {
      if (document.visibilityState !== 'visible') return;
      if (typeof navigator !== 'undefined' && navigator.onLine === false) return;
      last = Date.now();
      try {
        const r = ref.current();
        if (r && typeof r.catch === 'function') r.catch(() => {});
      } catch (e) { /* ignore */ }
    };

    const timer = setInterval(run, interval);
    const onWake = () => { if (Date.now() - last > 5000) run(); };

    document.addEventListener('visibilitychange', onWake);
    window.addEventListener('focus', onWake);
    window.addEventListener('online', onWake);
    return () => {
      clearInterval(timer);
      document.removeEventListener('visibilitychange', onWake);
      window.removeEventListener('focus', onWake);
      window.removeEventListener('online', onWake);
    };
  }, [interval, enabled]);
}
