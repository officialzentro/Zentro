import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';

export default function AuthCallback() {
  const navigate = useNavigate();
  const [stage, setStage]   = useState('checking'); // checking | needsInfo | saving
  const [userId, setUserId] = useState(null);
  const [form, setForm]     = useState({ full_name: '', phone: '' });
  const [error, setError]   = useState('');

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return navigate('/login', { replace: true });

      const { data: prof } = await supabase
        .from('profiles')
        .select('id, full_name, phone')
        .eq('id', session.user.id)
        .maybeSingle();

      if (prof) return navigate('/', { replace: true }); // existing user, straight in

      // New Google sign-in — no profile yet. Pre-fill name from Google, ask to confirm/complete.
      const meta = session.user.user_metadata || {};
      setUserId(session.user.id);
      setForm({ full_name: meta.full_name || meta.name || '', phone: '' });
      setStage('needsInfo');
    })();
  }, []); // eslint-disable-line

  const finishSetup = async () => {
    if (!form.full_name.trim()) return setError('Please enter your name');
    setStage('saving');
    const { data: { session } } = await supabase.auth.getSession();
    await supabase.from('profiles').insert({
      id: userId,
      full_name: form.full_name.trim(),
      phone: form.phone.trim(),
      email: session?.user?.email,
      role: 'customer',
    });
    navigate('/', { replace: true });
  };

  if (stage === 'checking' || stage === 'saving') {
    return <div className="loading-screen"><div className="spinner" /></div>;
  }

  return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px', maxWidth: 480, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 28, marginBottom: 8 }}>
          Almost there
        </div>
        <p style={{ color: 'var(--text-2)', fontSize: 14 }}>Confirm your details to finish setting up your account.</p>
      </div>

      <div className="input-group">
        <label className="input-label">Full Name</label>
        <input className="input" value={form.full_name}
          onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} />
      </div>
      <div className="input-group">
        <label className="input-label">Phone (optional)</label>
        <input className="input" type="tel" placeholder="03xxxxxxxxx" value={form.phone}
          onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} />
      </div>

      {error && <p style={{ color: 'var(--error)', fontSize: 13, marginBottom: 12 }}>{error}</p>}

      <button className="btn btn-primary" onClick={finishSetup} style={{ marginTop: 8 }}>
        Continue
      </button>
    </div>
  );
}
