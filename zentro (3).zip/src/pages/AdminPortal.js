import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { MapPin, User, CreditCard, Calendar, Store, Lock, Scissors, TrendingUp, Smartphone, Check, X, AlertTriangle, DollarSign, Users, Package, Gear, Save, Timer, Tag, Paperclip, Target, Medal, Crown, Bell, RefreshCw } from '../lib/icons';
import { SOCIAL_PLATFORMS, invalidateSocialCache } from '../components/SocialBar';
import { sendNotification } from '../lib/referrals';

// ── Default plans (stored in app_settings as JSON) ───────────────────────────
const DEFAULT_PLANS = {
  basic:   { name: 'Basic',   price: 999,  color: '#8EA0BC', photos: 3,  qr: false, badge: false, priority: false },
  pro:     { name: 'Pro',     price: 2499, color: '#FF5C1A', photos: 10, qr: true,  badge: false, priority: true  },
  premium: { name: 'Premium', price: 4999, color: '#FFB800', photos: 30, qr: true,  badge: true,  priority: true  },
};

// ── Admin Login — real Supabase Auth, gated by profiles.role === 'admin' ────
function AdminLogin({ onAuthed }) {
  const [email, setEmail]     = useState('');
  const [pass, setPass]       = useState('');
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const login = async () => {
    if (!email.trim() || !pass) return;
    setLoading(true); setError('');
    const { data, error: authErr } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pass });
    if (authErr || !data?.user) {
      setError('Invalid email or password');
      setLoading(false);
      return;
    }
    const { data: prof } = await supabase.from('profiles').select('role').eq('id', data.user.id).maybeSingle();
    if (prof?.role !== 'admin') {
      setError('This account does not have admin access');
      await supabase.auth.signOut();
      setLoading(false);
      return;
    }
    setLoading(false);
    onAuthed();
  };

  return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px' }}>
      <div style={{ textAlign: 'center', marginBottom: 36 }}>
        <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 10 }}>
          <svg width="44" height="44" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
        </div>
        <h1 style={{ fontSize: 26, marginBottom: 4 }}>Admin Portal</h1>
        <p style={{ color: 'var(--text-2)', fontSize: 14 }}>Zentro</p>
      </div>

      <div className="input-group">
        <label className="input-label">Email</label>
        <input className="input" type="email" placeholder="admin@zentropk.com"
          value={email} onChange={e => setEmail(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && login()} />
      </div>
      <div className="input-group">
        <label className="input-label">Password</label>
        <input className="input" type="password" placeholder="••••••••"
          value={pass} onChange={e => setPass(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && login()} />
      </div>
      {error && <p style={{ color: 'var(--error)', fontSize: 13, marginBottom: 12 }}>{error}</p>}
      <button className="btn btn-primary" onClick={login} disabled={loading}>
        {loading ? <span className="spinner spinner-sm" /> : 'Log In'}
      </button>
    </div>
  );
}

// ── Main Admin Portal ─────────────────────────────────────────────────────────
export default function AdminPortal() {
  const [authed, setAuthed]     = useState(false);
  const [checkingSession, setCheckingSession] = useState(true);
  const [tab, setTab]           = useState('shops');
  const [shops, setShops]       = useState([]);
  const [payments, setPayments] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [users, setUsers]       = useState([]);
  const [plans, setPlans]       = useState(DEFAULT_PLANS);
  const [fetched, setFetched]   = useState(false);
  const [toast, setToast]       = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [pendingTiers, setPendingTiers] = useState({}); // { [paymentId]: tier }
  const [pendingDays,  setPendingDays]  = useState({}); // { [paymentId]: days }
  const [shopDays,     setShopDays]     = useState({}); // { [shopId]: days }
  const [notifTitle,   setNotifTitle]   = useState('');
  const [notifBody,    setNotifBody]    = useState('');
  const [notifSending, setNotifSending] = useState(false);
  const [notifTarget,  setNotifTarget]  = useState('all'); // 'all' | 'customers' | 'barbers'
  const [shopBadge,    setShopBadge]    = useState({}); // { [shopId]: { text, color } }
  const [referrals,    setReferrals]    = useState([]); // all customer referrals
  const [refGranting,  setRefGranting]  = useState({}); // { [id]: true } loading state

  const [socialLinks, setSocialLinks] = useState(() => {
    // init all platforms off
    const s = {};
    SOCIAL_PLATFORMS.forEach(p => { s[p.key] = { url: '', enabled: false }; });
    return s;
  });

  const [settings, setSettings] = useState({
    jazzcash_number:      '',
    jazzcash_name:        '',
    easypaisa_number:     '',
    easypaisa_name:       '',
    credits_to_sub_days_rate: '100',
    wallet_min_send_amount: '10',
  });

  const showToast = (type, text) => {
    setToast({ type, text });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        const { data: prof } = await supabase.from('profiles').select('role').eq('id', session.user.id).maybeSingle();
        if (prof?.role === 'admin') setAuthed(true);
      }
      setCheckingSession(false);
    })();
  }, []);

  const handleLock = async () => {
    await supabase.auth.signOut();
    setAuthed(false);
    setFetched(false);
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await fetchAll();
    setRefreshing(false);
    showToast('success', 'Refreshed');
  };

  useEffect(() => {
    if (authed && !fetched) { fetchAll(); setFetched(true); }
  }, [authed]); // eslint-disable-line

  const fetchAll = async () => {
    const [{ data: sh }, { data: pa }, { data: bo }, { data: us }, { data: cfg }, { data: refs }] = await Promise.all([
      supabase.from('shops').select('*, profiles(full_name, email)').order('created_at', { ascending: false }),
      supabase.from('payment_submissions').select('*, shops(name)').order('submitted_at', { ascending: false }),
      supabase.from('bookings').select('*, profiles(full_name), shops(name), services(name), time_slots(slot_date, start_time)').order('created_at', { ascending: false }).limit(100),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('app_settings').select('key, value'),
      supabase.from('referrals')
        .select('*, referrer:profiles!referrals_referrer_id_fkey(full_name, email), referee:profiles!referrals_referee_id_fkey(full_name, email)')
        .order('created_at', { ascending: false })
        .limit(100),
    ]);
    setShops(sh || []);
    // Pre-populate custom badges from existing shop data
    const badges = {};
    (sh || []).forEach(s => {
      badges[s.id] = { text: s.custom_badge || '', color: s.custom_badge_color || '#FF5C1A' };
    });
    setShopBadge(badges);
    setPayments(pa || []);
    // Pre-populate tier selector with what each barber requested
    const tiers = {};
    const days  = {};
    (pa || []).forEach(p => {
      if (p.requested_tier) tiers[p.id] = p.requested_tier;
      days[p.id] = 30; // default 30 days
    });
    setPendingTiers(tiers);
    setPendingDays(days);
    setBookings(bo || []);
    setUsers(us || []);
    setReferrals(refs || []);

    // Load all settings from DB — any new key added to DB automatically appears
    const map = {};
    (cfg || []).forEach(r => { map[r.key] = r.value; });
    setSettings(prev => ({ ...prev, ...map }));

    // Load social links
    if (map.social_links) {
      try {
        const parsed = JSON.parse(map.social_links);
        setSocialLinks(prev => ({ ...prev, ...parsed }));
      } catch {}
    }

    // Load plans from DB if saved
    if (map.plans_config) {
      try { setPlans(JSON.parse(map.plans_config)); } catch {}
    }
  };

  const saveShopBadge = async (id) => {
    const badge = shopBadge[id] || { text: '', color: '#FF5C1A' };
    await supabase.from('shops').update({
      custom_badge: badge.text.trim() || null,
      custom_badge_color: badge.text.trim() ? badge.color : null,
    }).eq('id', id);
    fetchAll();
    showToast('success', badge.text.trim() ? `Badge set: "${badge.text}"` : 'Badge removed');
  };

  const approveShop = async (id, active, days = 30) => {
    let approvePayload;
    if (active) {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + Number(days));
      approvePayload = {
        is_active: true,
        subscription_status: 'active',
        subscription_approved_at: new Date().toISOString(),
        subscription_expires_at: expiresAt.toISOString(),
      };
    } else {
      approvePayload = { is_active: false, subscription_status: 'pending', subscription_approved_at: null };
    }
    await supabase.from('shops').update(approvePayload).eq('id', id);
    fetchAll();
    showToast('success', active ? `Shop approved · ${days} days` : 'Shop deactivated');
  };

  const setShopTier = async (id, tier) => {
    await supabase.from('shops').update({ subscription_tier: tier }).eq('id', id);
    fetchAll();
    showToast('success', `Tier set to ${tier}`);
  };

  const reviewPayment = async (id, status, shopId, tier, days = 30) => {
    const { error: pmtErr } = await supabase
      .from('payment_submissions')
      .update({ status, reviewed_at: new Date().toISOString() })
      .eq('id', id);
    if (pmtErr) { console.error('[DB] reviewPayment update error:', pmtErr); showToast('error', pmtErr.message); return; }

    // Look up the shop owner regardless of approve/reject so we can notify them either way.
    const { data: shopOwnerRow } = await supabase.from('shops').select('owner_id').eq('id', shopId).maybeSingle();
    const ownerId = shopOwnerRow?.owner_id;

    if (status === 'approved') {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + Number(days));
      const { data: shopRow, error: shopErr } = await supabase.from('shops').update({
        subscription_status: 'active',
        subscription_tier: tier || 'basic',
        is_active: true,
        subscription_approved_at: new Date().toISOString(),
        subscription_expires_at: expiresAt.toISOString(),
      }).eq('id', shopId).select('owner_id').maybeSingle();
      if (shopErr) { console.error('[DB] reviewPayment shop update error:', shopErr); showToast('error', shopErr.message); return; }

      // Pay out any pending barber-referral reward now that we know the tier
      if (shopRow?.owner_id) {
        const { error: rewardErr } = await supabase.rpc('reward_referral_on_plan_approval', {
          p_barber_id: shopRow.owner_id,
          p_tier: tier || 'basic',
        });
        if (rewardErr) console.error('[DB] reward_referral_on_plan_approval failed:', rewardErr.message);
      }

      if (ownerId) {
        sendNotification(ownerId, {
          title: 'Payment Approved! 🎉',
          body: `Your ${tier || 'basic'} plan is now active for ${days} days.`,
          type: 'payment',
        }).catch(() => {});
      }
    } else if (ownerId) {
      sendNotification(ownerId, {
        title: 'Payment Rejected',
        body: 'Your payment proof was rejected. Please resubmit or contact support.',
        type: 'payment',
      }).catch(() => {});
    }
    fetchAll();
    showToast('success', status === 'approved' ? `Approved · ${tier || 'basic'} · ${days} days` : 'Payment rejected');
  };

  const saveSettings = async () => {
    // Exclude hash keys (changed via dedicated changers) and plans_config (saved via savePlans)
    const excludedKeys = ['plans_config'];
    const rows = Object.entries(settings)
      .filter(([key]) => !excludedKeys.includes(key))
      .map(([key, value]) => ({ key, value: String(value) }));
    if (rows.length === 0) { showToast('error', 'Nothing to save'); return; }
    const { error } = await supabase.from('app_settings').upsert(rows, { onConflict: 'key' });
    if (error) {
      console.error('[DB] saveSettings failed:', error);
      showToast('error', 'Save failed: ' + error.message);
    } else {
      showToast('success', 'Settings saved');
    }
  };

  // Add a new custom setting key at runtime
  const addCustomSetting = (key, value = '') => {
    if (!key || settings[key] !== undefined) return;
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const savePlans = async (updatedPlans) => {
    setPlans(updatedPlans);
    const { error } = await supabase.from('app_settings').upsert(
      { key: 'plans_config', value: JSON.stringify(updatedPlans) },
      { onConflict: 'key' }
    );
    if (error) {
      console.error('[DB] savePlans failed:', error);
      showToast('error', 'Save failed: ' + error.message);
    } else {
      showToast('success', 'Plans saved');
    }
  };

  if (checkingSession) return <div className="loading-screen"><div className="spinner" /></div>;
  if (!authed) return <AdminLogin onAuthed={() => setAuthed(true)} />;

  const pendingPayments = payments.filter(p => p.status === 'pending').length;

  const TABS = [
    {
      key: 'shops', label: 'Shops', desc: `${shops.length} total`,
      color: '#3B82F6',
      icon: (
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
        </svg>
      ),
    },
    {
      key: 'payments', label: 'Payments', desc: pendingPayments > 0 ? `${pendingPayments} pending` : `${payments.length} total`,
      color: '#F59E0B', badge: pendingPayments > 0 ? pendingPayments : null,
      icon: <CreditCard size={26} />,
    },
    {
      key: 'bookings', label: 'Bookings', desc: `${bookings.length} total`,
      color: '#8B5CF6',
      icon: <Calendar size={26} />,
    },
    {
      key: 'users', label: 'Users', desc: `${users.length} total`,
      color: '#10B981',
      icon: <Users size={26} />,
    },
    {
      key: 'plans', label: 'Plans', desc: '3 tiers',
      color: '#EC4899',
      icon: <Crown size={26} />,
    },
    {
      key: 'social', label: 'Social', desc: 'Links & handles',
      color: '#06B6D4',
      icon: (
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
          <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
          <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
        </svg>
      ),
    },
    {
      key: 'notify', label: 'Notify', desc: 'Broadcast to users',
      color: '#F97316',
      icon: <Bell size={26} />,
    },
    {
      key: 'referrals', label: 'Referrals', desc: (() => { const p = referrals.filter(r => r.status === 'awaiting_purchase' || r.status === 'pending').length; return p > 0 ? `${p} pending` : `${referrals.length} total`; })(),
      color: '#EC4899', badge: referrals.filter(r => r.status === 'awaiting_purchase' || r.status === 'pending').length || null,
      icon: (
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/>
          <line x1="12" y1="22" x2="12" y2="7"/>
          <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/>
          <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
        </svg>
      ),
    },
    {
      key: 'support', label: 'Support', desc: 'Customer & barber tickets',
      color: '#0080FF',
      icon: (
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
        </svg>
      ),
    },
    {
      key: 'settings', label: 'Settings', desc: 'Config & access',
      color: '#6B7280',
      icon: <Gear size={26} />,
    },
  ];

  const activeTab = TABS.find(t => t.key === tab);

  const sendBroadcast = async () => {
    if (!notifTitle.trim() || !notifBody.trim()) return;
    setNotifSending(true);
    try {
      // Fetch target user IDs
      let query = supabase.from('profiles').select('id, role');
      if (notifTarget === 'customers') query = query.eq('role', 'customer');
      if (notifTarget === 'barbers')   query = query.eq('role', 'barber');
      const { data: profiles, error } = await query;
      if (error) throw error;
      if (!profiles || profiles.length === 0) { showToast('error', 'No users found'); return; }

      // Batch insert notifications
      const rows = profiles.map(p => ({
        user_id: p.id,
        title:   notifTitle.trim(),
        body:    notifBody.trim(),
        type:    'admin_broadcast',
        is_read: false,
      }));
      const { error: insErr } = await supabase.from('notifications').insert(rows);
      if (insErr) throw insErr;

      showToast('success', `Sent to ${rows.length} user${rows.length !== 1 ? 's' : ''}`);
      setNotifTitle('');
      setNotifBody('');
    } catch (err) {
      showToast('error', 'Failed: ' + err.message);
    } finally {
      setNotifSending(false);
    }
  };

  return (
    <div style={{ minHeight: '100dvh', paddingBottom: 60 }}>
      {toast && <div className={`toast toast-${toast.type}`}>{toast.text}</div>}

      {/* ── Hero Header ── */}
      <div style={{
        background: 'linear-gradient(135deg, var(--brand) 0%, #0055cc 100%)',
        padding: '36px 20px 28px',
        position: 'relative',
      }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', position:'relative', zIndex:1 }}>
          <div>
            <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:6 }}>
              <div style={{ width:38, height:38, borderRadius:12, background:'rgba(255,255,255,0.18)', display:'flex', alignItems:'center', justifyContent:'center' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
              </div>
              <div>
                <div style={{ fontSize:11, fontWeight:700, letterSpacing:1.5, textTransform:'uppercase', color:'rgba(255,255,255,0.7)', fontFamily:'var(--font-display)' }}>Zentro</div>
                <div style={{ fontSize:20, fontWeight:800, color:'#fff', fontFamily:'var(--font-display)', lineHeight:1.1 }}>Admin Portal</div>
              </div>
            </div>
          </div>
          <div style={{ display:'flex', gap:8 }}>
            <button
              onClick={handleRefresh}
              disabled={refreshing}
              style={{
                display:'flex', alignItems:'center', gap:5, padding:'7px 14px', borderRadius:20,
                background:'rgba(255,255,255,0.15)', border:'1.5px solid rgba(255,255,255,0.25)',
                color:'#fff', fontSize:12, fontWeight:700, fontFamily:'var(--font-display)', cursor: refreshing ? 'default' : 'pointer',
                opacity: refreshing ? 0.6 : 1,
              }}
            >
              <RefreshCw size={12} style={refreshing ? { animation: 'spin 0.8s linear infinite' } : {}} /> {refreshing ? 'Refreshing…' : 'Refresh'}
            </button>
            <button
              onClick={handleLock}
              style={{
                display:'flex', alignItems:'center', gap:5, padding:'7px 14px', borderRadius:20,
                background:'rgba(255,255,255,0.15)', border:'1.5px solid rgba(255,255,255,0.25)',
                color:'#fff', fontSize:12, fontWeight:700, fontFamily:'var(--font-display)', cursor:'pointer',
              }}
            >
              <Lock size={12} /> Lock
            </button>
          </div>
        </div>

        {/* Stats row */}
        <div style={{ display:'flex', gap:8, marginTop:20, position:'relative', zIndex:1 }}>
          {[
            { label:'Shops',    value: shops.length },
            { label:'Users',    value: users.length },
            { label:'Bookings', value: bookings.length },
            { label:'Pending',  value: pendingPayments, highlight: pendingPayments > 0 },
          ].map((s, i) => (
            <div key={s.label} className="stat-enter" style={{
              flex:1, background:'rgba(255,255,255,0.13)', borderRadius:10,
              padding:'8px 6px', textAlign:'center', animationDelay: `${i * 0.05}s`,
              border: s.highlight ? '1.5px solid rgba(255,220,0,0.5)' : '1.5px solid rgba(255,255,255,0.1)',
            }}>
              <div style={{ fontSize:18, fontWeight:800, color: s.highlight ? '#FFD700' : '#fff', fontFamily:'var(--font-display)', lineHeight:1 }}>{s.value}</div>
              <div style={{ fontSize:10, color:'rgba(255,255,255,0.65)', fontWeight:600, marginTop:2, textTransform:'uppercase', letterSpacing:0.5 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Nav Grid ── */}
      <div style={{ padding:'20px 16px 4px' }}>
        <div style={{ display:'grid', gridTemplateColumns:'repeat(4, 1fr)', gap:10, marginBottom:6 }}>
          {TABS.map(t => {
            const isActive = tab === t.key;
            return (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                style={{
                  position:'relative', padding:'14px 8px 12px', borderRadius:16, cursor:'pointer',
                  display:'flex', flexDirection:'column', alignItems:'center', gap:6,
                  background: isActive ? 'var(--brand-glow)' : 'var(--bg-input)',
                  border: `1.5px solid ${isActive ? 'var(--border-brand)' : 'var(--border)'}`,
                  transition:'all 0.18s', outline:'none',
                }}
              >
                {/* badge */}
                {t.badge && (
                  <span style={{
                    position:'absolute', top:6, right:6,
                    background:'#F59E0B', color:'#fff', borderRadius:8,
                    fontSize:10, fontWeight:800, padding:'1px 5px', lineHeight:'14px',
                    fontFamily:'var(--font-display)',
                  }}>{t.badge}</span>
                )}
                <div style={{ color: isActive ? 'var(--brand)' : 'var(--text-3)', transition:'color 0.18s' }}>
                  {t.icon}
                </div>
                <span style={{
                  fontSize:11, fontWeight:700, fontFamily:'var(--font-display)',
                  color: isActive ? 'var(--brand)' : 'var(--text-2)',
                  textAlign:'center', lineHeight:1.2,
                }}>{t.label}</span>
                {isActive && (
                  <div style={{ width:18, height:3, borderRadius:2, background:'var(--brand)', marginTop:1 }} />
                )}
              </button>
            );
          })}
        </div>

        {/* Active tab breadcrumb */}
        {activeTab && (
          <div style={{ display:'flex', alignItems:'center', gap:8, padding:'10px 4px 16px' }}>
            <div style={{ width:6, height:6, borderRadius:'50%', background: 'var(--brand)', flexShrink:0 }} />
            <span style={{ fontSize:13, fontWeight:800, fontFamily:'var(--font-display)', color:'var(--text-1)' }}>{activeTab.label}</span>
            <span style={{ fontSize:12, color:'var(--text-3)' }}>·</span>
            <span style={{ fontSize:12, color:'var(--text-3)' }}>{activeTab.desc}</span>
          </div>
        )}
      </div>

      <div key={tab} className="fade-in" style={{ padding: '0 20px' }}>

        {/* ── SHOPS ── */}
        {tab === 'shops' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{shops.length} total · {shops.filter(s => s.is_active).length} active</p>
            {shops.length === 0 && <div className="empty-state"><div className="empty-icon"><Store size={36} color="var(--text-3)" /></div><div className="empty-sub">No shops yet</div></div>}
            {shops.map((s, i) => (
              <div key={s.id} className="card stagger-in" style={{ marginBottom: 12, animationDelay: `${Math.min(i * 0.03, 0.3)}s` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 16 }}>{s.name}</div>
                  <span className={`badge ${s.is_active ? 'badge-success' : 'badge-warning'}`}>
                    {s.is_active ? 'Active' : 'Pending'}
                  </span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 2, display:'flex', alignItems:'center', gap:5 }}><MapPin size={12} color="var(--text-3)" /> {s.city}, {s.address}</p>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: s.subscription_expires_at ? 2 : 12, display:'flex', alignItems:'center', gap:5 }}><User size={12} color="var(--text-3)" /> {s.profiles?.full_name}</p>
                {s.subscription_expires_at && (
                  <p style={{ fontSize: 12, marginBottom: 12, display:'flex', alignItems:'center', gap:5,
                    color: new Date(s.subscription_expires_at) < new Date() ? 'var(--error)' : 'var(--text-3)' }}>
                    <Timer size={12} color={new Date(s.subscription_expires_at) < new Date() ? 'var(--error)' : 'var(--text-3)'} />
                    {new Date(s.subscription_expires_at) < new Date() ? 'Expired' : 'Expires'}: {new Date(s.subscription_expires_at).toLocaleDateString()}
                  </p>
                )}

                {/* Tier selector */}
                <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
                  {['basic', 'pro', 'premium'].map(tier => (
                    <button key={tier} onClick={() => setShopTier(s.id, tier)}
                      style={{
                        flex: 1, padding: '6px 0', borderRadius: 8, fontSize: 12, fontWeight: 700,
                        fontFamily: 'var(--font-display)', cursor: 'pointer', textTransform: 'capitalize',
                        border: `1.5px solid ${s.subscription_tier === tier ? 'var(--brand)' : 'var(--border)'}`,
                        background: s.subscription_tier === tier ? 'var(--brand-dim)' : 'var(--bg-input)',
                        color: s.subscription_tier === tier ? 'var(--brand)' : 'var(--text-3)',
                      }}>
                      {tier}
                    </button>
                  ))}
                </div>

                {/* Days picker — only show when approving */}
                {!s.is_active && (
                  <div style={{ marginBottom: 10 }}>
                    <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>Grant Duration</p>
                    <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                      {[7, 14, 30, 90].map(d => (
                        <button key={d}
                          onClick={() => setShopDays(prev => ({ ...prev, [s.id]: d }))}
                          style={{
                            padding: '5px 10px', borderRadius: 8,
                            fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)',
                            cursor: 'pointer',
                            border: `1.5px solid ${(shopDays[s.id] || 30) === d ? 'var(--brand)' : 'var(--border)'}`,
                            background: (shopDays[s.id] || 30) === d ? 'var(--brand-dim)' : 'var(--bg-input)',
                            color: (shopDays[s.id] || 30) === d ? 'var(--brand)' : 'var(--text-3)',
                          }}>
                          {d}d
                        </button>
                      ))}
                      <input
                        type="number" min="1" max="365"
                        value={shopDays[s.id] || 30}
                        onChange={e => setShopDays(prev => ({ ...prev, [s.id]: parseInt(e.target.value) || 30 }))}
                        style={{
                          width: 58, padding: '5px 8px', borderRadius: 8,
                          border: '1.5px solid var(--border)', background: 'var(--bg-input)',
                          color: 'var(--text-1)', fontSize: 13, fontFamily: 'var(--font-display)',
                          fontWeight: 700, textAlign: 'center',
                        }}
                      />
                      <span style={{ fontSize: 12, color: 'var(--text-3)' }}>days</span>
                    </div>
                  </div>
                )}

                {/* ── Custom Badge ── */}
                <div style={{ marginBottom: 12 }}>
                  <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>Custom Badge</p>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                    <input
                      className="input"
                      style={{ flex: 1, marginBottom: 0, fontSize: 13 }}
                      placeholder="e.g. Top Rated, New, Hot"
                      value={shopBadge[s.id]?.text || ''}
                      onChange={e => setShopBadge(prev => ({ ...prev, [s.id]: { ...prev[s.id], text: e.target.value } }))}
                    />
                    <input
                      type="color"
                      value={shopBadge[s.id]?.color || '#FF5C1A'}
                      onChange={e => setShopBadge(prev => ({ ...prev, [s.id]: { ...prev[s.id], color: e.target.value } }))}
                      style={{ width: 42, height: 42, borderRadius: 8, border: '1.5px solid var(--border)', background: 'none', cursor: 'pointer', padding: 2, flexShrink: 0 }}
                    />
                  </div>
                  {shopBadge[s.id]?.text?.trim() && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                      <span style={{ fontSize: 12, color: 'var(--text-3)' }}>Preview:</span>
                      <span style={{
                        fontSize: 10, fontWeight: 800, fontFamily: 'var(--font-display)',
                        padding: '3px 8px', borderRadius: 20,
                        background: (shopBadge[s.id]?.color || '#FF5C1A') + '20',
                        color: shopBadge[s.id]?.color || '#FF5C1A',
                        border: `1px solid ${(shopBadge[s.id]?.color || '#FF5C1A')}55`,
                        display: 'inline-flex', alignItems: 'center', gap: 4,
                      }}>
                        <span style={{ width: 5, height: 5, borderRadius: '50%', background: shopBadge[s.id]?.color || '#FF5C1A', display: 'inline-block' }} />
                        {shopBadge[s.id].text}
                      </span>
                    </div>
                  )}
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => saveShopBadge(s.id)}>
                      <Save size={12} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />
                      {shopBadge[s.id]?.text?.trim() ? 'Save Badge' : 'Remove Badge'}
                    </button>
                    {s.custom_badge && (
                      <button className="btn btn-ghost btn-sm" onClick={() => {
                        setShopBadge(prev => ({ ...prev, [s.id]: { text: '', color: '#FF5C1A' } }));
                        setTimeout(() => saveShopBadge(s.id), 0);
                      }}>
                        <X size={12} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 5 }} />
                        Clear
                      </button>
                    )}
                  </div>
                </div>

                <button className={`btn btn-sm ${s.is_active ? 'btn-danger' : 'btn-primary'}`} style={{ width: '100%' }}
                  onClick={() => approveShop(s.id, !s.is_active, shopDays[s.id] || 30)}>
                  {s.is_active ? 'Deactivate Shop' : <><Check size={13} style={{display:'inline',verticalAlign:'middle',marginRight:5}} />Approve · {shopDays[s.id] || 30} days</>}
                </button>
              </div>
            ))}
          </div>
        )}

        {/* ── PAYMENTS ── */}
        {tab === 'payments' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{payments.length} total · {pendingPayments} pending</p>
            {payments.length === 0 && <div className="empty-state"><div className="empty-icon"><CreditCard size={36} color="var(--text-3)" /></div><div className="empty-sub">No payments yet</div></div>}
            {payments.map((p, i) => (
              <div key={p.id} className="card stagger-in" style={{ marginBottom: 12, animationDelay: `${Math.min(i * 0.03, 0.3)}s` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{p.shops?.name}</span>
                  <span className={`badge ${p.status === 'approved' ? 'badge-success' : p.status === 'rejected' ? 'badge-error' : 'badge-warning'}`}>
                    {p.status}
                  </span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 2, display:'flex', alignItems:'center', gap:5 }}><DollarSign size={12} color="var(--text-3)" /> Rs {p.amount} · {p.payment_method}</p>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 2, display:'flex', alignItems:'center', gap:5 }}><Tag size={12} color="var(--text-3)" /> TXN: {p.txn_id}</p>
                <p style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: p.screenshot_url ? 8 : 12 }}>
                  {new Date(p.submitted_at).toLocaleDateString()}
                </p>
                {p.screenshot_url && (
                  <a href={p.screenshot_url} target="_blank" rel="noreferrer"
                    style={{ fontSize: 13, color: 'var(--brand)', display: 'flex', alignItems: 'center', gap: 5, marginBottom: 10 }}>
                    <Paperclip size={13} color="var(--brand)" /> View Screenshot ↗
                  </a>
                )}
                {p.status === 'pending' && (() => {
                  const selectedTier = pendingTiers[p.id] || p.requested_tier || 'basic';
                  return (
                    <div>
                      {/* Tier selector — pre-filled with what barber requested */}
                      <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 4 }}>
                        Grant Plan
                      </p>
                      {p.requested_tier && (
                        <p style={{ fontSize: 12, color: 'var(--brand)', marginBottom: 8, fontWeight: 600, display:'flex', alignItems:'center', gap:5 }}>
                          <Target size={13} color="var(--brand)" /> Barber requested: <strong style={{ textTransform: 'capitalize' }}>{p.requested_tier}</strong>
                        </p>
                      )}
                      <div style={{ display: 'flex', gap: 6, marginBottom: 10 }}>
                        {[
                          { key: 'basic',   label: 'Basic',   color: '#8EA0BC' },
                          { key: 'pro',     label: 'Pro',     color: 'var(--brand)' },
                          { key: 'premium', label: 'Premium', color: '#FFB800' },
                        ].map(t => (
                          <button key={t.key}
                            onClick={() => setPendingTiers(prev => ({ ...prev, [p.id]: t.key }))}
                            style={{
                              flex: 1, padding: '7px 0', borderRadius: 8,
                              fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)',
                              cursor: 'pointer', textTransform: 'capitalize',
                              border: `1.5px solid ${selectedTier === t.key ? t.color : 'var(--border)'}`,
                              background: selectedTier === t.key ? `${t.color}18` : 'var(--bg-input)',
                              color: selectedTier === t.key ? t.color : 'var(--text-3)',
                              transition: 'all 0.15s',
                            }}>
                            {t.label}
                          </button>
                        ))}
                      </div>
                      {/* Custom days input */}
                      <div style={{ marginBottom: 10 }}>
                        <p style={{ fontSize: 11, fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>Grant Duration</p>
                        <div style={{ display: 'flex', gap: 6, alignItems: 'center', flexWrap: 'wrap' }}>
                          {[7, 14, 30, 90].map(d => (
                            <button key={d}
                              onClick={() => setPendingDays(prev => ({ ...prev, [p.id]: d }))}
                              style={{
                                padding: '6px 10px', borderRadius: 8,
                                fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)',
                                cursor: 'pointer',
                                border: `1.5px solid ${(pendingDays[p.id] || 30) === d ? 'var(--brand)' : 'var(--border)'}`,
                                background: (pendingDays[p.id] || 30) === d ? 'var(--brand-dim)' : 'var(--bg-input)',
                                color: (pendingDays[p.id] || 30) === d ? 'var(--brand)' : 'var(--text-3)',
                              }}>
                              {d}d
                            </button>
                          ))}
                          <input
                            type="number" min="1" max="365"
                            value={pendingDays[p.id] || 30}
                            onChange={e => setPendingDays(prev => ({ ...prev, [p.id]: parseInt(e.target.value) || 30 }))}
                            style={{
                              width: 58, padding: '6px 8px', borderRadius: 8,
                              border: '1.5px solid var(--border)', background: 'var(--bg-input)',
                              color: 'var(--text-1)', fontSize: 13, fontFamily: 'var(--font-display)',
                              fontWeight: 700, textAlign: 'center',
                            }}
                          />
                          <span style={{ fontSize: 12, color: 'var(--text-3)' }}>days</span>
                        </div>
                      </div>
                      <div style={{ display: 'flex', gap: 8 }}>
                        <button className="btn btn-primary btn-sm" style={{ flex: 1 }}
                          onClick={() => reviewPayment(p.id, 'approved', p.shop_id, selectedTier, pendingDays[p.id] || 30)}>
                          <Check size={13} style={{display:'inline',verticalAlign:'middle',marginRight:5}} /> Approve · {selectedTier} · {pendingDays[p.id] || 30}d
                        </button>
                        <button className="btn btn-danger btn-sm" style={{ flex: 1 }}
                          onClick={() => reviewPayment(p.id, 'rejected', p.shop_id, null)}>
                          <X size={13} style={{display:'inline',verticalAlign:'middle',marginRight:5}} /> Reject
                        </button>
                      </div>
                    </div>
                  );
                })()}
              </div>
            ))}
          </div>
        )}

        {/* ── REFERRALS ── */}
        {tab === 'referrals' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>
              {referrals.length} total · {referrals.filter(r => r.status === 'rewarded').length} rewarded · {referrals.filter(r => r.status === 'awaiting_purchase' || r.status === 'pending').length} pending
            </p>
            {referrals.length === 0 && <div className="empty-state"><div className="empty-icon"><Target size={36} color="var(--text-3)" /></div><div className="empty-sub">No referrals yet</div></div>}
            {referrals.map((r, i) => (
              <div key={r.id} className="card stagger-in" style={{ marginBottom: 12, animationDelay: `${Math.min(i * 0.03, 0.3)}s` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, textTransform: 'capitalize' }}>{r.type?.replace(/_/g, ' ') || 'Referral'}</span>
                  <span className={`badge ${r.status === 'rewarded' ? 'badge-success' : r.status === 'expired' || r.status === 'rejected' ? 'badge-error' : 'badge-warning'}`}>
                    {r.status?.replace(/_/g, ' ')}
                  </span>
                </div>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 2, display:'flex', alignItems:'center', gap:5 }}>
                  <User size={12} color="var(--text-3)" /> Referrer: {r.referrer?.full_name || r.referrer?.email || '—'}
                </p>
                <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 2, display:'flex', alignItems:'center', gap:5 }}>
                  <User size={12} color="var(--text-3)" /> Referee: {r.referee?.full_name || r.referee?.email || '—'}
                </p>
                <p style={{ fontSize: 12, color: 'var(--text-3)', marginTop: 6 }}>
                  Created {new Date(r.created_at).toLocaleDateString()}
                  {r.rewarded_at && <> · Rewarded {new Date(r.rewarded_at).toLocaleDateString()}</>}
                </p>
              </div>
            ))}
          </div>
        )}

        {/* ── BOOKINGS ── */}
        {tab === 'bookings' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>{bookings.length} total bookings</p>
            {bookings.length === 0 && <div className="empty-state"><div className="empty-icon"><Calendar size={36} color="var(--text-3)" /></div><div className="empty-sub">No bookings yet</div></div>}
            {bookings.map((b, i) => (
              <div key={b.id} className="card card-sm stagger-in" style={{ marginBottom: 10, animationDelay: `${Math.min(i * 0.025, 0.25)}s` }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>{b.shops?.name}</span>
                  <span style={{ fontSize: 11, fontWeight: 700, fontFamily: 'var(--font-display)',
                    color: b.status === 'completed' ? 'var(--success)' : b.status === 'cancelled' ? 'var(--text-3)' : 'var(--warning)' }}>
                    {b.status?.toUpperCase()}
                  </span>
                </div>
                <p style={{ fontSize: 12, color: 'var(--text-2)', display:'flex', alignItems:'center', gap:6 }}><User size={12} color="var(--text-3)" /> {b.profiles?.full_name} <Scissors size={12} color="var(--text-3)" /> {b.services?.name}</p>
                <p style={{ fontSize: 12, color: 'var(--text-2)', display:'flex', alignItems:'center', gap:5 }}><Calendar size={12} color="var(--text-3)" /> {b.time_slots?.slot_date} at {b.time_slots?.start_time?.slice(0, 5)}</p>
              </div>
            ))}
          </div>
        )}

        {/* ── USERS ── */}
        {tab === 'users' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>
              {users.length} total · {users.filter(u => u.role === 'barber').length} barbers · {users.filter(u => u.role === 'customer').length} customers
            </p>
            {users.length === 0 && <div className="empty-state"><div className="empty-icon"><Users size={36} color="var(--text-3)" /></div><div className="empty-sub">No users yet</div></div>}
            {users.map((u, i) => (
              <div key={u.id} className="card card-sm stagger-in tap-feedback" style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center', animationDelay: `${Math.min(i * 0.025, 0.25)}s` }}>
                <div>
                  <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14 }}>{u.full_name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-2)' }}>{u.email}</div>
                  <div style={{ fontSize: 11, color: 'var(--text-3)' }}>{new Date(u.created_at).toLocaleDateString()}</div>
                </div>
                <span className={`badge ${u.role === 'barber' ? 'badge-brand' : 'badge-success'}`}>{u.role}</span>
              </div>
            ))}
          </div>
        )}

        {/* ── PLANS ── */}
        {tab === 'plans' && (
          <PlansEditor plans={plans} onSave={savePlans} showToast={showToast} />
        )}

        {/* ── SOCIAL ── */}
        {tab === 'social' && (
          <SocialEditor
            socialLinks={socialLinks}
            setSocialLinks={setSocialLinks}
            showToast={showToast}
          />
        )}

        {/* ── NOTIFY ── */}
        {tab === 'notify' && (
          <div>
            <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 20 }}>
              Send a notification to all users' in-app inbox instantly.
            </p>

            {/* Target selector */}
            <p style={{ fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)', color: 'var(--text-3)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 1 }}>Send To</p>
            <div style={{ display: 'flex', gap: 8, marginBottom: 20 }}>
              {[['all', 'All Users'], ['customers', 'Customers'], ['barbers', 'Barbers']].map(([val, label]) => (
                <button key={val} onClick={() => setNotifTarget(val)} style={{
                  flex: 1, padding: '10px 6px', borderRadius: 10, cursor: 'pointer',
                  fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12,
                  border: notifTarget === val ? 'none' : '1.5px solid var(--border)',
                  background: notifTarget === val ? 'var(--brand)' : 'var(--bg-card)',
                  color: notifTarget === val ? '#fff' : 'var(--text-2)',
                  boxShadow: notifTarget === val ? '0 4px 14px rgba(0,128,255,0.3)' : 'none',
                  transition: 'all 0.15s',
                }}>{label}</button>
              ))}
            </div>

            {/* Title */}
            <p style={{ fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)', color: 'var(--text-3)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 1 }}>Title</p>
            <input
              value={notifTitle}
              onChange={e => setNotifTitle(e.target.value)}
              placeholder="e.g. New Feature Available!"
              maxLength={80}
              style={{
                width: '100%', padding: '12px 14px', borderRadius: 12, marginBottom: 16,
                background: 'var(--bg-input)', border: '1.5px solid var(--border)',
                color: 'var(--text-1)', fontSize: 14, fontFamily: 'var(--font-display)',
                boxSizing: 'border-box',
              }}
            />

            {/* Body */}
            <p style={{ fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-display)', color: 'var(--text-3)', marginBottom: 8, textTransform: 'uppercase', letterSpacing: 1 }}>Message</p>
            <textarea
              value={notifBody}
              onChange={e => setNotifBody(e.target.value)}
              placeholder="Write your message here..."
              maxLength={300}
              rows={4}
              style={{
                width: '100%', padding: '12px 14px', borderRadius: 12, marginBottom: 8,
                background: 'var(--bg-input)', border: '1.5px solid var(--border)',
                color: 'var(--text-1)', fontSize: 14, fontFamily: 'var(--font-display)',
                resize: 'none', boxSizing: 'border-box',
              }}
            />
            <p style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 20, textAlign: 'right' }}>{notifBody.length}/300</p>

            <button
              onClick={sendBroadcast}
              disabled={notifSending || !notifTitle.trim() || !notifBody.trim()}
              className="btn btn-primary"
              style={{ width: '100%', opacity: (notifSending || !notifTitle.trim() || !notifBody.trim()) ? 0.5 : 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
            >
              {notifSending ? 'Sending...' : <>Send Notification <Bell size={15} /></>}
            </button>
          </div>
        )}

        {/* ── SUPPORT ── */}
        {tab === 'support' && <AdminSupportPanel showToast={showToast} />}

        {/* ── SETTINGS ── */}
        {tab === 'settings' && (
          <SettingsEditor
            settings={settings}
            setSettings={setSettings}
            onSave={saveSettings}
            onAddCustom={addCustomSetting}
            showToast={showToast}
          />
        )}
      </div>
    </div>
  );
}

// ── Admin Support Panel — list tickets, view + reply ──────────────────────────
function AdminSupportPanel({ showToast }) {
  const [tickets, setTickets]   = useState([]);
  const [loading, setLoading]   = useState(true);
  const [active, setActive]     = useState(null); // ticket object
  const [messages, setMessages] = useState([]);
  const [reply, setReply]       = useState('');
  const [sending, setSending]   = useState(false);

  const loadTickets = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('support_tickets')
      .select('*, profiles(full_name, role)')
      .order('updated_at', { ascending: false });
    setTickets(data || []);
    setLoading(false);
  };

  useEffect(() => { loadTickets(); }, []);

  const openTicket = async (t) => {
    setActive(t);
    const { data } = await supabase.from('support_messages').select('*').eq('ticket_id', t.id).order('created_at', { ascending: true });
    setMessages(data || []);
  };

  const sendReply = async () => {
    if (!reply.trim() || !active) return;
    setSending(true);
    const { data: userData } = await supabase.auth.getUser();
    const { data, error } = await supabase.from('support_messages').insert({
      ticket_id: active.id, sender_id: userData?.user?.id, sender_role: 'admin', message: reply.trim(),
    }).select('*').single();
    setSending(false);
    if (error) { showToast('error', 'Failed to send'); return; }
    setMessages(prev => [...prev, data]);
    if (active.user_id) {
      sendNotification(active.user_id, {
        title: 'New Support Reply',
        body: reply.trim().slice(0, 120),
        type: 'support',
      }).catch(() => {});
    }
    setReply('');
  };

  const setStatus = async (status) => {
    if (!active) return;
    await supabase.from('support_tickets').update({ status }).eq('id', active.id);
    setActive(a => ({ ...a, status }));
    loadTickets();
    showToast('success', `Ticket marked ${status}`);
  };

  if (loading) return <div className="spinner" style={{ margin: '40px auto' }} />;

  // Conversation view
  if (active) {
    return (
      <div>
        <button className="btn btn-ghost btn-sm" onClick={() => setActive(null)} style={{ marginBottom: 14 }}>← Back to tickets</button>
        <div className="card" style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800 }}>{active.profiles?.full_name || 'User'}</div>
            <span className={`badge ${active.status === 'closed' ? 'badge-success' : 'badge-warning'}`}>{active.status}</span>
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-3)', textTransform: 'capitalize' }}>{active.profiles?.role || 'user'}</div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 16, maxHeight: '50dvh', overflowY: 'auto' }}>
          {messages.map(m => {
            const isAdmin = m.sender_role === 'admin';
            return (
              <div key={m.id} style={{
                alignSelf: isAdmin ? 'flex-end' : 'flex-start', maxWidth: '78%',
                background: isAdmin ? 'var(--brand)' : 'var(--bg-input)',
                color: isAdmin ? '#fff' : 'var(--text-1)',
                borderRadius: 14, padding: '9px 13px', fontSize: 14, lineHeight: 1.4,
              }}>
                {!isAdmin && <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', color: 'var(--text-3)', marginBottom: 2 }}>{m.sender_role}</div>}
                {m.message}
              </div>
            );
          })}
        </div>

        <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
          <input className="input" placeholder="Type a reply…" value={reply}
            onChange={e => setReply(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendReply()} />
          <button className="btn btn-primary btn-sm" onClick={sendReply} disabled={sending || !reply.trim()}>Send</button>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={() => setStatus('in_progress')}>Mark In Progress</button>
          <button className="btn btn-ghost btn-sm" style={{ flex: 1 }} onClick={() => setStatus('closed')}>Close Ticket</button>
        </div>
      </div>
    );
  }

  // Ticket list view
  if (tickets.length === 0) {
    return <div className="empty-state"><div className="empty-sub">No support tickets yet</div></div>;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {tickets.map(t => (
        <div key={t.id} className="card" style={{ cursor: 'pointer' }} onClick={() => openTicket(t)}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{t.profiles?.full_name || 'User'}</div>
            <span className={`badge ${t.status === 'closed' ? 'badge-success' : t.status === 'in_progress' ? 'badge-brand' : 'badge-warning'}`}>{t.status}</span>
          </div>
          <div style={{ fontSize: 12, color: 'var(--text-3)' }}>
            {t.profiles?.role || 'user'} · updated {new Date(t.updated_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ── Social Media Editor ───────────────────────────────────────────────────────
function SocialEditor({ socialLinks, setSocialLinks, showToast }) {
  const [saving, setSaving] = useState(false);

  const toggle = (key) => {
    setSocialLinks(prev => ({
      ...prev,
      [key]: { ...prev[key], enabled: !prev[key]?.enabled },
    }));
  };

  const setUrl = (key, url) => {
    setSocialLinks(prev => ({
      ...prev,
      [key]: { ...prev[key], url },
    }));
  };

  const save = async () => {
    setSaving(true);
    invalidateSocialCache();
    const { error } = await supabase.from('app_settings').upsert(
      { key: 'social_links', value: JSON.stringify(socialLinks) },
      { onConflict: 'key' }
    );
    setSaving(false);
    if (error) {
      showToast('error', 'Save failed: ' + error.message);
    } else {
      showToast('success', 'Social links saved — synced across all users');
    }
  };

  const enabledCount = SOCIAL_PLATFORMS.filter(p => socialLinks[p.key]?.enabled && socialLinks[p.key]?.url?.trim()).length;

  return (
    <div>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 6 }}>
        Toggle which platforms show on the home page. Changes sync instantly for all users.
      </p>
      <p style={{ color: 'var(--brand)', fontSize: 12, fontWeight: 700, marginBottom: 20 }}>
        {enabledCount} platform{enabledCount !== 1 ? 's' : ''} active
      </p>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14, marginBottom: 24 }}>
        {SOCIAL_PLATFORMS.map(({ key, label, Icon, color, placeholder }) => {
          const link = socialLinks[key] || { url: '', enabled: false };
          const isActive = link.enabled && link.url?.trim();
          return (
            <div key={key} className="card" style={{
              border: `1.5px solid ${isActive ? color + '55' : 'var(--border)'}`,
              padding: '14px 16px',
              transition: 'border-color 0.2s',
            }}>
              {/* Header row */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: link.enabled ? 12 : 0 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 10, flexShrink: 0,
                  background: link.enabled ? color + '18' : 'var(--bg-input)',
                  border: `1.5px solid ${link.enabled ? color + '55' : 'var(--border)'}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'all 0.2s',
                }}>
                  <Icon size={18} color={link.enabled ? color : 'var(--text-3)'} />
                </div>
                <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, flex: 1 }}>
                  {label}
                </span>
                {/* Toggle switch */}
                <div
                  onClick={() => toggle(key)}
                  style={{
                    width: 44, height: 24, borderRadius: 12, cursor: 'pointer',
                    background: link.enabled ? color : 'var(--border)',
                    position: 'relative', transition: 'background 0.2s', flexShrink: 0,
                  }}
                >
                  <div style={{
                    position: 'absolute', top: 3,
                    left: link.enabled ? 23 : 3,
                    width: 18, height: 18, borderRadius: '50%',
                    background: '#fff', transition: 'left 0.2s',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.3)',
                  }} />
                </div>
              </div>

              {/* URL input — show always so admin can paste URL even before enabling */}
              <div style={{ display: link.enabled || link.url ? 'block' : 'none' }}>
                <input
                  className="input"
                  style={{ marginBottom: 0, fontSize: 13 }}
                  placeholder={placeholder}
                  value={link.url || ''}
                  onChange={e => setUrl(key, e.target.value)}
                />
              </div>
              {!link.enabled && !link.url && (
                <button
                  onClick={() => toggle(key)}
                  style={{
                    marginTop: 8, background: 'none', border: 'none', cursor: 'pointer',
                    color: 'var(--text-3)', fontSize: 12, fontFamily: 'var(--font-display)',
                    fontWeight: 600, padding: 0,
                  }}
                >
                  + Add link
                </button>
              )}
            </div>
          );
        })}
      </div>

      <button className="btn btn-primary" onClick={save} disabled={saving} style={{ marginBottom: 30 }}>
        {saving
          ? <span className="spinner spinner-sm" />
          : <><Save size={15} style={{ display: 'inline', verticalAlign: 'middle', marginRight: 6 }} />Save Social Links</>
        }
      </button>
    </div>
  );
}

// ── Plans Editor ──────────────────────────────────────────────────────────────
const PLAN_PERKS = [
  { key: 'qr',           label: 'QR Code Payment',   icon: <Smartphone size={14} /> },
  { key: 'badge',        label: 'Premium Badge',      icon: <Medal size={14} color="var(--brand)" /> },
  { key: 'priority',     label: 'Priority Listing',   icon: <TrendingUp size={14} /> },
  { key: 'home_service', label: 'Home Service Option', icon: <span style={{ fontSize: 13 }}>🏠</span> },
];

function PlanTierCard({ tier, plan, color, onUpdate, onTogglePerk, defaultOpen }) {
  const [open, setOpen] = useState(!!defaultOpen);
  const activePerks = PLAN_PERKS.filter(p => plan[p.key]).length;

  return (
    <div className="card" style={{ marginBottom: 14, padding: 0, overflow: 'hidden', borderColor: color + '44' }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 12,
          padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
        }}
      >
        <div style={{ width: 10, height: 10, borderRadius: '50%', background: color, flexShrink: 0 }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15 }}>{plan.name}</div>
          <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 1 }}>
            Rs {Number(plan.price).toLocaleString()}/mo · {plan.photos} photo{plan.photos !== 1 ? 's' : ''} · {activePerks}/{PLAN_PERKS.length} perks
          </div>
        </div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
          style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.18s', flexShrink: 0 }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {open && (
        <div style={{ padding: '4px 16px 16px', borderTop: '1px solid var(--border)' }}>
          {/* Plan name */}
          <div className="input-group" style={{ marginTop: 14 }}>
            <label className="input-label">Display Name</label>
            <input className="input" value={plan.name}
              onChange={e => onUpdate(tier, 'name', e.target.value)} />
          </div>

          {/* Price + Photos side by side to save vertical space */}
          <div style={{ display: 'flex', gap: 10 }}>
            <div className="input-group" style={{ flex: 1 }}>
              <label className="input-label">Price (Rs/mo)</label>
              <input className="input" type="number" value={plan.price}
                onChange={e => onUpdate(tier, 'price', e.target.value)} />
            </div>
            <div className="input-group" style={{ flex: 1 }}>
              <label className="input-label">Max Photos</label>
              <input className="input" type="number" value={plan.photos}
                onChange={e => onUpdate(tier, 'photos', e.target.value)} />
            </div>
          </div>

          {/* Perks toggles */}
          <p style={{ fontSize: 12, fontWeight: 700, color: 'var(--text-2)', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10, marginTop: 4 }}>Perks</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {PLAN_PERKS.map(perk => (
              <div key={perk.key} onClick={() => onTogglePerk(tier, perk.key)}
                style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  padding: '10px 14px', borderRadius: 'var(--radius-sm)',
                  background: plan[perk.key] ? 'var(--brand-dim)' : 'var(--bg-input)',
                  border: `1.5px solid ${plan[perk.key] ? 'var(--brand)' : 'var(--border)'}`,
                  cursor: 'pointer', transition: 'all 0.2s',
                }}>
                <span style={{ fontSize: 14 }}>{perk.icon} {perk.label}</span>
                <div style={{
                  width: 40, height: 22, borderRadius: 11,
                  background: plan[perk.key] ? 'var(--brand)' : 'var(--border)',
                  position: 'relative', transition: 'background 0.2s', flexShrink: 0,
                }}>
                  <div style={{
                    position: 'absolute', top: 3,
                    left: plan[perk.key] ? 21 : 3,
                    width: 16, height: 16, borderRadius: '50%',
                    background: '#fff', transition: 'left 0.2s',
                  }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function PlansEditor({ plans, onSave, showToast }) {
  const [local, setLocal] = useState(plans);
  const [saving, setSaving] = useState(false);

  useEffect(() => { setLocal(plans); }, [plans]);

  const update = (tier, field, value) => {
    setLocal(prev => ({
      ...prev,
      [tier]: { ...prev[tier], [field]: field === 'price' ? parseInt(value) || 0 : field === 'photos' ? parseInt(value) || 0 : value }
    }));
  };

  const togglePerk = (tier, perk) => {
    setLocal(prev => ({
      ...prev,
      [tier]: { ...prev[tier], [perk]: !prev[tier][perk] }
    }));
  };

  const save = async () => {
    setSaving(true);
    await onSave(local);
    setSaving(false);
  };

  const tierColors = { basic: '#8EA0BC', pro: 'var(--brand)', premium: '#FFB800' };

  return (
    <div>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>
        Tap a plan to expand it. All plans save together.
      </p>

      {Object.entries(local).map(([tier, plan], i) => (
        <PlanTierCard
          key={tier}
          tier={tier}
          plan={plan}
          color={tierColors[tier]}
          onUpdate={update}
          onTogglePerk={togglePerk}
          defaultOpen={i === 0}
        />
      ))}

      <button className="btn btn-primary" onClick={save} disabled={saving} style={{ marginBottom: 30 }}>
        {saving ? <span className="spinner spinner-sm" /> : <><Save size={15} style={{display:'inline',verticalAlign:'middle',marginRight:6}} />Save Plans</>}
      </button>
    </div>
  );
}

// ── Settings Editor ───────────────────────────────────────────────────────────
// Extensible — any new feature just needs a new entry in SETTING_FIELDS
// or the admin can add a custom key at runtime
const SETTING_FIELDS = [
  {
    id: 'payment', section: 'Payment', color: '#10B981', icon: <DollarSign size={16} />,
    description: 'Accounts customers send manual payments to',
    fields: [
      { label: 'JazzCash Number',      key: 'jazzcash_number' },
      { label: 'JazzCash Account Name', key: 'jazzcash_name' },
      { label: 'Easypaisa Number',     key: 'easypaisa_number' },
      { label: 'Easypaisa Account Name', key: 'easypaisa_name' },
    ],
  },
  {
    id: 'wallet', section: 'Wallet & Credits', color: '#6366F1', icon: <Package size={16} />,
    description: 'Rules for the customer credit wallet',
    fields: [
      { label: 'Credits → Subscription Days Rate (Rs per day)', key: 'credits_to_sub_days_rate', type: 'number', hint: 'How many Rs of customer credits = 1 free subscription day for a barber. e.g. 100 means Rs 100 in credits = 1 day.' },
      { label: 'Minimum Send Amount (Rs)', key: 'wallet_min_send_amount', type: 'number', hint: 'Smallest amount a customer can send to a friend or pay a barber from their wallet. Applies to both flows.' },
    ],
  },
  {
    id: 'referrals', section: 'Referral Rewards', color: '#EC4899', icon: <Target size={16} />,
    description: '9 fields — how much each referral type earns',
    fields: [
      { label: 'Customer → Customer Credit (Rs)', key: 'referral_customer_credit', type: 'number', hint: 'Credit (Rs) both the referrer and referee earn when the referee completes their FIRST booking.' },
      { label: 'Referral Redeem Cooldown (Days)', key: 'referral_redeem_cooldown_days', type: 'number', hint: 'How many days must pass before a referrer\'s code can be redeemed by another new signup. Prevents bot/fake-account abuse.' },
      { label: 'Barber → Customer Credits', key: 'referral_barber_to_customer_days', type: 'number', hint: 'Flat free credits a barber earns when a customer signs up using their code. Paid immediately at signup.' },
      { label: 'Barber → Barber Credits (Basic)', key: 'referral_barber_to_barber_days_basic', type: 'number', hint: 'Free credits a barber earns when a referred barber buys the Basic plan.' },
      { label: 'Barber → Barber Credits (Pro)', key: 'referral_barber_to_barber_days_pro', type: 'number', hint: 'Free credits a barber earns when a referred barber buys the Pro plan.' },
      { label: 'Barber → Barber Credits (Premium)', key: 'referral_barber_to_barber_days_premium', type: 'number', hint: 'Free credits a barber earns when a referred barber buys the Premium plan.' },
      { label: 'Customer → Barber Credit (Rs, Basic)', key: 'referral_customer_to_barber_credit_basic', type: 'number', hint: 'Rs credit a customer earns when a referred barber buys the Basic plan.' },
      { label: 'Customer → Barber Credit (Rs, Pro)', key: 'referral_customer_to_barber_credit_pro', type: 'number', hint: 'Rs credit a customer earns when a referred barber buys the Pro plan.' },
      { label: 'Customer → Barber Credit (Rs, Premium)', key: 'referral_customer_to_barber_credit_premium', type: 'number', hint: 'Rs credit a customer earns when a referred barber buys the Premium plan.' },
    ],
  },
];

function SettingsSection({ section, settings, setSettings, defaultOpen }) {
  const [open, setOpen] = useState(!!defaultOpen);
  return (
    <div className="card" style={{ marginBottom: 14, padding: 0, overflow: 'hidden' }}>
      <button
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 12,
          padding: '14px 16px', background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
        }}
      >
        <div style={{
          width: 32, height: 32, borderRadius: 9, flexShrink: 0,
          background: section.color + '18', color: section.color,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {section.icon}
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14.5 }}>{section.section}</div>
          <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 1 }}>{section.description}</div>
        </div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
          style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.18s', flexShrink: 0 }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {open && (
        <div style={{ padding: '4px 16px 16px', borderTop: '1px solid var(--border)' }}>
          {section.fields.map(f => (
            <div key={f.key} className="input-group" style={{ marginTop: 14 }}>
              <label className="input-label">{f.label}</label>
              <input className="input" type={f.type || 'text'} value={settings[f.key] || ''}
                onChange={e => setSettings(p => ({ ...p, [f.key]: e.target.value }))} />
              {f.hint && <p style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 4, lineHeight: 1.5 }}>{f.hint}</p>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function SettingsEditor({ settings, setSettings, onSave, onAddCustom, showToast }) {
  const [newKey, setNewKey]     = useState('');
  const [newVal, setNewVal]     = useState('');
  const [saving, setSaving]     = useState(false);
  const [showAddCustom, setShowAddCustom] = useState(false);
  const [showSecurity, setShowSecurity]   = useState(false);

  const save = async () => {
    setSaving(true);
    await onSave();
    setSaving(false);
  };

  // Keys already shown in predefined sections
  const predefinedKeys = SETTING_FIELDS.flatMap(s => s.fields.map(f => f.key))
    .concat(['plans_config']);

  // Any extra keys from DB not in predefined list = custom settings
  const customKeys = Object.keys(settings).filter(k => !predefinedKeys.includes(k));

  return (
    <div>
      <p style={{ color: 'var(--text-2)', fontSize: 13, marginBottom: 16 }}>
        Tap a section to expand it. All sections save together.
      </p>

      {/* Predefined sections — collapsible cards, first one open by default */}
      {SETTING_FIELDS.map((section, i) => (
        <SettingsSection
          key={section.id}
          section={section}
          settings={settings}
          setSettings={setSettings}
          defaultOpen={i === 0}
        />
      ))}

      {/* Custom settings added at runtime */}
      {customKeys.length > 0 && (
        <div className="card" style={{ marginBottom: 14, padding: '14px 16px' }}>
          <p style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14.5, marginBottom: 12 }}>Custom Settings</p>
          {customKeys.map(key => (
            <div key={key} className="input-group">
              <label className="input-label" style={{ fontFamily: 'monospace', fontSize: 12 }}>{key}</label>
              <input className="input" value={settings[key] || ''}
                onChange={e => setSettings(p => ({ ...p, [key]: e.target.value }))} />
            </div>
          ))}
        </div>
      )}

      {/* Sticky-feeling primary save action for all the above */}
      <button className="btn btn-primary" onClick={save} disabled={saving} style={{ marginBottom: 24 }}>
        {saving ? <span className="spinner spinner-sm" /> : <><Save size={15} style={{display:'inline',verticalAlign:'middle',marginRight:6}} />Save All Settings</>}
      </button>

      {/* ── Add a new setting key — collapsed by default to reduce clutter ── */}
      <button
        onClick={() => setShowAddCustom(o => !o)}
        className="card"
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 10,
          padding: '12px 16px', marginBottom: 14, cursor: 'pointer',
          background: 'var(--bg-input)', border: '1.5px dashed var(--border)', textAlign: 'left',
        }}
      >
        <span style={{ fontSize: 16, color: 'var(--text-2)', fontWeight: 800 }}>+</span>
        <span style={{ flex: 1, fontSize: 13.5, fontWeight: 700, color: 'var(--text-2)' }}>Add a custom setting</span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
          style={{ transform: showAddCustom ? 'rotate(180deg)' : 'none', transition: 'transform 0.18s' }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {showAddCustom && (
        <div className="card" style={{ marginBottom: 24, padding: '16px' }}>
          <p style={{ fontSize: 12.5, color: 'var(--text-2)', marginBottom: 14 }}>
            For a one-off feature flag or config value. It will appear under "Custom Settings" above forever.
          </p>
          <div style={{ display: 'flex', gap: 10, marginBottom: 10 }}>
            <input className="input" placeholder="setting_key" value={newKey}
              onChange={e => setNewKey(e.target.value.toLowerCase().replace(/\s/g, '_'))} style={{ marginBottom: 0 }} />
            <input className="input" placeholder="value" value={newVal}
              onChange={e => setNewVal(e.target.value)} style={{ marginBottom: 0 }} />
          </div>
          <button className="btn btn-secondary" onClick={() => {
            if (!newKey) return showToast('error', 'Enter a key');
            onAddCustom(newKey, newVal);
            setNewKey(''); setNewVal('');
            setShowAddCustom(false);
            showToast('info', `Added "${newKey}" — save to persist`);
          }}>
            + Add Setting
          </button>
        </div>
      )}

      {/* ── Security: password + pattern — visually separated, collapsed by default ── */}
      <button
        onClick={() => setShowSecurity(o => !o)}
        style={{
          width: '100%', display: 'flex', alignItems: 'center', gap: 10,
          padding: '12px 4px', marginBottom: showSecurity ? 14 : 4, cursor: 'pointer',
          background: 'none', border: 'none', borderTop: '1px solid var(--border)',
          paddingTop: 20, textAlign: 'left',
        }}
      >
        <AlertTriangle size={16} color="var(--error)" />
        <span style={{ flex: 1, fontSize: 14, fontWeight: 800, color: 'var(--text-1)', fontFamily: 'var(--font-display)' }}>
          Security — Admin Login
        </span>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"
          style={{ transform: showSecurity ? 'rotate(180deg)' : 'none', transition: 'transform 0.18s' }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      {showSecurity && (
        <>
          <p style={{ fontSize: 12.5, color: 'var(--text-2)', marginBottom: 18 }}>
            This updates the password for your admin login account.
          </p>
          <div className="card" style={{ marginBottom: 14, padding: '16px' }}>
            <p className="section-label" style={{ fontSize: 14, marginBottom: 14 }}>Change Admin Password</p>
            <AdminPasswordChanger showToast={showToast} />
          </div>
        </>
      )}
    </div>
  );
}

// ── Password Changer ──────────────────────────────────────────────────────────
function AdminPasswordChanger({ showToast }) {
  const [newPass, setNewPass] = useState('');
  const [confirm, setConfirm] = useState('');
  const [saving, setSaving]   = useState(false);

  const save = async () => {
    if (newPass.length < 6) return showToast('error', 'Min 6 characters');
    if (newPass !== confirm) return showToast('error', 'Passwords do not match');
    setSaving(true);
    const { error: pwErr } = await supabase.auth.updateUser({ password: newPass });
    setSaving(false);
    if (pwErr) { console.error('[Auth] password update failed:', pwErr.message); showToast('error', 'Failed: ' + pwErr.message); return; }
    setNewPass(''); setConfirm('');
    showToast('success', 'Password updated');
  };

  return (
    <div style={{ marginBottom: 8 }}>
      <div className="input-group">
        <label className="input-label">New Password</label>
        <input className="input" type="password" placeholder="Min 6 characters"
          value={newPass} onChange={e => setNewPass(e.target.value)} />
      </div>
      <div className="input-group">
        <label className="input-label">Confirm Password</label>
        <input className="input" type="password" placeholder="Repeat password"
          value={confirm} onChange={e => setConfirm(e.target.value)} />
      </div>
      <button className="btn btn-secondary" onClick={save} disabled={saving}>
        {saving ? <span className="spinner spinner-sm" /> : 'Update Password'}
      </button>
    </div>
  );
}
