import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './hooks/useAuth';
import { warmupDb } from './lib/supabase';
import useTheme from './hooks/useTheme';
import './styles/global.css';
import { ErrorBoundary } from './ErrorBoundary';

import BottomNav      from './components/BottomNav';
import MobileDownloadBanner from './components/MobileDownloadBanner';
import SupportChat     from './components/SupportChat';
import Home           from './pages/Home';
import Explore        from './pages/Explore';
import ShopDetail     from './pages/ShopDetail';
import Login          from './pages/Login';
import AuthCallback   from './pages/AuthCallback';
import Register       from './pages/Register';
import Account        from './pages/Account';
import AdminPortal    from './pages/AdminPortal';
import Download       from './pages/Download';
import InviteFriends  from './pages/InviteFriends';
import CustomerWallet from './pages/CustomerWallet';

warmupDb();

function AppRoutes() {
  const { user } = useAuth();
  return (
    <>
      <Routes>
        <Route path="/"          element={<ErrorBoundary name="Home"><Home /></ErrorBoundary>} />
        <Route path="/explore"   element={<ErrorBoundary name="Explore"><Explore /></ErrorBoundary>} />
        <Route path="/shop/:id"  element={<ErrorBoundary name="ShopDetail"><ShopDetail /></ErrorBoundary>} />
        <Route path="/login"     element={<ErrorBoundary name="Login"><Login /></ErrorBoundary>} />
        <Route path="/auth/callback" element={<ErrorBoundary name="AuthCallback"><AuthCallback /></ErrorBoundary>} />
        <Route path="/register"  element={<ErrorBoundary name="Register"><Register /></ErrorBoundary>} />
        <Route path="/account"   element={<ErrorBoundary name="Account"><Account /></ErrorBoundary>} />
        <Route path="/invite"    element={<ErrorBoundary name="InviteFriends"><InviteFriends /></ErrorBoundary>} />
        <Route path="/wallet"    element={<ErrorBoundary name="CustomerWallet"><CustomerWallet /></ErrorBoundary>} />
        <Route path="/admin"     element={<ErrorBoundary name="AdminPortal"><AdminPortal /></ErrorBoundary>} />
        <Route path="/bookings"  element={<Navigate to="/account" replace />} />
        <Route path="/download"  element={<ErrorBoundary name="Download"><Download /></ErrorBoundary>} />
        <Route path="*"          element={<Navigate to="/" replace />} />
      </Routes>
      <ErrorBoundary name="BottomNav"><BottomNav /></ErrorBoundary>
      <ErrorBoundary name="MobileDownloadBanner"><MobileDownloadBanner /></ErrorBoundary>
      <ErrorBoundary name="SupportChat"><SupportChat /></ErrorBoundary>
    </>
  );
}

export default function App() {
  useTheme(); // applies + keeps data-theme in sync across the whole app
  return (
    <ErrorBoundary name="AuthProvider+Router">
      <BrowserRouter>
        <AuthProvider>
          <AppRoutes />
        </AuthProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}
