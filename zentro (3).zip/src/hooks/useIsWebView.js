// useIsWebView — returns true when running inside the Appilix WebView APK
// Detection (checked in order): URL param ?apk=1  →  window.Android bridge object
// (injected by Appilix)  →  user-agent contains "Appilix" or the WebView "wv)" signature.
// This is the single source of truth — other files should import this instead of
// re-implementing their own UA check, so behavior never drifts out of sync again.

let _cached = null;

export default function useIsWebView() {
  if (_cached !== null) return _cached;

  const params = new URLSearchParams(window.location.search);
  if (params.get('apk') === '1') { _cached = true; return true; }

  if (typeof window.Android !== 'undefined') { _cached = true; return true; }

  const ua = navigator.userAgent || '';
  // Appilix injects its own UA string; also match the classic Android WebView signature.
  // Note: newer Android WebViews sometimes drop the "wv)" token, so this isn't 100%
  // reliable on its own — the ?apk=1 param (set in the Appilix app's configured URL)
  // is the most reliable signal and is checked first.
  if (/Appilix|wv\)/.test(ua)) { _cached = true; return true; }

  _cached = false;
  return false;
}
