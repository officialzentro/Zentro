import { useState, useEffect, useCallback } from 'react';

// ── Shared theme hook ───────────────────────────────────────────────────────
// Modes: 'system' (default, follows OS/browser preference live), 'light', 'dark'.
// Persists the user's chosen mode in localStorage; applies data-theme on <html>.
// Usage: const { mode, resolved, setMode } = useTheme();

const STORAGE_KEY = 'zentro_theme'; // 'system' | 'light' | 'dark'

function getSystemPref() {
  if (typeof window === 'undefined' || !window.matchMedia) return 'light';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

function resolveTheme(mode) {
  return mode === 'system' ? getSystemPref() : mode;
}

function applyTheme(resolved) {
  document.documentElement.setAttribute('data-theme', resolved);
}

export default function useTheme() {
  const [mode, setModeState] = useState(() => localStorage.getItem(STORAGE_KEY) || 'system');
  const [resolved, setResolved] = useState(() => resolveTheme(mode));

  // Apply immediately on mount and whenever mode changes
  useEffect(() => {
    const r = resolveTheme(mode);
    setResolved(r);
    applyTheme(r);
  }, [mode]);

  // While in 'system' mode, follow live OS theme changes
  useEffect(() => {
    if (mode !== 'system' || !window.matchMedia) return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = () => {
      const r = getSystemPref();
      setResolved(r);
      applyTheme(r);
    };
    mq.addEventListener('change', handler);
    return () => mq.removeEventListener('change', handler);
  }, [mode]);

  const setMode = useCallback((next) => {
    setModeState(next);
    localStorage.setItem(STORAGE_KEY, next);
  }, []);

  return { mode, resolved, setMode };
}
