import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { enablePush, getPushStatus, sendPush, pushConfigured } from '../lib/push';

// Settings row: shows if notifications are on for this phone, and lets the user turn them on.
export default function PushSettingRow({ bare = false }) {
  const { user } = useAuth();
  const [status, setStatus] = useState('loading');
  const [sent, setSent] = useState(false);

  const refresh = useCallback(() => { getPushStatus().then(setStatus); }, []);
  useEffect(() => { refresh(); }, [refresh]);

  if (!pushConfigured || status === 'unsupported') return null;

  const turnOn = () => {
    enablePush();
    setTimeout(refresh, 2500);
    setTimeout(refresh, 6000);
  };
  const test = async () => {
    setSent(true);
    await sendPush(user?.id, { title: 'Zentro test', body: 'Notifications are working on this phone.' });
    setTimeout(() => setSent(false), 4000);
  };

  const text = {
    loading: 'Checking…',
    on: 'On. You will get booking alerts.',
    off: 'Off. Tap Turn on to get booking alerts.',
    blocked: 'Blocked. Open phone Settings, Apps, Zentro (or Chrome), Notifications and allow them.',
  }[status];

  const btn = { border: 'none', borderRadius: 8, padding: '7px 12px', fontSize: 12, fontWeight: 700, cursor: 'pointer', fontFamily: 'var(--font-display)' };
  const inner = (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 10 }}>
      <div style={{ minWidth: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 13.5 }}>Notifications</div>
        <div style={{ fontSize: 11.5, color: status === 'on' ? 'var(--success, #16a34a)' : 'var(--text-3)', marginTop: 2 }}>{text}</div>
      </div>
      {status === 'off' && <button onClick={turnOn} style={{ ...btn, background: 'var(--brand)', color: '#fff' }}>Turn on</button>}
      {status === 'on' && <button onClick={test} disabled={sent} style={{ ...btn, background: 'var(--bg-input)', color: 'var(--brand)' }}>{sent ? 'Sent' : 'Send test'}</button>}
    </div>
  );
  if (bare) return <div style={{ padding: '14px 0', borderBottom: '1px solid var(--border)' }}>{inner}</div>;
  return <div className="card fade-up" style={{ marginBottom: 18, padding: '14px 16px' }}>{inner}</div>;
}
