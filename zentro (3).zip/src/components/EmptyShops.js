import { useState } from 'react';
import { copyToClipboard } from '../lib/referrals';

// ── Empty state for shop lists ─────────────────────────────────────────────────
// Two cases, both with a real next step (no dead ends):
//  1. No search: no shops are registered yet. CTA: ask a nearby barber to register.
//  2. With search: nothing matched. CTA: clear the search, plus "can't find your
//     barber?" so a missing shop turns into a new registration.
// The CTA opens WhatsApp (plain link, works inside the APK WebView) with a ready
// message + the register link, and offers a Copy fallback.

export default function EmptyShops({ search, onClear }) {
  const lang = localStorage.getItem('zentro_lang') || 'en';
  const ur = lang === 'ur';
  const [copied, setCopied] = useState(false);

  const link = `${window.location.origin}/register`;
  const message = ur
    ? `Bhai, apni barber shop Zentro par register karo — customers online slot book kar sakenge. Yahan register karo: ${link}`
    : `Hey! Register your barbershop on Zentro so customers can book slots online: ${link}`;
  const waHref = `https://wa.me/?text=${encodeURIComponent(message)}`;

  const copy = async () => {
    const ok = await copyToClipboard(message);
    if (ok) { setCopied(true); setTimeout(() => setCopied(false), 2000); }
  };

  const T = search ? {
    title: ur ? `"${search}" se koi shop nahi mila` : `No shops match "${search}"`,
    sub:   ur ? 'Alag naam ya shehar try karo' : 'Try a different name or city',
    ask:   ur ? 'Apna barber nahi mila?' : "Can't find your barber?",
    askSub: ur ? 'Usay Zentro par register karne ko kaho.' : 'Ask them to register on Zentro.',
  } : {
    title: ur ? 'Abhi koi shop registered nahi' : 'No shops on Zentro yet',
    sub:   ur ? 'Aapke area mein abhi koi barber Zentro par nahi hai. Apne qareebi barber ko register karne ko kaho — pehle wo hi online booking shuru karega.'
              : "There are no barbers listed here yet. Ask your nearby barber to register and be the first to take bookings online.",
    ask: null,
  };

  const Btn = ({ children, ...p }) => (
    <a {...p} style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      padding: '13px 18px', borderRadius: 14, textDecoration: 'none', cursor: 'pointer',
      background: '#25D366', color: '#fff', fontFamily: 'var(--font-display)',
      fontWeight: 800, fontSize: 14, border: 'none', ...(p.style || {}),
    }}>{children}</a>
  );

  return (
    <div style={{ textAlign: 'center', padding: '40px 8px 28px' }}>
      <div style={{
        width: 72, height: 72, borderRadius: 24, margin: '0 auto 16px',
        background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>
        <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
          <line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>
        </svg>
      </div>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 19, color: 'var(--text-1)', marginBottom: 8 }}>{T.title}</div>
      <div style={{ color: 'var(--text-2)', fontSize: 14, lineHeight: 1.6, maxWidth: 290, margin: '0 auto 22px' }}>{T.sub}</div>

      {search && (
        <button onClick={onClear} style={{
          padding: '11px 20px', borderRadius: 12, border: '1.5px solid var(--border)',
          background: 'var(--bg-input)', color: 'var(--brand)', cursor: 'pointer',
          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, marginBottom: 26,
        }}>{ur ? 'Search saaf karo' : 'Clear search'}</button>
      )}

      {T.ask && (
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13, color: 'var(--text-1)' }}>{T.ask}</div>
      )}
      {T.askSub && (
        <div style={{ fontSize: 12.5, color: 'var(--text-3)', margin: '2px 0 12px' }}>{T.askSub}</div>
      )}

      <div style={{ maxWidth: 300, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 10 }}>
        <Btn href={waHref} target="_blank" rel="noopener noreferrer">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M17.5 14.4c-.3-.1-1.7-.8-1.9-.9-.3-.1-.5-.1-.7.1-.2.3-.8.9-.9 1.1-.2.2-.3.2-.6.1-.3-.1-1.2-.4-2.3-1.4-.8-.8-1.4-1.7-1.6-2-.2-.3 0-.4.1-.6l.4-.5c.1-.2.2-.3.3-.5.1-.2 0-.4 0-.5-.1-.1-.7-1.6-.9-2.2-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1 1-1 2.5s1.1 2.9 1.2 3.1c.1.2 2.1 3.2 5.1 4.5 3 1.2 3 .8 3.6.8.6-.1 1.8-.7 2-1.4.3-.7.3-1.3.2-1.4-.1-.1-.3-.2-.6-.3zM12 2a10 10 0 0 0-8.6 15L2 22l5.2-1.4A10 10 0 1 0 12 2z"/></svg>
          {ur ? 'Apne nearby barber ko register karne ko kaho' : 'Ask my nearby barber to register'}
        </Btn>
        <button onClick={copy} style={{
          padding: '11px 18px', borderRadius: 12, border: '1.5px solid var(--border)',
          background: 'var(--bg-input)', color: 'var(--text-2)', cursor: 'pointer',
          fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 12.5,
        }}>{copied ? (
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
            {ur ? 'Copy ho gaya' : 'Copied'}
          </span>
        ) : (ur ? 'Message copy karo' : 'Copy message instead')}</button>
      </div>
    </div>
  );
}
