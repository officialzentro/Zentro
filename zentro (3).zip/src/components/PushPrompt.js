import { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { enablePush, pushConfigured } from '../lib/push';
import useLang from '../hooks/useLang';

const KEY = 'zentro_push_dismissed_at';
const DAY = 86400000;

// Small banner that asks the user to turn on notifications with one tap.
// Barbers are asked again every 2 days (a missed booking costs them money),
// everyone else every 7 days. It never shows once notifications are on or blocked.
export default function PushPrompt() {
  const { user, profile } = useAuth();
  const { tr } = useLang();
  const [show, setShow] = useState(false);
  const isBarber = profile?.role === 'barber';

  useEffect(() => {
    if (!pushConfigured || !user || typeof Notification === 'undefined') return setShow(false);
    if (Notification.permission !== 'default') return setShow(false);
    let at = 0;
    try {
      at = Number(localStorage.getItem(KEY)) || 0;
      if (!at && localStorage.getItem('zentro_push_dismissed') === '1') {
        at = Date.now(); // the older "dismissed" setting counts as dismissed today
        localStorage.setItem(KEY, String(at));
      }
    } catch (e) { /* ignore */ }
    const wait = (isBarber ? 2 : 7) * DAY;
    setShow(!at || Date.now() - at > wait);
  }, [user, isBarber]);

  if (!show) return null;

  const turnOn = () => {
    enablePush();
    setShow(false);
  };
  const later = () => {
    try { localStorage.setItem(KEY, String(Date.now())); } catch (e) { /* ignore */ }
    setShow(false);
  };

  return (
    <div style={{
      position: 'fixed', left: 12, right: 12, top: 'calc(env(safe-area-inset-top, 0px) + 12px)', zIndex: 3000,
      background: 'var(--bg-card)', border: '1px solid var(--border)', borderRadius: 14,
      padding: '12px 14px', display: 'flex', alignItems: 'center', gap: 10,
      boxShadow: '0 8px 24px rgba(0,0,0,0.18)', maxWidth: 480, margin: '0 auto',
    }}>
      <div style={{ flex: 1, fontSize: 13, color: 'var(--text-1)', fontWeight: 600, lineHeight: 1.4 }}>
        {isBarber
          ? tr('Turn on notifications so you never miss a new booking', 'Notifications on karo taake koi nayi booking miss na ho')
          : tr('Turn on notifications for booking updates and reminders', 'Booking updates aur reminders ke liye notifications on karo')}
      </div>
      <button onClick={later} style={{ background: 'none', border: 'none', color: 'var(--text-3)', fontSize: 12, cursor: 'pointer' }}>{tr('Later', 'Baad mein')}</button>
      <button className="btn btn-primary btn-sm" onClick={turnOn}>{tr('Turn on', 'On karo')}</button>
    </div>
  );
}
