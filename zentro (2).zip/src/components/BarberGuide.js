// BarberGuide — permanent in-app guide for barbers
// Plans Comparison table is synced live from admin app_settings (plans_config)

import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

// ── Brand-safe SVG icons ───────────────────────────────────────────────────────
const CheckIcon = () => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2.5" strokeLinecap="round">
    <polyline points="20 6 9 17 4 12"/>
  </svg>
);

const ChevronIcon = ({ open }) => (
  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2.5" strokeLinecap="round"
    style={{ transition: 'transform 0.25s', transform: open ? 'rotate(180deg)' : 'rotate(0deg)', flexShrink: 0 }}>
    <polyline points="6 9 12 15 18 9"/>
  </svg>
);

const GUIDE_SECTIONS = [
  {
    title: 'Home Screen Kaise Chalti Hai',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/>
        <rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
      </svg>
    ),
    steps: [
      'Sabse upar apni shop ka naam hai. Uske saath chat icon (support) aur bell (notifications) hain',
      'Neeche Today box mein aaj ki bookings, andaza shuda kamai aur plan ke bache hue din nazar aate hain',
      'Quick actions mein 4 buttons hain: Manage Slots, Bookings, My QR Code aur Payments',
      '"More" dabao to Shop Setup, Refer a Barber, Setup Guide aur Settings khul jaate hain',
      'Sabse neeche Recent activity mein aakhri 2 bookings dikhti hain',
    ],
  },
  {
    title: 'Shop Setup (Sabse Pehle)',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
        <polyline points="9 22 9 12 15 12 15 22"/>
      </svg>
    ),
    steps: [
      'Barber account banate hi Shop Setup khud khul jaata hai. Baad mein: Home → More → Shop Setup',
      'Basic Info mein Shop Name, City aur Address zaroor likho. Phone aur description bhi daal do',
      '"Serves" mein Men, Women ya Both chuno',
      '"Pin Your Shop" mein map par apni shop ki exact location lagao (ya phone ki location use karo)',
      'Services mein "+ Add Service" dabao aur kam az kam 1 service add karo (naam + price)',
      'Achi photos upload karo. Photos ki limit aap ke plan par hai',
      'Save karo. Admin approve karega to shop live ho jayegi (tab tak "Pending admin approval" dikhega)',
    ],
  },
  {
    title: 'Time Slots',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
      </svg>
    ),
    steps: [
      'Home → Manage Slots kholo',
      'Start aur End time chuno (jitne ghante kaam karna hai)',
      'Interval chuno, jaise 30 min',
      '"Days Ahead" mein chuno ke kitne din aage ke slots banane hain',
      '"Generate Slots" dabao. Customers ab yeh slots book kar sakte hain',
      '"Clear Free" sirf khali slots hata deta hai. Booked slots nahi hatte',
    ],
  },
  {
    title: 'Plan aur Payment',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
        <line x1="1" y1="10" x2="23" y2="10"/>
      </svg>
    ),
    steps: [
      'Home → Payments kholo',
      'Basic plan bilkul free hai: "Activate Free Plan" dabao. Payment ki zaroorat nahi, bas admin approval chahiye',
      'Pro ya Premium ke liye "Choose a Plan" mein plan chuno',
      'JazzCash ya Easypaisa number copy karo aur amount bhej do',
      'Transaction ID likho aur payment ka screenshot upload karo',
      '"Submit Payment Proof" dabao. Admin approve karega to plan active ho jayega',
      'Neeche Payment History mein purani payments dikhti hain',
    ],
  },
  {
    title: 'Bookings Manage Karo',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
        <line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/>
        <line x1="3" y1="10" x2="21" y2="10"/>
      </svg>
    ),
    steps: [
      'Home → Bookings kholo. Upar Today, Upcoming, Past aur All tabs hain',
      'Nayi booking "Pending" hoti hai: Confirm ya Cancel dabao',
      'Customer aa jaye aur kaam ho jaye to "Mark Complete" dabao',
      'Cancel karne par woh slot dobara free ho jata hai',
      'Nayi booking aati hai to bell icon par notification milti hai',
    ],
  },
  {
    title: 'QR Code',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>
        <path d="M14 14h3v3h-3zM20 14v3M14 20h3M20 20v1"/>
      </svg>
    ),
    steps: [
      'Home → My QR Code dabao. Bookings screen par bhi sabse upar "My Shop QR Code" card hai',
      '"Show QR" dabao to aap ka QR khul jayega',
      '"Download QR" se poster save karo aur print karwa lo',
      'Poster shop ke sheeshe ya counter par lagao. Customer scan karke seedha aap ki shop khol leta hai',
      'QR Code Pro aur Premium plan mein milta hai',
    ],
  },
  {
    title: 'Refer & Earn',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="20 12 20 22 4 22 4 12"/>
        <rect x="2" y="7" width="20" height="5"/>
        <line x1="12" y1="22" x2="12" y2="7"/>
        <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/>
        <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
      </svg>
    ),
    steps: [
      'Home → More → Refer a Barber kholo. Wahan aap ka apna code hai ("Your Code")',
      'Code ya invite link dusre barbers ko share karo',
      'Jab woh register kar ke paid plan le aur admin approve kare, to aap ko reward milta hai',
      'Reward Zentro credits hote hain. Plan tier ke hisaab se amount admin set karta hai',
      'Credits Payments screen par "Use discount" se agle plan mein kaam aate hain',
    ],
  },
  {
    title: 'Madad Chahiye?',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
    ),
    steps: [
      'Home screen par upar bell ke saath chat icon hai. Usay dabao',
      'Apna masla likho. Zentro team chat mein jawab degi',
      'Jawab aane par notification milti hai',
    ],
  },
  {
    title: 'Pro Tips',
    icon: (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFB800" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
      </svg>
    ),
    steps: [
      'Achi photos lagate ho to zyada bookings milti hain',
      'Slots har roz update karo. Customers active shops prefer karte hain',
      'Premium plan par priority listing milti hai, yani zyada nazar aate ho',
      'QR poster shop par lagao. Walk-in customers bhi seedha book kar lete hain',
      'Har booking jaldi confirm karo. Cancel hui bookings rating par asar daalti hain',
    ],
  },
];

// Plans comparison — loaded live from admin settings
function PlansComparisonSection({ plansConfig }) {
  if (!plansConfig) {
    return <div className="skeleton" style={{ height: 160, borderRadius: 12 }} />;
  }

  const tiers = ['basic', 'pro', 'premium'];
  const tierColors = { basic: '#8EA0BC', pro: '#0080FF', premium: '#FFB800' };

  const rows = [
    { feature: 'Monthly Price',    getValue: (t) => (plansConfig[t]?.price === 0 ? 'Free' : `Rs ${plansConfig[t]?.price?.toLocaleString() || '—'}`) },
    { feature: 'Photos Upload',    getValue: (t) => `${plansConfig[t]?.photos ?? '—'}` },
    { feature: 'QR Code',          getValue: (t) => plansConfig[t]?.qr       ? true : '—' },
    { feature: 'Priority Listing', getValue: (t) => plansConfig[t]?.priority  ? true : '—' },
    { feature: 'Premium Badge',    getValue: (t) => plansConfig[t]?.badge     ? true : '—' },
  ];

  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
        <thead>
          <tr>
            {['Feature', ...tiers.map(t => plansConfig[t]?.name || t)].map((h, i) => (
              <th key={h} style={{
                padding: '8px 6px', textAlign: i === 0 ? 'left' : 'center',
                fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 11,
                color: i === 0 ? 'var(--text-3)' : Object.values(tierColors)[i - 1],
                borderBottom: '1.5px solid var(--border)',
                textTransform: 'uppercase', letterSpacing: 0.5,
              }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              <td style={{ padding: '9px 6px', color: 'var(--text-2)', fontWeight: 600, borderBottom: '1px solid var(--border)' }}>
                {row.feature}
              </td>
              {tiers.map((t, j) => {
                const val = row.getValue(t);
                return (
                  <td key={t} style={{
                    padding: '9px 6px', textAlign: 'center',
                    color: val === '—' ? 'var(--text-3)' : val === true ? 'var(--brand)' : 'var(--text-1)',
                    fontWeight: 700, borderBottom: '1px solid var(--border)',
                  }}>{val === true ? <CheckIcon /> : val}</td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      <p style={{ fontSize: 11, color: 'var(--text-3)', marginTop: 10, fontStyle: 'italic' }}>
        Prices may be updated by admin — always check Payment tab for latest.
      </p>
    </div>
  );
}

function GuideSection({ section, plansConfig }) {
  const [open, setOpen] = useState(false);

  return (
    <div style={{
      borderRadius: 16, overflow: 'hidden',
      border: `1.5px solid ${open ? 'var(--border-brand)' : 'var(--border)'}`,
      background: 'var(--bg-card)', marginBottom: 10,
      transition: 'border-color 0.2s',
    }}>
      <button
        className="tap-feedback"
        onClick={() => setOpen(o => !o)}
        style={{
          width: '100%', background: 'none', border: 'none', cursor: 'pointer',
          padding: '14px 16px',
          display: 'flex', alignItems: 'center', gap: 12, textAlign: 'left',
          color: 'var(--text-1)',
        }}
      >
        <div style={{
          width: 38, height: 38, borderRadius: 12, flexShrink: 0,
          background: 'var(--brand-glow)', border: '1px solid var(--border-brand)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          {section.icon}
        </div>
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, flex: 1 }}>
          {section.title}
        </span>
        <ChevronIcon open={open} />
      </button>

      {open && (
        <div className="fade-up" style={{ padding: '0 16px 16px' }}>
          {section.isPlans ? (
            <PlansComparisonSection plansConfig={plansConfig} />
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, paddingTop: 4 }}>
              {section.steps.map((step, i) => (
                <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: 7, flexShrink: 0,
                    background: 'var(--brand-glow)', border: '1px solid var(--border-brand)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    marginTop: 1,
                  }}>
                    <span style={{ fontSize: 10, fontFamily: 'var(--font-display)', fontWeight: 800, color: 'var(--brand)' }}>{i + 1}</span>
                  </div>
                  <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.55, fontFamily: 'var(--font-display)', fontWeight: 500, flex: 1 }}>
                    {step}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function BarberGuide() {
  const [plansConfig, setPlansConfig] = useState(null);

  useEffect(() => {
    // Load plans_config live from admin settings
    supabase.from('app_settings').select('value').eq('key', 'plans_config').maybeSingle()
      .then(({ data }) => {
        if (data?.value) {
          try { setPlansConfig(JSON.parse(data.value)); } catch {}
        } else {
          // fallback defaults
          setPlansConfig({
            basic:   { name: 'Basic',   price: 0,    photos: 3,  qr: false, badge: false, priority: false },
            pro:     { name: 'Pro',     price: 1999, photos: 10, qr: true,  badge: false, priority: true  },
            premium: { name: 'Premium', price: 3499, photos: 30, qr: true,  badge: true,  priority: true  },
          });
        }
      });
  }, []);

  // Build sections list — insert Plans Comparison after Pro Tips
  const allSections = [
    ...GUIDE_SECTIONS,
    {
      title: 'Plans Comparison',
      icon: (
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--brand)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="12" y1="20" x2="12" y2="10"/>
          <line x1="18" y1="20" x2="18" y2="4"/>
          <line x1="6" y1="20" x2="6" y2="16"/>
        </svg>
      ),
      isPlans: true,
    },
  ];

  return (
    <div>
      <div style={{ marginBottom: 20 }}>
        <p style={{ fontSize: 11, fontWeight: 800, letterSpacing: 1.2, textTransform: 'uppercase', color: 'var(--brand)', marginBottom: 4, fontFamily: 'var(--font-display)' }}>
          Barber Guide
        </p>
        <h2 style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: 'var(--text-1)', marginBottom: 6 }}>
          Sab Kuch Seekho
        </h2>
        <p style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.5, fontFamily: 'var(--font-display)' }}>
          Neeche har section tap karo. Har cheez step-by-step likhi hai.
        </p>
      </div>

      {allSections.map((section, i) => (
        <GuideSection key={i} section={section} plansConfig={plansConfig} />
      ))}

      <div style={{ height: 20 }} />
    </div>
  );
}
