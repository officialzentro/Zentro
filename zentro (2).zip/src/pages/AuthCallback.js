import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { User, Scissors } from '../lib/icons';

export default function AuthCallback() {
  const navigate = useNavigate();
  const [stage, setStage]   = useState('checking'); // checking | needsInfo | saving
  const [userId, setUserId] = useState(null);
  const [form, setForm]     = useState({ full_name: '', phone: '' });
  const [role, setRole]     = useState(''); // customer | barber (must be chosen)
  const [error, setError]   = useState('');

  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.user) return navigate('/login', { replace: true });

      const { data: prof } = await supabase
        .from('profiles')
        .select('id, full_name, phone')
        .eq('id', session.user.id)
        .maybeSingle();

      if (prof) return navigate('/', { replace: true }); // existing user, straight in

      // New Google sign-in — no profile yet. Pre-fill name from Google, ask to confirm/complete.
      const meta = session.user.user_metadata || {};
      setUserId(session.user.id);
      setForm({ full_name: meta.full_name || meta.name || '', phone: '' });
      setStage('needsInfo');
    })();
  }, []); // eslint-disable-line

  const finishSetup = async () => {
    if (!role) return setError('Please choose how you will use Zentro');
    if (!form.full_name.trim()) return setError('Please enter your name');
    setError('');
    setStage('saving');
    const { data: { session } } = await supabase.auth.getSession();
    const { error: insertError } = await supabase.from('profiles').insert({
      id: userId,
      full_name: form.full_name.trim(),
      phone: form.phone.trim(),
      email: session?.user?.email,
      role,
    });
    if (insertError) {
      setStage('needsInfo');
      return setError('Could not save your details. Please try again.');
    }
    // New barbers go straight to the account page, which opens Shop Setup first
    navigate(role === 'barber' ? '/account' : '/', { replace: true });
  };

  if (stage === 'checking' || stage === 'saving') {
    return <div className="loading-screen"><div className="spinner" /></div>;
  }

  return (
    <div style={{ minHeight: '100dvh', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '40px 24px', maxWidth: 480, margin: '0 auto' }}>
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 28, marginBottom: 8 }}>
          Almost there
        </div>
        <p style={{ color: 'var(--text-2)', fontSize: 14 }}>Confirm your details to finish setting up your account.</p>
      </div>

      <div style={{ marginBottom: 20 }}>
        <div className="input-label" style={{ marginBottom: 8 }}>How will you use Zentro?</div>
        <div style={{ display: 'flex', gap: 8 }}>
          {[
            { value: 'customer', label: 'Book a barber', icon: <User size={16} /> },
            { value: 'barber',   label: 'I own a shop', icon: <Scissors size={16} /> },
          ].map(r => (
            <button key={r.value} onClick={() => { setRole(r.value); setError(''); }} style={{
              flex: 1, padding: '12px', borderRadius: 14,
              border: `1.5px solid ${role === r.value ? 'var(--brand)' : 'var(--border-strong)'}`,
              background: role === r.value ? 'var(--brand-glow)' : 'var(--bg-input)',
              color: role === r.value ? 'var(--brand)' : 'var(--text-2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
              fontFamily: 'var(--font-display)', fontWeight: 700, cursor: 'pointer', fontSize: 14,
            }}>
              {r.icon} {r.label}
            </button>
          ))}
        </div>
      </div>

      <div className="input-group">
        <label className="input-label">Full Name</label>
        <input className="input" value={form.full_name}
          onChange={e => setForm(p => ({ ...p, full_name: e.target.value }))} />
      </div>
      <div className="input-group">
        <label className="input-label">Phone (optional)</label>
        <input className="input" type="tel" placeholder="03xxxxxxxxx" value={form.phone}
          onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} />
      </div>

      {error && <p style={{ color: 'var(--error)', fontSize: 13, marginBottom: 12 }}>{error}</p>}

      <button className="btn btn-primary" onClick={finishSetup} style={{ marginTop: 8 }}>
        Continue
      </button>
    </div>
  );
}
