import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { usePlanPerks } from '../hooks/usePlanPerks';
import { format } from 'date-fns';
import { getOrCreateReferralCode, buildInviteLink, copyToClipboard, fetchMyReferrals, fetchMyCredits } from '../lib/referrals';

// ── Brand-safe SVG icon set ────────────────────────────────────────────────────
const Ico = {
  scissors: (c='var(--brand)', s=18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
      <line x1="20" y1="4" x2="8.12" y2="15.88"/>
      <line x1="14.47" y1="14.48" x2="20" y2="20"/>
      <line x1="8.12" y1="8.12" x2="12" y2="12"/>
    </svg>
  ),
  calendar: (c='var(--brand)', s=18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
      <line x1="16" y1="2" x2="16" y2="6"/>
      <line x1="8" y1="2" x2="8" y2="6"/>
      <line x1="3" y1="10" x2="21" y2="10"/>
    </svg>
  ),
  barChart: (c='var(--brand)', s=18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <line x1="18" y1="20" x2="18" y2="10"/>
      <line x1="12" y1="20" x2="12" y2="4"/>
      <line x1="6" y1="20" x2="6" y2="14"/>
      <line x1="2" y1="20" x2="22" y2="20"/>
    </svg>
  ),
  checkCircle: (c='var(--success)', s=18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
      <polyline points="22 4 12 14.01 9 11.01"/>
    </svg>
  ),
  clock: (c='var(--brand)', s=15) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/>
      <polyline points="12 6 12 12 16 14"/>
    </svg>
  ),
  gear: (c='currentColor', s=15) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="3"/>
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
    </svg>
  ),
  users: (c='var(--brand)', s=18) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
      <circle cx="9" cy="7" r="4"/>
      <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
      <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
    </svg>
  ),
  share: (c='#fff', s=16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/>
      <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/>
      <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>
    </svg>
  ),
  copy: (c='#fff', s=15) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
      <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
    </svg>
  ),
  check: (c='#fff', s=15) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12"/>
    </svg>
  ),
  gift: (c='var(--brand)', s=20) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 12 20 22 4 22 4 12"/>
      <rect x="2" y="7" width="20" height="5"/>
      <line x1="12" y1="22" x2="12" y2="7"/>
      <path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/>
      <path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>
    </svg>
  ),
  timer: (c='#CC8E00', s=16) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="9"/>
      <polyline points="12 6 12 12 16 14"/>
      <polyline points="9 1 12 1 15 1"/>
    </svg>
  ),
  razorBlade: (c='#8EA0BC', s=22) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 2l20 20M2 22 12 12 22 2"/>
      <path d="M7 7l10 10"/>
    </svg>
  ),
  zap: (c='var(--brand)', s=22) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
    </svg>
  ),
  crown: (c='#FFB800', s=22) => (
    <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 4l5 8 5-6 5 6 5-8v14H2z"/>
    </svg>
  ),
};

const PLAN_ICONS = {
  basic:   Ico.razorBlade(),
  pro:     Ico.zap(),
  premium: Ico.crown(),
};

function SubCountdown({ expiresAt }) {
  if (!expiresAt) return null;
  const exp  = new Date(expiresAt);
  const now  = new Date();
  const diff = exp - now;
  const expired = diff <= 0;
  const days = expired ? 0 : Math.ceil(diff / (1000 * 60 * 60 * 24));
  const isUrgent = !expired && days <= 7;

  return (
    <div style={{
      marginTop: 12, padding: '10px 14px', borderRadius: 10,
      background: expired ? 'rgba(255,59,59,0.08)' : isUrgent ? 'rgba(255,149,0,0.08)' : 'rgba(0,128,255,0.06)',
      border: `1px solid ${expired ? 'rgba(255,59,59,0.2)' : isUrgent ? 'rgba(255,149,0,0.25)' : 'rgba(0,128,255,0.15)'}`,
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    }}>
      <div>
        <div style={{ fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, color: expired ? 'var(--error)' : isUrgent ? 'var(--warning)' : 'var(--text-3)', marginBottom: 3 }}>
          {expired ? 'Subscription Expired' : 'Subscription Active'}
        </div>
        <div style={{ fontSize: 13, fontWeight: 600, color: expired ? 'var(--error)' : 'var(--text-1)' }}>
          {expired ? 'Renew to continue' : `Expires ${exp.toLocaleDateString('en-PK', { day: 'numeric', month: 'short', year: 'numeric' })}`}
        </div>
      </div>
      {!expired && (
        <div style={{
          textAlign: 'center',
          background: isUrgent ? 'rgba(255,149,0,0.12)' : 'var(--brand-glow)',
          borderRadius: 10, padding: '6px 12px', minWidth: 54,
        }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: isUrgent ? 'var(--warning)' : 'var(--brand)', lineHeight: 1 }}>{days}</div>
          <div style={{ fontSize: 9, fontWeight: 700, textTransform: 'uppercase', color: isUrgent ? 'var(--warning)' : 'var(--brand)', letterSpacing: 0.5 }}>days left</div>
        </div>
      )}
    </div>
  );
}

// ── Barber Referral Card (subscription days only, admin-controlled) ────────────
function BarberReferralCard({ userId, showToast }) {
  const [refCode, setRefCode]       = useState(null);
  const [codeCopied, setCodeCopied] = useState(false);
  const [linkCopied, setLinkCopied] = useState(false);
  const [referrals, setReferrals]   = useState([]);
  const [rewardDays, setRewardDays] = useState(null); // from admin settings

  useEffect(() => {
    if (!userId) return;
    getOrCreateReferralCode(userId).then(row => setRefCode(row?.code || null));
    fetchMyReferrals(userId).then(setReferrals);
    // Fetch admin-set reward amount
    supabase.from('app_settings').select('value').eq('key', 'referral_reward_days').maybeSingle()
      .then(({ data }) => { if (data?.value) setRewardDays(Number(data.value)); });
  }, [userId]);

  const handleCopyCode = async () => {
    if (!refCode) return;
    const ok = await copyToClipboard(refCode);
    if (ok) { setCodeCopied(true); showToast('success', 'Code copied!'); setTimeout(() => setCodeCopied(false), 1800); }
  };

  const handleShareLink = async () => {
    if (!refCode) return;
    const link = buildInviteLink(refCode);
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join Zentro as a Barber',
          text: `List your shop on Zentro — use my referral code ${refCode} when you sign up!`,
          url: link,
        });
        return;
      } catch { return; }
    }
    const ok = await copyToClipboard(link);
    if (ok) { setLinkCopied(true); showToast('success', 'Invite link copied!'); setTimeout(() => setLinkCopied(false), 1800); }
  };

  const confirmed = referrals.filter(r => r.status === 'rewarded' || r.status === 'confirmed').length;
  const pending   = referrals.filter(r => r.status === 'pending').length;

  return (
    <div style={{ marginBottom: 28 }}>
      {/* Reward banner */}
      <div style={{
        borderRadius: 18, overflow: 'hidden', marginBottom: 12,
        background: 'linear-gradient(135deg, #0a1628 0%, #0b1f3e 50%, #071430 100%)',
        border: '1.5px solid rgba(0,128,255,0.25)',
        boxShadow: '0 8px 32px rgba(0,128,255,0.12)',
      }}>
        {/* Decorative bar */}
        <div style={{ height: 3, background: 'linear-gradient(90deg, var(--brand), #00c6ff)' }} />
        <div style={{ padding: '18px 18px 0' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <div style={{
              width: 44, height: 44, borderRadius: 14, flexShrink: 0,
              background: 'linear-gradient(135deg, rgba(0,128,255,0.25), rgba(0,198,255,0.15))',
              border: '1.5px solid rgba(0,128,255,0.3)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              {Ico.gift('var(--brand)', 22)}
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, color: '#fff' }}>
                Refer Barbers
              </div>
              <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.55)', marginTop: 2 }}>
                {rewardDays != null
                  ? `Earn ${rewardDays} free subscription day${rewardDays !== 1 ? 's' : ''} per referral`
                  : 'Earn free subscription days per referral'}
              </div>
            </div>
          </div>

          {/* Stats row */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 16 }}>
            {[
              { label: 'Confirmed', value: confirmed, color: 'var(--success)' },
              { label: 'Pending',   value: pending,   color: '#FFB800' },
            ].map(s => (
              <div key={s.label} style={{
                background: 'rgba(255,255,255,0.05)', borderRadius: 12, padding: '12px 14px',
                border: '1px solid rgba(255,255,255,0.08)',
              }}>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24, color: s.color, lineHeight: 1 }}>{s.value}</div>
                <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.45)', fontWeight: 600, marginTop: 3, textTransform: 'uppercase', letterSpacing: 0.5 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Code strip */}
        {refCode && (
          <div style={{
            margin: '0 18px 18px',
            background: 'rgba(0,128,255,0.1)',
            border: '1px solid rgba(0,128,255,0.2)',
            borderRadius: 12, padding: '10px 14px',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <div>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.4)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 3 }}>Your Code</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: '#fff', letterSpacing: 2 }}>{refCode}</div>
            </div>
            <button onClick={handleCopyCode} style={{
              background: codeCopied ? 'var(--success)' : 'var(--brand)',
              border: 'none', borderRadius: 10, padding: '10px 14px',
              cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
              transition: 'all 0.2s', color: '#fff',
              fontSize: 12, fontFamily: 'var(--font-display)', fontWeight: 700,
            }}>
              {codeCopied ? Ico.check() : Ico.copy()}
              {codeCopied ? 'Copied' : 'Copy'}
            </button>
          </div>
        )}
      </div>

      {/* Share link button */}
      <button onClick={handleShareLink} className="btn btn-primary" style={{
        width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
      }}>
        {Ico.share()}
        {linkCopied ? 'Link Copied!' : 'Share Invite Link'}
      </button>

      {/* Recent referrals list */}
      {referrals.length > 0 && (
        <div style={{ marginTop: 14 }}>
          <p className="section-label" style={{ marginBottom: 8 }}>Recent Referrals</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {referrals.slice(0, 4).map((r, i) => (
              <div key={r.id} style={{
                background: 'var(--bg-card)', borderRadius: 12, padding: '10px 14px',
                border: '1px solid var(--border)',
                display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{
                    width: 34, height: 34, borderRadius: 10, flexShrink: 0,
                    background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {Ico.users('var(--brand)', 16)}
                  </div>
                  <div>
                    <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 13 }}>
                      {r.referee?.full_name || 'New Barber'}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--text-3)' }}>
                      {new Date(r.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })}
                    </div>
                  </div>
                </div>
                <span className={`badge ${r.status === 'rewarded' ? 'badge-success' : r.status === 'pending' ? 'badge-warning' : 'badge-success'}`} style={{ textTransform: 'capitalize' }}>
                  {r.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Subscription Days earned display ─────────────────────────────────────────
function SubscriptionDaysCard({ userId }) {
  const [days, setDays] = useState(null);

  useEffect(() => {
    if (!userId) return;
    fetchMyCredits(userId).then(d => setDays(d.subscriptionDaysTotal));
  }, [userId]);

  if (!days) return null;

  return (
    <div style={{
      marginBottom: 20,
      borderRadius: 14,
      background: 'linear-gradient(135deg, #CC8E00, #FFB800)',
      padding: '14px 18px',
      display: 'flex', alignItems: 'center', gap: 14,
      boxShadow: '0 6px 24px rgba(255,184,0,0.25)',
    }}>
      {Ico.timer('#fff', 22)}
      <div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.6 }}>Referral Bonus</div>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 20, color: '#fff' }}>+{days} free day{days !== 1 ? 's' : ''}</div>
        <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.75)', marginTop: 1 }}>Added to your next renewal</div>
      </div>
    </div>
  );
}

export default function BarberDashboard() {
  const { user, profile, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [shop, setShop]         = useState(null);
  const [bookings, setBookings] = useState([]);
  const [stats, setStats]       = useState({ today: 0, total: 0, completed: 0 });
  const [loading, setLoading]   = useState(true);
  const [tab, setTab]           = useState('today');

  const { plansConfig, loading: plansLoading } = usePlanPerks(shop?.subscription_tier);

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    if (profile && profile.role !== 'barber') { navigate('/'); return; }
    if (user) fetchData();
  }, [user, profile, authReady]); // eslint-disable-line

  const fetchData = async () => {
    const { data: shopData } = await supabase
      .from('shops').select('*').eq('owner_id', user.id).maybeSingle();
    setShop(shopData);
    if (!shopData) { setLoading(false); return; }

    const { data: bData } = await supabase
      .from('bookings')
      .select('*, profiles(full_name), services(name, price), time_slots(slot_date, start_time)')
      .eq('shop_id', shopData.id)
      .order('created_at', { ascending: false });

    const bs = bData || [];
    setBookings(bs);
    const today = format(new Date(), 'yyyy-MM-dd');
    const todayCount  = bs.filter(b => b.time_slots?.slot_date === today && b.status !== 'cancelled').length;
    const completed   = bs.filter(b => b.status === 'completed').length;
    setStats({ today: todayCount, total: bs.length, completed });
    setLoading(false);
  };

  const updateStatus = async (bookingId, status, slotId) => {
    await supabase.from('bookings').update({ status }).eq('id', bookingId);
    if (status === 'cancelled') {
      await supabase.from('time_slots').update({ is_booked: false }).eq('id', slotId);
    }
    showToast('success', `Booking ${status}`);
    fetchData();
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  if (!shop) return (
    <div className="page">
      <div className="empty-state" style={{ minHeight: '80dvh' }}>
        <div className="empty-icon">{Ico.scissors('var(--text-3)', 36)}</div>
        <div className="empty-title">No shop set up yet</div>
        <div className="empty-sub">Set up your shop to start receiving bookings</div>
        <button className="btn btn-primary btn-sm" onClick={() => navigate('/barber/setup')} style={{ marginTop: 16 }}>
          Set Up My Shop
        </button>
      </div>
    </div>
  );

  const today      = format(new Date(), 'yyyy-MM-dd');
  const todayBs    = bookings.filter(b => b.time_slots?.slot_date === today);
  const upcomingBs = bookings.filter(b => b.time_slots?.slot_date > today && b.status !== 'cancelled');
  const pastBs     = bookings.filter(b => b.time_slots?.slot_date < today);
  const tabBookings = tab === 'today' ? todayBs : tab === 'upcoming' ? upcomingBs : tab === 'past' ? pastBs : bookings;
  const currentPlan = shop.subscription_tier || 'basic';

  return (
    <div className="page">
      {ToastEl}
      <div style={{ padding: '24px 20px 0' }}>

        {/* ── Hero Header ───────────────────────────────────────────────── */}
        <div style={{ marginBottom: 24, position: 'relative' }}>
          {/* Shop name row */}
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
            <div>
              <p style={{ color: 'var(--text-3)', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 4 }}>Your Shop</p>
              <h1 style={{ fontSize: 26, fontFamily: 'var(--font-display)', fontWeight: 900, marginBottom: 6 }}>{shop.name}</h1>
              {!shop.is_active && <span className="badge badge-warning">Pending Approval</span>}
            </div>
            {/* Live dot */}
            {shop.is_active && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6 }}>
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--success)', boxShadow: '0 0 0 3px rgba(34,197,94,0.25)', display: 'inline-block' }} />
                <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--success)', textTransform: 'uppercase', letterSpacing: 0.5 }}>Live</span>
              </div>
            )}
          </div>
        </div>

        {/* ── Stats Cards ───────────────────────────────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 28 }}>
          {[
            { label: "Today",    value: stats.today,     icon: Ico.calendar('var(--brand)', 20), accent: 'var(--brand)' },
            { label: 'Total',    value: stats.total,     icon: Ico.barChart('var(--brand)', 20), accent: 'var(--brand)' },
            { label: 'Done',     value: stats.completed, icon: Ico.checkCircle('var(--success)', 20), accent: 'var(--success)' },
          ].map(s => (
            <div key={s.label} style={{
              borderRadius: 16,
              background: 'var(--bg-card)',
              border: '1.5px solid var(--border)',
              padding: '16px 10px',
              textAlign: 'center',
              position: 'relative', overflow: 'hidden',
            }}>
              {/* Accent glow top */}
              <div style={{ position: 'absolute', top: 0, left: '50%', transform: 'translateX(-50%)', width: 40, height: 2, borderRadius: 2, background: s.accent }} />
              <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 8 }}>{s.icon}</div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 22, color: s.accent, lineHeight: 1 }}>{s.value}</div>
              <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 4 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {/* ── Quick Actions ─────────────────────────────────────────────── */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 28 }}>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/barber/slots')}
            style={{ width: '100%', padding: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            {Ico.clock()} Manage Slots
          </button>
          <button className="btn btn-secondary btn-sm" onClick={() => navigate('/barber/setup')}
            style={{ width: '100%', padding: '13px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
            {Ico.gear()} Shop Setup
          </button>
        </div>

        {/* ── Subscription Days (from referral earnings) ─────────────────── */}
        <SubscriptionDaysCard userId={user?.id} />

        {/* ── Plan Cards ───────────────────────────────────────────────── */}
        {!plansLoading && (
          <div style={{ marginBottom: 28 }}>
            <p className="section-label">Subscription Plans</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              {['basic', 'pro', 'premium'].map(tier => {
                const p      = plansConfig[tier];
                const active = currentPlan === tier;
                const borderColors = { basic: '#8EA0BC', pro: 'var(--brand)', premium: '#FFB800' };
                return (
                  <div key={tier} style={{
                    borderRadius: 16,
                    border: active ? `2px solid ${borderColors[tier]}` : '2px solid var(--border)',
                    background: active ? `${borderColors[tier]}08` : 'var(--bg-card)',
                    position: 'relative', padding: '16px 18px',
                    boxShadow: active ? `0 4px 20px ${borderColors[tier]}22` : 'var(--shadow-card)',
                  }}>
                    {active && (
                      <span style={{
                        position: 'absolute', top: 12, right: 14,
                        background: borderColors[tier], color: '#fff',
                        fontSize: 10, fontWeight: 700, borderRadius: 6,
                        padding: '2px 8px', letterSpacing: 0.5,
                      }}>YOUR PLAN</span>
                    )}
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 10 }}>
                      <span>{PLAN_ICONS[tier]}</span>
                      <div>
                        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16 }}>{p.name}</div>
                        <div style={{ fontSize: 13, color: borderColors[tier], fontWeight: 700 }}>Rs {p.price?.toLocaleString()} / mo</div>
                      </div>
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                      {[
                        { label: 'Photos',   value: `${p.photos} uploads` },
                        { label: 'QR Code',  value: p.qr       ? 'Included' : 'Not included' },
                        { label: 'Badge',    value: p.badge    ? 'Included' : 'Not included' },
                        { label: 'Priority', value: p.priority ? 'Included' : 'Not included' },
                      ].map(f => (
                        <div key={f.label} style={{ background: 'var(--bg-input)', borderRadius: 8, padding: '8px 10px' }}>
                          <div style={{ fontSize: 10, color: 'var(--text-3)', fontWeight: 600, textTransform: 'uppercase', marginBottom: 2 }}>{f.label}</div>
                          <div style={{ fontSize: 12, fontWeight: 600, color: f.value.includes('Not') ? 'var(--text-3)' : 'var(--text-1)' }}>{f.value}</div>
                        </div>
                      ))}
                    </div>
                    {active && <SubCountdown expiresAt={shop.subscription_expires_at} />}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ── Barber Referral Section ───────────────────────────────────── */}
        <p className="section-label">Refer Barbers</p>
        <BarberReferralCard userId={user?.id} showToast={showToast} />

        {/* ── Bookings Tabs ─────────────────────────────────────────────── */}
        <div style={{ marginBottom: 24 }}>
          <p className="section-label">Bookings</p>
          <div style={{ display: 'flex', gap: 8, marginBottom: 16, overflowX: 'auto', paddingBottom: 4 }}>
            {[
              { key: 'today',    label: `Today (${todayBs.length})` },
              { key: 'upcoming', label: `Upcoming (${upcomingBs.length})` },
              { key: 'past',     label: `Past (${pastBs.length})` },
              { key: 'all',      label: `All (${bookings.length})` },
            ].map(t => (
              <button key={t.key} onClick={() => setTab(t.key)} style={{
                flexShrink: 0, padding: '7px 14px', borderRadius: 20,
                border: 'none', cursor: 'pointer', fontSize: 12, fontWeight: 700,
                fontFamily: 'var(--font-display)',
                background: tab === t.key ? 'var(--brand)' : 'var(--bg-input)',
                color:      tab === t.key ? '#fff'         : 'var(--text-2)',
                transition: 'all 0.15s',
              }}>{t.label}</button>
            ))}
          </div>

          {tabBookings.length === 0 ? (
            <div className="empty-state" style={{ padding: '24px 0' }}>
              <div className="empty-sub">No bookings here</div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {tabBookings.map(b => (
                <BookingRow key={b.id} booking={b} onUpdate={updateStatus} />
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

function BookingRow({ booking: b, onUpdate }) {
  const statusColor = { pending: 'var(--warning)', confirmed: 'var(--success)', cancelled: 'var(--text-3)', completed: 'var(--brand)' };

  // SVG icons inline for booking rows
  const ScissorsSmall = () => (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/>
      <line x1="20" y1="4" x2="8.12" y2="15.88"/>
      <line x1="14.47" y1="14.48" x2="20" y2="20"/>
      <line x1="8.12" y1="8.12" x2="12" y2="12"/>
    </svg>
  );
  const ClockSmall = () => (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>
    </svg>
  );
  const CalendarSmall = () => (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--text-3)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/>
      <line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/>
      <line x1="3" y1="10" x2="21" y2="10"/>
    </svg>
  );

  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700 }}>{b.profiles?.full_name || 'Customer'}</div>
        <span style={{ fontSize: 12, fontWeight: 700, color: statusColor[b.status], fontFamily: 'var(--font-display)' }}>
          {b.status?.toUpperCase()}
        </span>
      </div>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 5 }}>
        <ScissorsSmall /> {b.services?.name} — Rs {b.services?.price}
      </p>
      <p style={{ fontSize: 13, color: 'var(--text-2)', marginBottom: 4, display: 'flex', alignItems: 'center', gap: 5 }}>
        <ClockSmall /> {b.time_slots?.start_time?.slice(0, 5)}
      </p>
      <p style={{ fontSize: 12, color: 'var(--text-3)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 5 }}>
        <CalendarSmall /> {b.time_slots?.slot_date || '—'}
      </p>
      {b.status === 'pending' && (
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-primary btn-sm" style={{ flex: 1 }}
            onClick={() => onUpdate(b.id, 'confirmed', b.time_slot_id)}>Confirm</button>
          <button className="btn btn-danger btn-sm" style={{ flex: 1 }}
            onClick={() => onUpdate(b.id, 'cancelled', b.time_slot_id)}>Cancel</button>
        </div>
      )}
      {b.status === 'confirmed' && (
        <button className="btn btn-primary btn-sm"
          onClick={() => onUpdate(b.id, 'completed', b.time_slot_id)}>Mark Complete</button>
      )}
    </div>
  );
}
