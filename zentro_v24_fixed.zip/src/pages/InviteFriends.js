import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { Users, Tag, CheckCircle, Sparkle, DollarSign } from '../lib/icons';
import {
  getOrCreateReferralCode,
  fetchMyReferrals,
  fetchMyCredits,
  buildInviteLink,
  copyToClipboard,
} from '../lib/referrals';

const STEPS = [
  { title: 'Share your code', body: 'Send your unique code or invite link to a friend.' },
  { title: 'They sign up',    body: 'Your friend creates an account using your code.' },
  { title: 'You both earn',   body: 'Once they book their first appointment, you each get booking credits.' },
];

export default function InviteFriends() {
  const { user, authReady } = useAuth();
  const navigate = useNavigate();
  const { showToast, ToastEl } = useToast();

  const [code, setCode]           = useState(null);
  const [referrals, setReferrals] = useState([]);
  const [creditTotal, setCreditTotal] = useState(0);
  const [loading, setLoading]     = useState(true);
  const [copied, setCopied]       = useState(false);

  useEffect(() => {
    if (!authReady) return;
    if (!user) { navigate('/login'); return; }
    load();
  }, [user, authReady]); // eslint-disable-line

  const load = async () => {
    setLoading(true);
    const [codeRow, refs, credits] = await Promise.all([
      getOrCreateReferralCode(user.id),
      fetchMyReferrals(user.id),
      fetchMyCredits(user.id),
    ]);
    setCode(codeRow?.code || null);
    setReferrals(refs);
    setCreditTotal(credits.creditTotal);
    setLoading(false);
  };

  const handleCopyCode = async () => {
    if (!code) return;
    const ok = await copyToClipboard(code);
    if (ok) {
      setCopied(true);
      showToast('success', 'Code copied!');
      setTimeout(() => setCopied(false), 1800);
    } else {
      showToast('error', 'Could not copy — long-press to select instead');
    }
  };

  const handleCopyLink = async () => {
    if (!code) return;
    const ok = await copyToClipboard(buildInviteLink(code));
    if (ok) showToast('success', 'Invite link copied!');
    else showToast('error', 'Could not copy link');
  };

  const handleShare = async () => {
    if (!code) return;
    const link = buildInviteLink(code);
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Join Zentro',
          text: `Book your next haircut on Zentro — use my code ${code} and we both get credits!`,
          url: link,
        });
      } catch {} // user cancelled share sheet — not an error
    } else {
      handleCopyLink();
    }
  };

  if (!authReady || loading) return <div className="loading-screen"><div className="spinner" /></div>;

  return (
    <div className="page">
      {ToastEl}
      <div className="page-header">
        <button className="back-btn" onClick={() => navigate(-1)}>←</button>
        <span className="page-title">Invite Friends</span>
      </div>

      <div className="page-inner page-enter" style={{ paddingTop: 20 }}>

        {/* ── Hero ── */}
        <div className="invite-hero">
          <div className="invite-hero-icon">
            <Users size={26} color="#fff" />
          </div>
          <h2 style={{ fontSize: 19, marginBottom: 6 }}>Give credits, get credits</h2>
          <p style={{ color: 'var(--text-2)', fontSize: 13.5, lineHeight: 1.5, maxWidth: 280, margin: '0 auto' }}>
            Share your code with friends. When they book their first cut, you both earn booking credits.
          </p>

          <div className="refcode-chip">
            <span className="refcode-chip-code">{code || '—'}</span>
            <button
              className={`refcode-copy-btn${copied ? ' copied' : ''}`}
              onClick={handleCopyCode}
              aria-label="Copy code"
            >
              {copied ? <CheckCircle size={16} color="#fff" /> : <Tag size={15} color="#fff" />}
            </button>
          </div>

          <div style={{ display: 'flex', gap: 10, marginTop: 14 }}>
            <button className="btn btn-secondary btn-sm" style={{ flex: 1 }} onClick={handleCopyLink}>
              Copy Link
            </button>
            <button className="btn btn-primary btn-sm" style={{ flex: 1 }} onClick={handleShare}>
              Share
            </button>
          </div>
        </div>

        {/* ── Credits balance ── */}
        {creditTotal > 0 && (
          <div className="card fade-up" style={{ marginTop: 18, display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 40, height: 40, borderRadius: 12, flexShrink: 0,
              background: 'var(--brand-glow)', display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <DollarSign size={18} color="var(--brand)" />
            </div>
            <div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17 }}>
                Rs {creditTotal.toLocaleString()} in booking credits
              </div>
              <div style={{ fontSize: 12.5, color: 'var(--text-2)' }}>Applied automatically at checkout</div>
            </div>
          </div>
        )}

        {/* ── How it works ── */}
        <p className="section-label" style={{ marginTop: 28 }}>How It Works</p>
        <div className="accent-line-animated" />
        <div className="card">
          {STEPS.map((s, i) => (
            <div key={s.title} className="ref-step" style={{ borderBottom: i < STEPS.length - 1 ? '1px solid var(--border)' : 'none' }}>
              <div className="ref-step-num">{i + 1}</div>
              <div>
                <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, marginBottom: 2 }}>{s.title}</div>
                <div style={{ fontSize: 13, color: 'var(--text-2)', lineHeight: 1.45 }}>{s.body}</div>
              </div>
            </div>
          ))}
        </div>

        {/* ── Referral history ── */}
        <p className="section-label" style={{ marginTop: 28 }}>Your Invites</p>
        <div className="accent-line-animated" />
        {referrals.length === 0 ? (
          <div className="empty-state" style={{ padding: '36px 20px' }}>
            <div className="empty-icon"><Sparkle size={32} color="var(--text-3)" /></div>
            <div className="empty-title" style={{ fontSize: 16 }}>No invites yet</div>
            <div className="empty-sub">Share your code above to start earning credits</div>
          </div>
        ) : (
          <div className="card" style={{ padding: '6px 16px' }}>
            {referrals.map((r, i) => (
              <div key={r.id} className="ref-row stagger-in" style={{ animationDelay: `${i * 0.04}s` }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, minWidth: 0 }}>
                  <div className="ref-row-avatar">
                    {(r.referee?.full_name || r.referee?.email || '?')[0].toUpperCase()}
                  </div>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontWeight: 700, fontSize: 13.5, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 160 }}>
                      {r.referee?.full_name || r.referee?.email || 'Friend'}
                    </div>
                    <div style={{ fontSize: 11.5, color: 'var(--text-3)' }}>
                      {new Date(r.created_at).toLocaleDateString('en-PK', { day: 'numeric', month: 'short' })}
                    </div>
                  </div>
                </div>
                <span className={`badge ${r.status === 'rewarded' ? 'badge-success' : r.status === 'voided' ? 'badge-error' : 'badge-warning'}`}>
                  {r.status === 'rewarded' ? 'Earned' : r.status === 'voided' ? 'Voided' : 'Pending'}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
      <div style={{ height: 40 }} />
    </div>
  );
}
