// useIsWebView — true when running as an app: Appilix WebView APK or an installed Chrome app (PWA).
// Checked in order: saved flag -> ?apk=1 -> window.Android bridge -> user-agent.
// Once detected, the answer is saved so it stays true on every later page load
// (even if the URL param or UA hint is missing next time).

let _cached = null;
const KEY = 'zentro_is_apk';

const save = () => { try { localStorage.setItem(KEY, '1'); } catch (e) {} };

export default function useIsWebView() {
  if (_cached !== null) return _cached;

  try { if (localStorage.getItem(KEY) === '1') { _cached = true; return true; } } catch (e) {}

  const params = new URLSearchParams(window.location.search);
  if (params.get('apk') === '1') { _cached = true; save(); return true; }

  if (typeof window.Android !== 'undefined') { _cached = true; save(); return true; }

  const ua = navigator.userAgent || '';
  // Appilix name, "wv" token (with or without bracket), and the classic Android
  // WebView shape: "Version/x.x" together with "Chrome/" (normal Chrome has no "Version/").
  if (
    /Appilix/i.test(ua) ||
    /\bwv\b/.test(ua) ||
    (/Android/.test(ua) && /Version\/\d+\.\d+/.test(ua) && /Chrome\//.test(ua))
  ) { _cached = true; save(); return true; }

  // Installed app from Chrome (PWA / "Add to Home screen"): opens without browser bars.
  // Not saved to storage, because storage is shared with the normal Chrome tab.
  try {
    const standalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      window.matchMedia('(display-mode: fullscreen)').matches ||
      window.matchMedia('(display-mode: minimal-ui)').matches ||
      window.navigator.standalone === true ||
      (document.referrer || '').startsWith('android-app://');
    if (standalone) { _cached = true; return true; }
  } catch (e) {}

  _cached = false;
  return false;
}
