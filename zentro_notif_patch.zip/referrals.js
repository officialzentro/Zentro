import { supabase, dbWrite } from './supabase';

// ── Ensure the current user has a referral code, creating one if needed ────
// Calls the `ensure_referral_code` Postgres function (security definer),
// so it works under RLS regardless of which policies exist on referral_codes.
export async function getOrCreateReferralCode(userId) {
  const { data, error } = await supabase.rpc('ensure_referral_code', { p_owner_id: userId });
  if (error) {
    console.error('[Referrals] ensure_referral_code failed:', error.message);
    return null;
  }
  return data;
}

// ── Redeem a code entered at signup. Call right after the profile row is
//    created in Register.js. Safe to call even if the code is invalid —
//    returns { error } instead of throwing, so signup itself never fails
//    because of a bad referral code. ──
export async function redeemReferralCode(code, refereeId) {
  if (!code || !code.trim()) return { data: null, error: null };
  const { data, error } = await supabase.rpc('redeem_referral_code', {
    p_code: code.trim().toUpperCase(),
    p_referee_id: refereeId,
  });
  if (error) {
    console.error('[Referrals] redeem_referral_code failed:', error.message);
    return { data: null, error };
  }
  return { data, error: null };
}

// ── Fetch a user's referral history (as referrer), with referee display name ──
export async function fetchMyReferrals(userId) {
  // Step 1: fetch referral rows
  const { data: rows, error } = await supabase
    .from('referrals')
    .select('id, status, type, created_at, rewarded_at, referee_id')
    .eq('referrer_id', userId)
    .order('created_at', { ascending: false });
  if (error) {
    console.error('[Referrals] fetchMyReferrals failed:', error.message);
    return [];
  }
  if (!rows || rows.length === 0) return [];

  // Step 2: fetch referee profiles separately to avoid FK-alias issues
  const refereeIds = [...new Set(rows.map(r => r.referee_id).filter(Boolean))];
  let profileMap = {};
  if (refereeIds.length > 0) {
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, full_name, email')
      .in('id', refereeIds);
    if (profiles) {
      profiles.forEach(p => { profileMap[p.id] = p; });
    }
  }

  return rows.map(r => ({
    ...r,
    referee: profileMap[r.referee_id] || null,
  }));
}

// ── Fetch a user's credits ledger, split by kind ──
export async function fetchMyCredits(userId) {
  const { data, error } = await supabase
    .from('credits')
    .select('id, amount, kind, source, created_at, expires_at, redeemed_at')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) {
    console.error('[Referrals] fetchMyCredits failed:', error.message);
    return { creditTotal: 0, subscriptionDaysTotal: 0, rows: [] };
  }
  const rows = data || [];
  const active = rows.filter(r => !r.redeemed_at && (!r.expires_at || new Date(r.expires_at) > new Date()));
  const creditTotal = active.filter(r => r.kind === 'credit').reduce((s, r) => s + Number(r.amount), 0);
  const subscriptionDaysTotal = active.filter(r => r.kind === 'subscription_days').reduce((s, r) => s + Number(r.amount), 0);
  return { creditTotal, subscriptionDaysTotal, rows };
}

// ── Build a shareable invite link for a code ──
export function buildInviteLink(code) {
  return `${window.location.origin}/register?ref=${encodeURIComponent(code)}`;
}

// ── Copy text to clipboard ──
// Works across: website (HTTPS), PWA (standalone), and WebView APKs
// (Appilix / custom WebView where navigator.clipboard may be blocked)
export async function copyToClipboard(text) {
  // 1. Modern async clipboard API — works on HTTPS + PWA
  if (navigator.clipboard && navigator.clipboard.writeText) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      // Fall through — common in WebViews even on HTTPS
    }
  }

  // 2. execCommand fallback — works in WebViews and older browsers
  try {
    const el = document.createElement('textarea');
    el.value = text;
    // Keep it in flow but invisible so WebView doesn't ignore it
    el.setAttribute('readonly', '');
    el.style.cssText = 'position:fixed;top:0;left:0;width:1px;height:1px;opacity:0;';
    document.body.appendChild(el);
    // iOS needs a range selection, Android needs .select()
    if (navigator.userAgent.match(/ipad|iphone/i)) {
      const range = document.createRange();
      range.selectNodeContents(el);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      el.setSelectionRange(0, 999999);
    } else {
      el.focus();
      el.select();
    }
    const ok = document.execCommand('copy');
    document.body.removeChild(el);
    if (ok) return true;
  } catch {
    // Fall through
  }

  return false;
}

export { dbWrite };

// ── Notifications (in-app inbox) ──────────────────────────────────────────────
// Insert a notification row for a user.
// type: 'booking_confirmed' | 'booking_cancelled' | 'booking_reminder' | 'system' | etc.
export async function sendNotification(userId, { title, body, type = 'system', meta = {} }) {
  const { error } = await supabase.from('notifications').insert({
    user_id: userId,
    title,
    body,
    type,
    meta,
    is_read: false,
  });
  if (error) console.error('[Notifications] sendNotification failed:', error.message);
  return !error;
}

// Fetch latest notifications for a user (newest first, max 50)
export async function fetchNotifications(userId) {
  const { data, error } = await supabase
    .from('notifications')
    .select('id, title, body, type, meta, is_read, created_at')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) {
    console.error('[Notifications] fetchNotifications failed:', error.message);
    return [];
  }
  return data || [];
}

// Mark all notifications as read for a user
export async function markAllRead(userId) {
  await supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('user_id', userId)
    .eq('is_read', false);
}
