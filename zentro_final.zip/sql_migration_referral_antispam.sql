-- ════════════════════════════════════════════════════════════════
-- Zentro — Anti-spam Customer Referral Migration
-- Credits granted AUTOMATICALLY when referee completes first booking.
-- Amount is admin-configurable in Settings → referral_customer_credit
-- Run this in Supabase SQL Editor
-- ════════════════════════════════════════════════════════════════

-- ── 1. Update referrals status constraint ────────────────────────────────────
ALTER TABLE referrals DROP CONSTRAINT IF EXISTS referrals_status_check;
ALTER TABLE referrals ADD CONSTRAINT referrals_status_check
  CHECK (status IN (
    'pending',           -- barber referrals: awaiting plan purchase
    'awaiting_purchase', -- barber referrals: same
    'pending_booking',   -- NEW: customer referral waiting for first booking
    'rewarded'           -- credits granted
  ));

-- ── 2. Add audit column ───────────────────────────────────────────────────────
ALTER TABLE referrals
  ADD COLUMN IF NOT EXISTS first_booking_id uuid;

-- ── 3. Admin setting: credit amount per referral ──────────────────────────────
INSERT INTO app_settings (key, value)
VALUES ('referral_customer_credit', '50')
ON CONFLICT (key) DO NOTHING;

-- ── 4. Update redeem_referral_code RPC ───────────────────────────────────────
-- Now sets status = 'pending_booking' for customer referrals.
-- No credits on signup — blocks temp account spam.
CREATE OR REPLACE FUNCTION redeem_referral_code(p_code text, p_referee_id uuid)
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_referrer_id   uuid;
  v_referrer_role text;
  v_type          text;
BEGIN
  SELECT owner_id INTO v_referrer_id
    FROM referral_codes
   WHERE code = UPPER(TRIM(p_code))
   LIMIT 1;

  IF v_referrer_id IS NULL       THEN RETURN 'invalid_code';    END IF;
  IF v_referrer_id = p_referee_id THEN RETURN 'self_referral';  END IF;

  IF EXISTS (SELECT 1 FROM referrals WHERE referee_id = p_referee_id) THEN
    RETURN 'already_referred';
  END IF;

  SELECT role INTO v_referrer_role FROM profiles WHERE id = v_referrer_id LIMIT 1;
  v_type := CASE WHEN v_referrer_role = 'barber' THEN 'barber_to_customer' ELSE 'customer_to_customer' END;

  INSERT INTO referrals (referrer_id, referee_id, type, status, created_at)
  VALUES (
    v_referrer_id, p_referee_id, v_type,
    CASE WHEN v_type = 'customer_to_customer' THEN 'pending_booking' ELSE 'pending' END,
    now()
  );

  RETURN 'ok';
END;
$$;

-- ── 5. Trigger: auto-grant credits on first completed booking ─────────────────
CREATE OR REPLACE FUNCTION fn_referral_reward_on_first_booking()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_referral      referrals%ROWTYPE;
  v_credit_amount numeric;
  v_first_count   int;
BEGIN
  IF NEW.status <> 'completed' OR OLD.status = 'completed' THEN
    RETURN NEW;
  END IF;

  -- Count completed bookings for this customer (including current one)
  SELECT COUNT(*) INTO v_first_count
    FROM bookings
   WHERE customer_id = NEW.customer_id
     AND status = 'completed';

  -- Only on the very first completion
  IF v_first_count <> 1 THEN RETURN NEW; END IF;

  -- Find pending referral
  SELECT * INTO v_referral
    FROM referrals
   WHERE referee_id = NEW.customer_id
     AND status = 'pending_booking'
   LIMIT 1;

  IF v_referral.id IS NULL THEN RETURN NEW; END IF;

  -- Get admin-set credit amount (default 50)
  SELECT COALESCE(NULLIF(value, '')::numeric, 50)
    INTO v_credit_amount
    FROM app_settings
   WHERE key = 'referral_customer_credit'
   LIMIT 1;

  IF v_credit_amount IS NULL THEN v_credit_amount := 50; END IF;

  -- Grant to referrer
  INSERT INTO credits (user_id, amount, kind, source, created_at)
  VALUES (v_referral.referrer_id, v_credit_amount, 'customer_credit', 'referral_reward', now());

  -- Grant to referee
  INSERT INTO credits (user_id, amount, kind, source, created_at)
  VALUES (v_referral.referee_id, v_credit_amount, 'customer_credit', 'referral_reward', now());

  -- Mark rewarded
  UPDATE referrals
     SET status = 'rewarded', rewarded_at = now(), first_booking_id = NEW.id
   WHERE id = v_referral.id;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_referral_reward_on_first_booking ON bookings;
CREATE TRIGGER trg_referral_reward_on_first_booking
  AFTER UPDATE OF status ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION fn_referral_reward_on_first_booking();

-- ── 6. RLS ───────────────────────────────────────────────────────────────────
ALTER TABLE referrals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "referrals_own" ON referrals;
CREATE POLICY "referrals_own"
  ON referrals FOR SELECT
  USING (auth.uid() = referrer_id OR auth.uid() = referee_id);

-- ════════════════════════════════════════════════════════════════
-- How it works:
--   Signup with ref code  → referral row created, status = pending_booking
--   Referee completes 1st booking → trigger fires → credits granted to BOTH
--   Temp accounts get nothing (never complete a real booking)
--   Credit amount: admin Settings → referral_customer_credit (default Rs 50)
-- ════════════════════════════════════════════════════════════════
